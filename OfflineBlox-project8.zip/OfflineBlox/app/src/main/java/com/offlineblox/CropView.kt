package com.offlineblox

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Crop window: drag to move the picture, pinch to zoom, and line the guide (Minecraft-style unfolded
 * template of the shirt / pants / face) up with the picture. kind: 0 shirt, 1 pants, 2 face.
 */
class CropView(ctx: Context, private val src: Bitmap, private val kind: Int) : View(ctx) {
    companion object {
        /** bounding box in Minecraft 64x64 skin units: x, y, w, h */
        fun bbox(kind: Int): IntArray = when (kind) {
            0 -> intArrayOf(16, 16, 40, 16)
            1 -> intArrayOf(0, 16, 16, 16)
            else -> intArrayOf(8, 8, 8, 8)
        }
    }

    private val bb = bbox(kind)
    private val m = Matrix()
    private val frame = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0xFFFFE066.toInt() }
    private val dim = Paint().apply { color = 0xB0000000.toInt() }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFE066.toInt(); textAlign = Paint.Align.CENTER }
    private val sg = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            m.postScale(d.scaleFactor, d.scaleFactor, d.focusX, d.focusY)
            invalidate()
            return true
        }
    })
    private var lx = 0f
    private var ly = 0f
    private var pan = false

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val mw = w * 0.92f
        val mh = h * 0.86f
        val asp = bb[2].toFloat() / bb[3]
        var fw = mw
        var fh = fw / asp
        if (fh > mh) { fh = mh; fw = fh * asp }
        frame.set((w - fw) / 2f, (h - fh) / 2f, (w + fw) / 2f, (h + fh) / 2f)
        val sc = maxOf(frame.width() / src.width, frame.height() / src.height)
        m.reset()
        m.postScale(sc, sc)
        m.postTranslate(frame.centerX() - src.width * sc / 2f, frame.centerY() - src.height * sc / 2f)
    }

    private fun ux(x: Int) = frame.left + (x - bb[0]) / bb[2].toFloat() * frame.width()
    private fun uy(y: Int) = frame.top + (y - bb[1]) / bb[3].toFloat() * frame.height()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF1E1E1E.toInt())
        c.drawBitmap(src, m, paint)
        c.drawRect(0f, 0f, w, frame.top, dim)
        c.drawRect(0f, frame.bottom, w, h, dim)
        c.drawRect(0f, frame.top, frame.left, frame.bottom, dim)
        c.drawRect(frame.right, frame.top, w, frame.bottom, dim)
        c.drawRect(frame, line)
        for (r in AvatarTex.MC) {
            val ok = when (kind) {
                0 -> r[0] == 1 || r[0] == 3
                1 -> r[0] == 5
                else -> r[0] == 0 && r[1] == 0
            }
            if (!ok) continue
            c.drawRect(ux(r[2]), uy(r[3]), ux(r[2] + r[4]), uy(r[3] + r[5]), line)
        }
        text.textSize = frame.height() / 10f
        if (kind == 0) {
            c.drawText(L.t("FRONT", "หน้า"), ux(24), uy(26), text)
            c.drawText(L.t("BACK", "หลัง"), ux(36), uy(26), text)
            c.drawText(L.t("ARM", "แขน"), ux(46), uy(26), text)
        } else if (kind == 1) {
            c.drawText(L.t("FRONT", "หน้า"), ux(6), uy(26), text)
        } else {
            c.drawText(L.t("FACE", "ใบหน้า"), frame.centerX(), frame.centerY(), text)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sg.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; pan = true }
            MotionEvent.ACTION_POINTER_DOWN -> pan = false
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (e.actionIndex == 0) 1 else 0
                lx = e.getX(i); ly = e.getY(i)
                pan = e.pointerCount == 2
            }
            MotionEvent.ACTION_MOVE -> if (pan && e.pointerCount == 1 && !sg.isInProgress) {
                m.postTranslate(e.x - lx, e.y - ly)
                lx = e.x; ly = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pan = false
        }
        return true
    }

    /** The picture inside the guide frame, rendered at 8 px per skin unit. */
    fun result(): Bitmap {
        val ow = bb[2] * 8
        val oh = bb[3] * 8
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.scale(ow / frame.width(), oh / frame.height())
        c.translate(-frame.left, -frame.top)
        c.drawBitmap(src, m, paint)
        return out
    }
}
