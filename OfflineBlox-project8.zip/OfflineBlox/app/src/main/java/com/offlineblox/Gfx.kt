package com.offlineblox

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.opengl.GLES30
import android.opengl.GLUtils
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random

/** Small OpenGL ES 3.0 helper: one cube mesh, lit+textured+shadowed shader. */
class Gfx {
    companion object {
        const val SHADOW = 1024
        private const val TAG = "OfflineBlox"

        private const val VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;
layout(location = 3) in float aFace;
uniform mat4 uVP;
uniform mat4 uLightVP;
uniform mat4 uModel;
uniform vec3 uScale;
uniform vec4 uFace[6];
out vec3 vN;
out vec2 vUV;
out vec4 vShadow;
out vec3 vWorld;
out float vDist;
void main() {
  vec4 wp = uModel * vec4(aPos * uScale, 1.0);
  vWorld = wp.xyz;
  vN = normalize(mat3(uModel) * aNormal);
  vec4 r = uFace[int(aFace + 0.5)];
  vUV = r.xy + aUV * r.zw;
  vShadow = uLightVP * wp;
  gl_Position = uVP * wp;
  vDist = gl_Position.w;
}
"""

        private const val FS = """#version 300 es
precision highp float;
precision highp sampler2DShadow;
in vec3 vN;
in vec2 vUV;
in vec4 vShadow;
in vec3 vWorld;
in float vDist;
uniform sampler2D uTex;
uniform sampler2DShadow uShadowMap;
uniform vec4 uColor;
uniform vec3 uLightDir;
uniform vec3 uFog;
uniform vec2 uFogRange;
uniform int uMode;
uniform float uShadowOn;
uniform float uTexel;
out vec4 fragColor;
void main() {
  vec3 n = normalize(vN);
  vec2 uv = vUV;
  if (uMode == 1) {
    vec3 an = abs(n);
    vec2 w;
    if (an.z > 0.5) { w = vWorld.xy; } else if (an.x > 0.5) { w = vWorld.yz; } else { w = vWorld.xz; }
    uv = w / 4.0;
  }
  vec4 tex = texture(uTex, uv);
  vec3 base = tex.rgb * uColor.rgb;
  float ndl = max(dot(n, uLightDir), 0.0);
  float sh = 1.0;
  if (uShadowOn > 0.5) {
    vec3 sc = vShadow.xyz / vShadow.w * 0.5 + 0.5;
    if (sc.x > 0.0 && sc.x < 1.0 && sc.y > 0.0 && sc.y < 1.0 && sc.z < 1.0) {
      float sum = 0.0;
      for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
          sum += texture(uShadowMap, vec3(sc.xy + vec2(float(i), float(j)) * uTexel, sc.z - 0.003));
        }
      }
      sh = sum / 9.0;
    }
  }
  float hemi = 0.5 + 0.5 * n.z;
  float light = 0.36 + 0.14 * hemi + 0.62 * ndl * sh;
  vec3 col = base * light;
  float fog = clamp((vDist - uFogRange.x) / (uFogRange.y - uFogRange.x), 0.0, 1.0);
  col = mix(col, uFog, fog);
  fragColor = vec4(col, 1.0);
}
"""

        private const val SVS = """#version 300 es
layout(location = 0) in vec3 aPos;
uniform mat4 uLightVP;
uniform mat4 uModel;
uniform vec3 uScale;
void main() {
  gl_Position = uLightVP * (uModel * vec4(aPos * uScale, 1.0));
}
"""

        private const val SFS = """#version 300 es
precision mediump float;
void main() {
}
"""
    }

    var ok = false
    var error = ""
    var mode = 0
    var shadowPass = false
    var shadowOk = false
    var shadowFbo = 0
    var worldTex = 0
    private var shadowTex = 0
    private var prog = 0
    private var sprog = 0
    private var vao = 0

    private var uVP = 0; private var uLightVP = 0; private var uModel = 0; private var uScale = 0
    private var uFace = 0; private var uTex = 0; private var uShadowMap = 0; private var uColor = 0
    private var uLightDir = 0; private var uFog = 0; private var uFogRange = 0; private var uMode = 0
    private var uShadowOn = 0; private var uTexel = 0
    private var sLVP = 0; private var sModel = 0; private var sScale = 0

    private fun u(p: Int, n: String) = GLES30.glGetUniformLocation(p, n)

    fun init() {
        prog = link(VS, FS)
        sprog = link(SVS, SFS)
        if (prog == 0 || sprog == 0) { ok = false; return }
        uVP = u(prog, "uVP"); uLightVP = u(prog, "uLightVP"); uModel = u(prog, "uModel"); uScale = u(prog, "uScale")
        uFace = u(prog, "uFace"); uTex = u(prog, "uTex"); uShadowMap = u(prog, "uShadowMap"); uColor = u(prog, "uColor")
        uLightDir = u(prog, "uLightDir"); uFog = u(prog, "uFog"); uFogRange = u(prog, "uFogRange"); uMode = u(prog, "uMode")
        uShadowOn = u(prog, "uShadowOn"); uTexel = u(prog, "uTexel")
        sLVP = u(sprog, "uLightVP"); sModel = u(sprog, "uModel"); sScale = u(sprog, "uScale")
        buildMesh()
        worldTex = makeTexture(makeWorldBitmap(), true, true)
        initShadow()
        ok = true
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val st = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            Log.e(TAG, log)
            error += "Shader: " + log.take(240) + " "
            GLES30.glDeleteShader(s)
            return 0
        }
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val a = compile(GLES30.GL_VERTEX_SHADER, vs)
        val b = compile(GLES30.GL_FRAGMENT_SHADER, fs)
        if (a == 0 || b == 0) return 0
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, a)
        GLES30.glAttachShader(p, b)
        GLES30.glLinkProgram(p)
        val st = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(p)
            Log.e(TAG, log)
            error += "Link: " + log.take(240) + " "
            return 0
        }
        return p
    }

    private fun buildMesh() {
        // per face: normal, then corners TL, TR, BR, BL
        val faces = arrayOf(
            floatArrayOf(1f, 0f, 0f, .5f, -.5f, .5f, .5f, .5f, .5f, .5f, .5f, -.5f, .5f, -.5f, -.5f),
            floatArrayOf(-1f, 0f, 0f, -.5f, .5f, .5f, -.5f, -.5f, .5f, -.5f, -.5f, -.5f, -.5f, .5f, -.5f),
            floatArrayOf(0f, 1f, 0f, .5f, .5f, .5f, -.5f, .5f, .5f, -.5f, .5f, -.5f, .5f, .5f, -.5f),
            floatArrayOf(0f, -1f, 0f, -.5f, -.5f, .5f, .5f, -.5f, .5f, .5f, -.5f, -.5f, -.5f, -.5f, -.5f),
            floatArrayOf(0f, 0f, 1f, -.5f, -.5f, .5f, -.5f, .5f, .5f, .5f, .5f, .5f, .5f, -.5f, .5f),
            floatArrayOf(0f, 0f, -1f, .5f, -.5f, -.5f, .5f, .5f, -.5f, -.5f, .5f, -.5f, -.5f, -.5f, -.5f)
        )
        val uvs = floatArrayOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f)
        val data = FloatArray(24 * 9)
        val idx = ShortArray(36)
        for (f in 0 until 6) {
            val fd = faces[f]
            for (v in 0 until 4) {
                val o = (f * 4 + v) * 9
                data[o] = fd[3 + v * 3]; data[o + 1] = fd[4 + v * 3]; data[o + 2] = fd[5 + v * 3]
                data[o + 3] = fd[0]; data[o + 4] = fd[1]; data[o + 5] = fd[2]
                data[o + 6] = uvs[v * 2]; data[o + 7] = uvs[v * 2 + 1]
                data[o + 8] = f.toFloat()
            }
            val b = f * 4
            val k = f * 6
            idx[k] = b.toShort(); idx[k + 1] = (b + 1).toShort(); idx[k + 2] = (b + 2).toShort()
            idx[k + 3] = b.toShort(); idx[k + 4] = (b + 2).toShort(); idx[k + 5] = (b + 3).toShort()
        }
        val fb = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(data); fb.position(0)
        val sb = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        sb.put(idx); sb.position(0)

        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        vao = ids[0]
        GLES30.glBindVertexArray(vao)
        val bufs = IntArray(2)
        GLES30.glGenBuffers(2, bufs, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, bufs[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.size * 4, fb, GLES30.GL_STATIC_DRAW)
        val stride = 9 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, stride, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, stride, 24)
        GLES30.glEnableVertexAttribArray(3)
        GLES30.glVertexAttribPointer(3, 1, GLES30.GL_FLOAT, false, stride, 32)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, bufs[1])
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, sb, GLES30.GL_STATIC_DRAW)
    }

    private fun initShadow() {
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        shadowTex = t[0]
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, shadowTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_DEPTH_COMPONENT24, SHADOW, SHADOW, 0,
            GLES30.GL_DEPTH_COMPONENT, GLES30.GL_UNSIGNED_INT, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_MODE, GLES30.GL_COMPARE_REF_TO_TEXTURE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_FUNC, GLES30.GL_LEQUAL)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        shadowFbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, shadowFbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_TEXTURE_2D, shadowTex, 0)
        GLES30.glDrawBuffers(1, intArrayOf(GLES30.GL_NONE), 0)
        GLES30.glReadBuffer(GLES30.GL_NONE)
        shadowOk = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) == GLES30.GL_FRAMEBUFFER_COMPLETE
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    fun makeTexture(bmp: Bitmap, repeat: Boolean, mip: Boolean): Int {
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0])
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        if (mip) GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER,
            if (mip) GLES30.GL_LINEAR_MIPMAP_LINEAR else GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        val w = if (repeat) GLES30.GL_REPEAT else GLES30.GL_CLAMP_TO_EDGE
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, w)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, w)
        return t[0]
    }

    private fun makeWorldBitmap(): Bitmap {
        val s = 128
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        c.drawColor(0xFFD8D8D8.toInt())
        val r = Random(7)
        p.style = Paint.Style.FILL
        for (i in 0 until 900) {
            p.color = if (r.nextBoolean()) 0x18FFFFFF else 0x18000000
            val x = r.nextInt(s).toFloat()
            val y = r.nextInt(s).toFloat()
            c.drawRect(x, y, x + 3f, y + 3f, p)
        }
        val sf = s.toFloat()
        p.color = 0x30FFFFFF
        c.drawRect(0f, 0f, sf, 4f, p); c.drawRect(0f, 0f, 4f, sf, p)
        p.color = 0x40000000
        c.drawRect(0f, sf - 4f, sf, sf, p); c.drawRect(sf - 4f, 0f, sf, sf, p)
        p.color = 0x14000000; c.drawCircle(64f, 64f, 22f, p)
        p.color = 0x20FFFFFF; c.drawCircle(61f, 61f, 18f, p)
        return bmp
    }

    fun useTex(tex: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
    }

    fun beginMain(vp: FloatArray, lvp: FloatArray, light: FloatArray, fog: Int, near: Float, far: Float, shadowOn: Boolean) {
        shadowPass = false
        GLES30.glUseProgram(prog)
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0)
        GLES30.glUniformMatrix4fv(uLightVP, 1, false, lvp, 0)
        GLES30.glUniform3f(uLightDir, light[0], light[1], light[2])
        GLES30.glUniform3f(uFog, ((fog shr 16) and 255) / 255f, ((fog shr 8) and 255) / 255f, (fog and 255) / 255f)
        GLES30.glUniform2f(uFogRange, near, far)
        GLES30.glUniform1f(uShadowOn, if (shadowOn && shadowOk) 1f else 0f)
        GLES30.glUniform1f(uTexel, 1f / SHADOW)
        GLES30.glUniform1i(uTex, 0)
        GLES30.glUniform1i(uShadowMap, 1)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, shadowTex)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindVertexArray(vao)
    }

    fun beginShadow(lvp: FloatArray) {
        shadowPass = true
        GLES30.glUseProgram(sprog)
        GLES30.glUniformMatrix4fv(sLVP, 1, false, lvp, 0)
        GLES30.glBindVertexArray(vao)
    }

    /** model = rigid transform (translate + rotate). Size is applied separately. */
    fun box(model: FloatArray, sx: Float, sy: Float, sz: Float, color: Int, faces: FloatArray) {
        if (shadowPass) {
            GLES30.glUniformMatrix4fv(sModel, 1, false, model, 0)
            GLES30.glUniform3f(sScale, sx, sy, sz)
        } else {
            GLES30.glUniformMatrix4fv(uModel, 1, false, model, 0)
            GLES30.glUniform3f(uScale, sx, sy, sz)
            GLES30.glUniform4f(uColor, ((color shr 16) and 255) / 255f, ((color shr 8) and 255) / 255f, (color and 255) / 255f, 1f)
            GLES30.glUniform1i(uMode, mode)
            GLES30.glUniform4fv(uFace, 6, faces, 0)
        }
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, 36, GLES30.GL_UNSIGNED_SHORT, 0)
    }
}
