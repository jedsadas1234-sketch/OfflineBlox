package com.offlineblox

object Pal {
    private fun h(v: Long) = v.toInt()

    val skin = intArrayOf(
        h(0xFFF5CD30), h(0xFFFFDBAC), h(0xFFE0AC69), h(0xFFC68642), h(0xFF8D5524), h(0xFF5C3A21),
        h(0xFFF1E0D0), h(0xFF7BB661), h(0xFF6BA3E0), h(0xFFBDBDBD), h(0xFFF4A6C0)
    )
    val col = intArrayOf(
        h(0xFFC4281C), h(0xFF0D69AC), h(0xFF287F47), h(0xFFF5CD30), h(0xFFDA8541), h(0xFF6B327C),
        h(0xFFF2F3F3), h(0xFF1B2A35), h(0xFF9B9B9B), h(0xFF7C5C46), h(0xFFE8BAC8), h(0xFF008F9C),
        h(0xFFA4BD47), h(0xFF203A56), h(0xFF8E1F3A), h(0xFF7FC4F0)
    )
    val hairStyles = listOf("None", "Short", "Spiky", "Long", "Mohawk", "Bun")
    val hats = listOf("None", "Cap", "Top Hat", "Crown", "Party Hat", "Cowboy", "Headphones", "Beanie", "Bunny Ears", "Halo")
    val faces = listOf("Smile", "Cool", "Angry", "Tongue", "Surprised", "Happy", "Blush", "Sleepy")
    val backs = listOf("None", "Cape", "Wings", "Backpack", "Jetpack", "Sword", "Bat Wings")
    val designs = listOf("None", "Stripe", "Bars", "Pocket", "Heart", "Cross")
}

class Avatar(
    var skin: Int = 0, var shirt: Int = 1, var pants: Int = 2, var shoes: Int = 7,
    var hairC: Int = 9, var hair: Int = 1, var hat: Int = 0, var face: Int = 0,
    var back: Int = 0, var design: Int = 0
) {
    fun ser() = listOf(skin, shirt, pants, shoes, hairC, hair, hat, face, back, design).joinToString(",")

    companion object {
        fun parse(s: String): Avatar {
            val p = s.split(",").map { it.toIntOrNull() ?: 0 }
            fun g(i: Int, n: Int, def: Int) = if (i < p.size) p[i].coerceIn(0, n - 1) else def
            return Avatar(
                g(0, Pal.skin.size, 0), g(1, Pal.col.size, 1), g(2, Pal.col.size, 2), g(3, Pal.col.size, 7),
                g(4, Pal.col.size, 9), g(5, Pal.hairStyles.size, 1), g(6, Pal.hats.size, 0),
                g(7, Pal.faces.size, 0), g(8, Pal.backs.size, 0), g(9, Pal.designs.size, 0)
            )
        }
    }
}
