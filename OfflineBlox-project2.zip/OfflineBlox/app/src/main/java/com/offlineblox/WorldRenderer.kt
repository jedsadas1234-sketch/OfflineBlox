package com.offlineblox

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.floor
import kotlin.math.sqrt

class WorldRenderer(private val hud: GameHud) : GLSurfaceView.Renderer {
    private var gfx = Gfx()
    private var rig = Rig(gfx)
    private val atlas = HashMap<String, Int>()
    private val lproj = FloatArray(16)
    private val lview = FloatArray(16)
    private val lvp = FloatArray(16)
    private val model = FloatArray(16)
    private val light = FloatArray(3)
    private var w = 1
    private var h = 1

    init {
        val l = sqrt(0.42f * 0.42f + 0.30f * 0.30f + 0.85f * 0.85f)
        light[0] = 0.42f / l; light[1] = 0.30f / l; light[2] = 0.85f / l
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        gfx = Gfx()
        gfx.init()
        rig = Rig(gfx)
        atlas.clear()
        hud.glError = gfx.error
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = width; h = height
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val gm = hud.gm
        val sky = gm.skyBot
        GLES30.glClearColor(((sky shr 16) and 255) / 255f, ((sky shr 8) and 255) / 255f, (sky and 255) / 255f, 1f)
        if (!gfx.ok) {
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
            return
        }
        try {
            val cx = floor(hud.px)
            val cy = floor(hud.py)
            val cz = hud.pz
            Matrix.setLookAtM(lview, 0, cx + light[0] * 50f, cy + light[1] * 50f, cz + light[2] * 50f, cx, cy, cz, 0f, 0f, 1f)
            Matrix.orthoM(lproj, 0, -30f, 30f, -30f, 30f, 1f, 120f)
            Matrix.multiplyMM(lvp, 0, lproj, 0, lview, 0)
            val useShadow = hud.shadows && gfx.shadowOk
            if (useShadow) {
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, gfx.shadowFbo)
                GLES30.glViewport(0, 0, Gfx.SHADOW, Gfx.SHADOW)
                GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT)
                GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
                GLES30.glPolygonOffset(2f, 4f)
                gfx.beginShadow(lvp)
                drawScene(true)
                GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL)
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                GLES30.glViewport(0, 0, w, h)
            }
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
            gfx.beginMain(hud.vp, lvp, light, sky, 70f, 220f, useShadow)
            drawScene(false)
        } catch (e: Exception) {
            hud.glError = e.toString()
        }
    }

    private fun worldBox(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, color: Int) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, cx, cy, cz)
        gfx.box(model, sx, sy, sz, color, AvatarTex.white)
    }

    private fun drawScene(shadow: Boolean) {
        val gm = hud.gm
        gfx.mode = 1
        if (!shadow) gfx.useTex(gfx.worldTex)
        val f = gm.floor
        if (f != null && !shadow) {
            worldBox((f[0] + f[2]) / 2f, (f[1] + f[3]) / 2f, -0.75f, f[2] - f[0], f[3] - f[1], 1.5f, gm.floorColor)
        }
        for (b in gm.boxes) worldBox(b.x + b.w / 2f, b.y + b.d / 2f, b.z + b.h / 2f, b.w, b.d, b.h, b.color)
        gfx.mode = 0
        if (!hud.firstPerson) drawAv(shadow, hud.av, hud.px, hud.py, hud.pz, hud.yaw, hud.phase, hud.swing, hud.airT)
        for (r in hud.net.peers.values) {
            if (r.fresh) drawAv(shadow, r.av, r.x, r.y, r.z, r.yaw, r.phase, r.swing, r.airT)
        }
    }

    private fun drawAv(shadow: Boolean, a: Avatar, x: Float, y: Float, z: Float, yaw: Float, phase: Float, swing: Float, airT: Float) {
        if (!shadow) gfx.useTex(atlasTex(a))
        rig.draw(a, x, y, z, yaw, phase, swing, airT)
    }

    private fun atlasTex(a: Avatar): Int {
        val key = a.ser()
        var t = atlas[key]
        if (t == null) {
            if (atlas.size > 40) {
                for (v in atlas.values) GLES30.glDeleteTextures(1, intArrayOf(v), 0)
                atlas.clear()
            }
            val bmp = AvatarTex.make(a)
            t = gfx.makeTexture(bmp, false, false)
            bmp.recycle()
            atlas[key] = t
        }
        return t
    }
}
