package com.offlineblox

import kotlin.math.sin

class Box(val x: Float, val y: Float, val z: Float, val w: Float, val d: Float, val h: Float, val color: Int)

class GameMap(
    val name: String, val desc: String, val floor: FloatArray?, val floorColor: Int,
    val boxes: List<Box>, val sx: Float, val sy: Float, val skyTop: Int, val skyBot: Int
)

object Maps {
    val all: List<GameMap> by lazy { listOf(baseplate(), obby(), town()) }

    private fun baseplate(): GameMap {
        val b = ArrayList<Box>()
        val cols = intArrayOf(0xFFC4281C.toInt(), 0xFF0D69AC.toInt(), 0xFFF5CD30.toInt(), 0xFF287F47.toInt(), 0xFF6B327C.toInt())
        for (i in 0 until 8) b.add(Box(6f + i * 2f, -4f, 0f, 2f, 8f, 0.9f * (i + 1), cols[i % cols.size]))
        b.add(Box(22f, -4f, 0f, 8f, 8f, 7.2f, 0xFFF2F3F3.toInt()))
        val spots = listOf(-8f to -8f, -14f to 6f, -6f to 14f, 10f to -18f, -20f to -14f, 14f to 16f)
        for ((i, p) in spots.withIndex()) b.add(Box(p.first, p.second, 0f, 3f, 3f, 1.5f + (i % 3), cols[(i + 2) % cols.size]))
        return GameMap("Baseplate", "Empty plate, stairs and cubes. Free roam.",
            floatArrayOf(-40f, -40f, 40f, 40f), 0xFF7A7F85.toInt(), b, 0f, 0f, 0xFF4A90D9.toInt(), 0xFFBFE0FF.toInt())
    }

    private fun obby(): GameMap {
        val b = ArrayList<Box>()
        val cols = intArrayOf(0xFFC4281C.toInt(), 0xFFDA8541.toInt(), 0xFFF5CD30.toInt(), 0xFF287F47.toInt(), 0xFF0D69AC.toInt(), 0xFF6B327C.toInt())
        var x = 8f
        for (i in 0 until 22) {
            val size = if (i % 3 == 2) 2f else 3f
            val y = sin(i * 0.9f) * 5f
            b.add(Box(x, y, 0f + i * 0.7f, size, size, 0.6f, cols[i % cols.size]))
            x += size + 2.0f + (i % 4) * 0.5f
        }
        b.add(Box(x, -4f, 22 * 0.7f, 8f, 8f, 0.6f, 0xFFF5CD30.toInt()))
        return GameMap("Obby", "Jump across the platforms. Fall = respawn.",
            floatArrayOf(-5f, -5f, 5f, 5f), 0xFF3A7BD5.toInt(), b, 0f, 0f, 0xFF3B2A6B.toInt(), 0xFFB48CE0.toInt())
    }

    private fun town(): GameMap {
        val b = ArrayList<Box>()
        val road = 0xFF444B52.toInt()
        b.add(Box(-45f, -3f, 0f, 90f, 6f, 0.06f, road))
        b.add(Box(-3f, -45f, 0f, 6f, 90f, 0.06f, road))
        val houses = listOf(
            -30f to -30f, -30f to 14f, 14f to -30f, 14f to 14f, 28f to -12f, -38f to -8f
        )
        val pastel = intArrayOf(0xFFF2D8A7.toInt(), 0xFFBFE0FF.toInt(), 0xFFE8BAC8.toInt(), 0xFFC9E4B0.toInt(), 0xFFF5CD30.toInt(), 0xFFDDDDDD.toInt())
        for ((i, p) in houses.withIndex()) {
            b.add(Box(p.first, p.second, 0f, 8f, 8f, 5f, pastel[i % pastel.size]))
            b.add(Box(p.first - 0.5f, p.second - 0.5f, 5f, 9f, 9f, 1.5f, 0xFFC4281C.toInt()))
        }
        val trees = listOf(-12f to -12f, 10f to 10f, -12f to 10f, 10f to -12f, 22f to 24f, -24f to 24f, 30f to 8f, -30f to -4f)
        for (t in trees) {
            b.add(Box(t.first, t.second, 0f, 1f, 1f, 3f, 0xFF7C5C46.toInt()))
            b.add(Box(t.first - 1f, t.second - 1f, 3f, 3f, 3f, 3f, 0xFF287F47.toInt()))
        }
        return GameMap("Town", "Little town with houses and trees.",
            floatArrayOf(-45f, -45f, 45f, 45f), 0xFF6BA64A.toInt(), b, 0f, 0f, 0xFF5BA3E8.toInt(), 0xFFD6EEFF.toInt())
    }
}
