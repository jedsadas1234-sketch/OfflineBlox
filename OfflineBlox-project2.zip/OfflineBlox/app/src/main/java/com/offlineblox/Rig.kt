package com.offlineblox

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.opengl.Matrix
import java.util.Random
import kotlin.math.sin

/** Texture atlas for one avatar: rows = parts (head, torso, armL, armR, legL, legR), cols = 6 faces. Row 6 = white. */
object AvatarTex {
    const val W = 384
    const val H = 448
    const val C = 64

    private fun rect(row: Int, col: Int) = floatArrayOf((col * C + 1f) / W, (row * C + 1f) / H, (C - 2f) / W, (C - 2f) / H)

    // face order: +x(front), -x, +y, -y, +z(top), -z(bottom)
    val rects: Array<FloatArray> = Array(6) { part ->
        val a = FloatArray(24)
        for (f in 0 until 6) System.arraycopy(rect(part, f), 0, a, f * 4, 4)
        a
    }
    val white: FloatArray = FloatArray(24).also { a ->
        val r = rect(6, 0)
        for (f in 0 until 6) System.arraycopy(r, 0, a, f * 4, 4)
    }

    private fun fill(cv: Canvas, p: Paint, x: Float, y: Float, w: Float, h: Float, col: Int) {
        p.style = Paint.Style.FILL; p.color = col
        cv.drawRect(x, y, x + w, y + h, p)
    }

    private fun noise(cv: Canvas, p: Paint, ox: Float, oy: Float, seed: Int) {
        val r = Random(seed.toLong())
        p.style = Paint.Style.FILL
        for (i in 0 until 110) {
            p.color = if (r.nextBoolean()) 0x16FFFFFF else 0x16000000
            val x = ox + r.nextInt(C)
            val y = oy + r.nextInt(C)
            cv.drawRect(x, y, x + 2f, y + 2f, p)
        }
    }

    fun make(a: Avatar): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val skin = Pal.skin[a.skin]
        val shirt = Pal.col[a.shirt]
        val pants = Pal.col[a.pants]
        val shoes = Pal.col[a.shoes]
        val cs = C.toFloat()
        for (part in 0 until 6) {
            for (f in 0 until 6) {
                val ox = (f * C).toFloat()
                val oy = (part * C).toFloat()
                when (part) {
                    0 -> fill(cv, p, ox, oy, cs, cs, skin)
                    1 -> fill(cv, p, ox, oy, cs, cs, shirt)
                    2, 3 -> {
                        if (f < 4) {
                            fill(cv, p, ox, oy, cs, cs * 0.55f, shirt)
                            fill(cv, p, ox, oy + cs * 0.55f, cs, cs * 0.45f, skin)
                        } else fill(cv, p, ox, oy, cs, cs, if (f == 4) shirt else skin)
                    }
                    else -> {
                        if (f < 4) {
                            fill(cv, p, ox, oy, cs, cs * 0.8f, pants)
                            fill(cv, p, ox, oy + cs * 0.8f, cs, cs * 0.2f, shoes)
                        } else fill(cv, p, ox, oy, cs, cs, if (f == 4) pants else shoes)
                    }
                }
                noise(cv, p, ox, oy, part * 7 + f)
            }
        }
        faceDecal(cv, p, a.face, 0f, 0f)
        design(cv, p, a.design, 0f, cs)
        fill(cv, p, 0f, 6f * cs, cs, cs, 0xFFFFFFFF.toInt())
        return bmp
    }

    private fun faceDecal(cv: Canvas, p: Paint, id: Int, ox: Float, oy: Float) {
        fun fx(u: Float) = ox + (u + 0.6f) / 1.2f * C
        fun fy(v: Float) = oy + (5.2f - v) / 1.2f * C
        val dark = 0xFF111111.toInt()
        fun dot(u: Float, v: Float, r: Float, col: Int = dark) {
            p.style = Paint.Style.FILL; p.color = col
            cv.drawCircle(fx(u), fy(v), r / 1.2f * C, p)
        }
        fun ln(u1: Float, v1: Float, u2: Float, v2: Float) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 0.07f / 1.2f * C; p.strokeCap = Paint.Cap.ROUND; p.color = dark
            cv.drawLine(fx(u1), fy(v1), fx(u2), fy(v2), p)
        }
        fun poly(vararg q: Float) {
            var i = 0
            while (i + 3 < q.size) { ln(q[i], q[i + 1], q[i + 2], q[i + 3]); i += 2 }
        }
        fun box(u1: Float, u2: Float, v1: Float, v2: Float) {
            p.style = Paint.Style.FILL; p.color = dark
            cv.drawRect(fx(u1), fy(v2), fx(u2), fy(v1), p)
        }
        fun smile() = poly(-0.3f, 4.45f, -0.15f, 4.34f, 0.15f, 4.34f, 0.3f, 4.45f)
        fun eyes() { dot(-0.25f, 4.75f, 0.08f); dot(0.25f, 4.75f, 0.08f) }
        when (id) {
            0 -> { eyes(); smile() }
            1 -> { box(-0.5f, -0.05f, 4.6f, 4.9f); box(0.05f, 0.5f, 4.6f, 4.9f); smile() }
            2 -> { eyes(); ln(-0.42f, 5.02f, -0.1f, 4.9f); ln(0.42f, 5.02f, 0.1f, 4.9f); poly(-0.3f, 4.32f, -0.1f, 4.42f, 0.1f, 4.42f, 0.3f, 4.32f) }
            3 -> { eyes(); smile(); dot(0.08f, 4.27f, 0.1f, 0xFFFF6F91.toInt()) }
            4 -> { eyes(); dot(0f, 4.38f, 0.12f) }
            5 -> { poly(-0.42f, 4.7f, -0.28f, 4.86f, -0.14f, 4.7f); poly(0.14f, 4.7f, 0.28f, 4.86f, 0.42f, 4.7f); smile() }
            6 -> { eyes(); smile(); dot(-0.45f, 4.5f, 0.12f, 0x88FF6F91.toInt()); dot(0.45f, 4.5f, 0.12f, 0x88FF6F91.toInt()) }
            7 -> { ln(-0.4f, 4.75f, -0.1f, 4.75f); ln(0.1f, 4.75f, 0.4f, 4.75f); dot(0f, 4.38f, 0.06f) }
        }
    }

    private fun design(cv: Canvas, p: Paint, id: Int, ox: Float, oy: Float) {
        if (id == 0) return
        fun fx(u: Float) = ox + (u + 1f) / 2f * C
        fun fy(v: Float) = oy + (4f - v) / 2f * C
        fun r(u1: Float, u2: Float, v1: Float, v2: Float, col: Int) {
            p.style = Paint.Style.FILL; p.color = col
            cv.drawRect(fx(u1), fy(v2), fx(u2), fy(v1), p)
        }
        val w = 0xFFF2F3F3.toInt()
        when (id) {
            1 -> r(-1f, 1f, 2.9f, 3.2f, w)
            2 -> { r(-0.7f, -0.45f, 2f, 4f, w); r(-0.12f, 0.12f, 2f, 4f, w); r(0.45f, 0.7f, 2f, 4f, w) }
            3 -> r(0.3f, 0.85f, 3.2f, 3.8f, 0x55000000)
            4 -> {
                p.style = Paint.Style.FILL; p.color = 0xFFFF4D6D.toInt()
                cv.drawCircle(fx(-0.17f), fy(3.5f), 0.2f / 2f * C, p)
                cv.drawCircle(fx(0.17f), fy(3.5f), 0.2f / 2f * C, p)
                val path = Path()
                path.moveTo(fx(-0.35f), fy(3.42f)); path.lineTo(fx(0.35f), fy(3.42f)); path.lineTo(fx(0f), fy(2.9f)); path.close()
                cv.drawPath(path, p)
            }
            5 -> { r(-0.1f, 0.1f, 2.3f, 3.7f, w); r(-0.5f, 0.5f, 2.9f, 3.1f, w) }
        }
    }
}

/** R6-style rig: head, torso, 2 arms, 2 legs, rotating around shoulder/hip pivots. Front faces +x. */
class Rig(private val g: Gfx) {
    private val base = FloatArray(16)
    private val m = FloatArray(16)
    private val white = 0xFFFFFFFF.toInt()

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    fun draw(a: Avatar, x: Float, y: Float, z: Float, yaw: Float, phase: Float, swing: Float, airT: Float) {
        Matrix.setIdentityM(base, 0)
        Matrix.translateM(base, 0, x, y, z)
        Matrix.rotateM(base, 0, yaw, 0f, 0f, 1f)
        g.mode = 0
        val s = sin(phase)
        val amp = 50f * swing
        val aL = lerp(-amp * s, -150f, airT)
        val aR = lerp(amp * s, -150f, airT)
        val lL = lerp(amp * s, -18f, airT)
        val lR = lerp(-amp * s, 18f, airT)
        part(0f, 0f, 0f, 0f, 0f, 0f, 4.6f, 1.2f, 1.2f, 1.2f, AvatarTex.rects[0])
        part(0f, 0f, 0f, 0f, 0f, 0f, 3f, 1f, 2f, 2f, AvatarTex.rects[1])
        part(0f, 1.5f, 4f, aL, 0f, 0f, -1f, 1f, 1f, 2f, AvatarTex.rects[2])
        part(0f, -1.5f, 4f, aR, 0f, 0f, -1f, 1f, 1f, 2f, AvatarTex.rects[3])
        part(0f, 0.5f, 2f, lL, 0f, 0f, -1f, 1f, 1f, 2f, AvatarTex.rects[4])
        part(0f, -0.5f, 2f, lR, 0f, 0f, -1f, 1f, 1f, 2f, AvatarTex.rects[5])
        back(a.back)
        hair(a.hair, Pal.col[a.hairC])
        hat(a.hat, 5.2f + (if (a.hair in 1..5) 0.1f else 0f))
    }

    private fun part(px: Float, py: Float, pz: Float, ang: Float, cx: Float, cy: Float, cz: Float,
                     sx: Float, sy: Float, sz: Float, faces: FloatArray) {
        System.arraycopy(base, 0, m, 0, 16)
        Matrix.translateM(m, 0, px, py, pz)
        if (ang != 0f) Matrix.rotateM(m, 0, ang, 0f, 1f, 0f)
        Matrix.translateM(m, 0, cx, cy, cz)
        g.box(m, sx, sy, sz, white, faces)
    }

    private fun acc(x0: Float, y0: Float, z0: Float, w: Float, d: Float, h: Float, col: Int) {
        System.arraycopy(base, 0, m, 0, 16)
        Matrix.translateM(m, 0, x0 + w / 2f, y0 + d / 2f, z0 + h / 2f)
        g.box(m, w, d, h, col, AvatarTex.white)
    }

    private fun back(id: Int) {
        val wh = 0xFFF2F3F3.toInt()
        val brown = 0xFF7C5C46.toInt()
        val gray = 0xFF9B9B9B.toInt()
        val orange = 0xFFDA8541.toInt()
        when (id) {
            1 -> acc(-0.65f, -0.9f, 0.8f, 0.15f, 1.8f, 3.2f, 0xFFC4281C.toInt())
            2 -> { acc(-0.7f, -2.4f, 2.2f, 0.1f, 1.7f, 2.3f, wh); acc(-0.7f, 0.7f, 2.2f, 0.1f, 1.7f, 2.3f, wh) }
            3 -> { acc(-1.0f, -0.6f, 2.1f, 0.5f, 1.2f, 1.5f, brown); acc(-1.05f, -0.6f, 3.2f, 0.55f, 1.2f, 0.4f, 0xFF5A4030.toInt()) }
            4 -> {
                acc(-0.95f, -0.8f, 1.8f, 0.5f, 0.6f, 2f, gray); acc(-0.95f, 0.2f, 1.8f, 0.5f, 0.6f, 2f, gray)
                acc(-0.9f, -0.7f, 1.2f, 0.4f, 0.4f, 0.6f, orange); acc(-0.9f, 0.3f, 1.2f, 0.4f, 0.4f, 0.6f, orange)
            }
            5 -> { acc(-0.8f, -0.1f, 1.6f, 0.12f, 0.2f, 3.2f, 0xFFBDBDBD.toInt()); acc(-0.85f, -0.5f, 1.6f, 0.22f, 1.0f, 0.2f, brown) }
            6 -> {
                val bat = 0xFF3A2150.toInt()
                acc(-0.7f, -1.8f, 3f, 0.1f, 1.0f, 1.8f, bat); acc(-0.7f, -2.8f, 3f, 0.1f, 1.0f, 1.2f, bat)
                acc(-0.7f, 0.8f, 3f, 0.1f, 1.0f, 1.8f, bat); acc(-0.7f, 1.8f, 3f, 0.1f, 1.0f, 1.2f, bat)
            }
        }
    }

    private fun hair(id: Int, c: Int) {
        if (id == 0) return
        acc(-0.65f, -0.65f, 5.0f, 1.3f, 1.3f, 0.3f, c)
        acc(-0.65f, -0.65f, 4.2f, 0.2f, 1.3f, 0.8f, c)
        when (id) {
            2 -> { acc(-0.4f, -0.45f, 5.3f, 0.3f, 0.3f, 0.5f, c); acc(-0.1f, 0.1f, 5.3f, 0.3f, 0.3f, 0.6f, c); acc(-0.3f, 0.0f, 5.3f, 0.3f, 0.3f, 0.4f, c) }
            3 -> acc(-0.7f, -0.7f, 3.0f, 0.25f, 1.4f, 2.2f, c)
            4 -> acc(-0.65f, -0.15f, 5.3f, 1.3f, 0.3f, 0.6f, c)
            5 -> acc(-0.9f, -0.25f, 5.2f, 0.5f, 0.5f, 0.5f, c)
        }
    }

    private fun hat(id: Int, hz: Float) {
        val wh = 0xFFF2F3F3.toInt()
        val red = 0xFFC4281C.toInt()
        val gold = 0xFFF5CD30.toInt()
        val brown = 0xFF7C5C46.toInt()
        val ink = 0xFF1B2A35.toInt()
        when (id) {
            1 -> { acc(-0.7f, -0.7f, hz, 1.4f, 1.4f, 0.45f, red); acc(0.7f, -0.6f, hz, 0.6f, 1.2f, 0.12f, 0xFF8E1F18.toInt()) }
            2 -> {
                acc(-0.9f, -0.9f, hz, 1.8f, 1.8f, 0.12f, ink)
                acc(-0.55f, -0.55f, hz + 0.12f, 1.1f, 1.1f, 1.0f, ink)
                acc(-0.57f, -0.57f, hz + 0.15f, 1.14f, 1.14f, 0.22f, red)
            }
            3 -> {
                acc(-0.7f, -0.7f, hz, 1.4f, 1.4f, 0.4f, gold)
                acc(-0.7f, -0.7f, hz + 0.4f, 0.3f, 0.3f, 0.4f, gold); acc(0.4f, -0.7f, hz + 0.4f, 0.3f, 0.3f, 0.4f, gold)
                acc(-0.7f, 0.4f, hz + 0.4f, 0.3f, 0.3f, 0.4f, gold); acc(0.4f, 0.4f, hz + 0.4f, 0.3f, 0.3f, 0.4f, gold)
            }
            4 -> {
                var s = 1.1f
                var zz = hz
                for (i in 0 until 4) {
                    acc(-s / 2f, -s / 2f, zz, s, s, 0.35f, if (i % 2 == 0) 0xFFE8BAC8.toInt() else 0xFF7FC4F0.toInt())
                    zz += 0.35f; s -= 0.27f
                }
            }
            5 -> { acc(-1.0f, -1.0f, hz, 2.0f, 2.0f, 0.1f, brown); acc(-0.5f, -0.5f, hz + 0.1f, 1.0f, 1.0f, 0.7f, 0xFF5A4030.toInt()) }
            6 -> {
                acc(-0.3f, -0.8f, hz - 1.0f, 0.6f, 0.25f, 0.8f, ink); acc(-0.3f, 0.55f, hz - 1.0f, 0.6f, 0.25f, 0.8f, ink)
                acc(-0.2f, -0.8f, hz, 0.4f, 1.6f, 0.15f, ink)
            }
            7 -> { acc(-0.7f, -0.7f, hz, 1.4f, 1.4f, 0.6f, 0xFF0D69AC.toInt()); acc(-0.2f, -0.2f, hz + 0.6f, 0.4f, 0.4f, 0.4f, wh) }
            8 -> { acc(-0.2f, -0.5f, hz, 0.3f, 0.3f, 1.4f, wh); acc(-0.2f, 0.2f, hz, 0.3f, 0.3f, 1.4f, wh) }
            9 -> {
                acc(-0.6f, -0.6f, hz + 0.6f, 1.2f, 0.15f, 0.1f, gold); acc(-0.6f, 0.45f, hz + 0.6f, 1.2f, 0.15f, 0.1f, gold)
                acc(-0.6f, -0.45f, hz + 0.6f, 0.15f, 0.9f, 0.1f, gold); acc(0.45f, -0.45f, hz + 0.6f, 0.15f, 0.9f, 0.1f, gold)
            }
        }
    }
}
