package com.offlineblox

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 3D viewport (same OpenGL renderer code as the game). One finger: orbit, tap: select,
 * drag a gizmo arrow: move / scale, two fingers: zoom + pan.
 */
class EditorView(ctx: Context, private val st: EditorState) : GLSurfaceView(ctx) {
    var onSelect: ((Int) -> Unit)? = null
    var onEdited: (() -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private var downX = 0f
    private var downY = 0f
    private var lx = 0f
    private var ly = 0f
    private var moved = false
    private var two = false
    private var lastDist = 0f
    private var lmx = 0f
    private var lmy = 0f
    private var grab = -1
    private var gsx = 0f
    private var gsy = 0f
    private var gvx = 0f
    private var gvy = 0f
    private var gstart = 0f
    private val axes = arrayOf(floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, 1f))

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 0, 24, 0)
        setRenderer(Rend())
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        st.vw = w
        st.vh = h
    }

    // ---------------------------------------------------------------- math helpers
    private fun proj(vp: FloatArray, x: Float, y: Float, z: Float, out: FloatArray): Boolean {
        val pin = floatArrayOf(x, y, z, 1f)
        val po = FloatArray(4)
        Matrix.multiplyMV(po, 0, vp, 0, pin, 0)
        if (po[3] <= 0.01f) return false
        out[0] = (po[0] / po[3] * 0.5f + 0.5f) * st.vw
        out[1] = (1f - (po[1] / po[3] * 0.5f + 0.5f)) * st.vh
        return true
    }

    private fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val vx = bx - ax
        val vy = by - ay
        val l2 = vx * vx + vy * vy
        var t = if (l2 < 1e-6f) 0f else ((px - ax) * vx + (py - ay) * vy) / l2
        t = t.coerceIn(0f, 1f)
        val dx = px - (ax + t * vx)
        val dy = py - (ay + t * vy)
        return sqrt(dx * dx + dy * dy)
    }

    /** gizmo arrow for axis a: o = p0 (3 floats) then p1 (3 floats) in world space */
    private fun handlePts(b: EBox, a: Int, o: FloatArray) {
        val cx = b.x + b.w / 2f
        val cy = b.y + b.d / 2f
        val cz = b.z + b.h / 2f
        val len0 = st.dist * 0.18f
        var px = cx
        var py = cy
        var pz = cz
        var len = len0
        if (st.tool == 1) {
            if (a == 0) px = b.x + b.w else if (a == 1) py = b.y + b.d else pz = b.z + b.h
            len = len0 * 0.7f
        }
        o[0] = px; o[1] = py; o[2] = pz
        o[3] = px + axes[a][0] * len; o[4] = py + axes[a][1] * len; o[5] = pz + axes[a][2] * len
    }

    private fun hitHandle(x: Float, y: Float): Int {
        val b = st.selBox() ?: return -1
        val vp = FloatArray(16)
        st.viewProj(vp)
        var best = -1
        var bd = 34f * d
        val pt = FloatArray(6)
        val a = FloatArray(2)
        val c = FloatArray(2)
        for (ax in 0..2) {
            handlePts(b, ax, pt)
            if (!proj(vp, pt[0], pt[1], pt[2], a) || !proj(vp, pt[3], pt[4], pt[5], c)) continue
            val dd = segDist(x, y, a[0], a[1], c[0], c[1])
            if (dd < bd) { bd = dd; best = ax }
        }
        return best
    }

    private fun beginGrab(x: Float, y: Float, axis: Int) {
        val b = st.selBox() ?: return
        val vp = FloatArray(16)
        st.viewProj(vp)
        val pt = FloatArray(6)
        handlePts(b, axis, pt)
        val a = FloatArray(2)
        val u = FloatArray(2)
        if (!proj(vp, pt[0], pt[1], pt[2], a) ||
            !proj(vp, pt[0] + axes[axis][0], pt[1] + axes[axis][1], pt[2] + axes[axis][2], u)) { grab = -1; return }
        gvx = u[0] - a[0]
        gvy = u[1] - a[1]
        gsx = x
        gsy = y
        gstart = if (st.tool == 0) { if (axis == 0) b.x else if (axis == 1) b.y else b.z }
        else { if (axis == 0) b.w else if (axis == 1) b.d else b.h }
    }

    private fun dragGrab(x: Float, y: Float) {
        val b = st.selBox() ?: return
        val l2 = gvx * gvx + gvy * gvy
        if (l2 < 1e-3f) return
        val delta = ((x - gsx) * gvx + (y - gsy) * gvy) / l2
        var v = gstart + delta
        if (st.snap > 0f) v = Math.round(v / st.snap) * st.snap
        if (st.tool == 0) {
            if (grab == 0) b.x = v else if (grab == 1) b.y = v else b.z = v
        } else {
            val s = max(0.1f, v)
            if (grab == 0) b.w = s else if (grab == 1) b.d = s else b.h = s
        }
        onEdited?.invoke()
    }

    private fun rayBox(ox: Float, oy: Float, oz: Float, dx: Float, dy: Float, dz: Float, b: EBox): Float {
        var tmin = 0f
        var tmax = 1e30f
        val o = floatArrayOf(ox, oy, oz)
        val dd = floatArrayOf(dx, dy, dz)
        val lo = floatArrayOf(b.x, b.y, b.z)
        val hi = floatArrayOf(b.x + b.w, b.y + b.d, b.z + b.h)
        for (i in 0..2) {
            if (abs(dd[i]) < 1e-8f) {
                if (o[i] < lo[i] || o[i] > hi[i]) return -1f
            } else {
                var t1 = (lo[i] - o[i]) / dd[i]
                var t2 = (hi[i] - o[i]) / dd[i]
                if (t1 > t2) { val t = t1; t1 = t2; t2 = t }
                if (t1 > tmin) tmin = t1
                if (t2 < tmax) tmax = t2
                if (tmin > tmax) return -1f
            }
        }
        return tmin
    }

    private fun pick(x: Float, y: Float) {
        val vp = FloatArray(16)
        st.viewProj(vp)
        val inv = FloatArray(16)
        if (!Matrix.invertM(inv, 0, vp, 0)) return
        val nx = x / st.vw * 2f - 1f
        val ny = 1f - y / st.vh * 2f
        val pa = FloatArray(4)
        val pb = FloatArray(4)
        Matrix.multiplyMV(pa, 0, inv, 0, floatArrayOf(nx, ny, -1f, 1f), 0)
        Matrix.multiplyMV(pb, 0, inv, 0, floatArrayOf(nx, ny, 1f, 1f), 0)
        for (i in 0..2) { pa[i] /= pa[3]; pb[i] /= pb[3] }
        var dx = pb[0] - pa[0]
        var dy = pb[1] - pa[1]
        var dz = pb[2] - pa[2]
        val l = sqrt(dx * dx + dy * dy + dz * dz)
        if (l < 1e-6f) return
        dx /= l; dy /= l; dz /= l
        var best = -1
        var bt = 1e30f
        val boxes = st.doc.boxes
        for (i in boxes.indices) {
            val t = rayBox(pa[0], pa[1], pa[2], dx, dy, dz, boxes[i])
            if (t >= 0f && t < bt) { bt = t; best = i }
        }
        st.sel = best
        onSelect?.invoke(best)
    }

    // ---------------------------------------------------------------- touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lx = e.x; ly = e.y
                moved = false
                two = false
                grab = if (st.readOnly) -1 else hitHandle(e.x, e.y)
                if (grab >= 0) beginGrab(e.x, e.y, grab)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (grab >= 0) { grab = -1; onDragEnd?.invoke() }
                two = true
                moved = true
                if (e.pointerCount >= 2) {
                    lastDist = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                    lmx = (e.getX(0) + e.getX(1)) / 2f
                    lmy = (e.getY(0) + e.getY(1)) / 2f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 2) {
                    val cur = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
                    if (lastDist > 10f && cur > 10f) st.dist = (st.dist * lastDist / cur).coerceIn(2f, 1500f)
                    lastDist = cur
                    val mx = (e.getX(0) + e.getX(1)) / 2f
                    val my = (e.getY(0) + e.getY(1)) / 2f
                    val k = st.dist * 0.0012f
                    val rx = sin(st.yaw)
                    val ry = -cos(st.yaw)
                    st.tx -= (mx - lmx) * k * rx
                    st.ty -= (mx - lmx) * k * ry
                    st.tz = max(-50f, st.tz + (my - lmy) * k)
                    lmx = mx; lmy = my
                } else if (grab >= 0) {
                    dragGrab(e.x, e.y)
                } else {
                    if (!moved && hypot(e.x - downX, e.y - downY) > 12f * d) moved = true
                    if (moved && !two) {
                        st.yaw -= (e.x - lx) * 0.006f
                        st.pitch = (st.pitch + (e.y - ly) * 0.005f).coerceIn(-0.2f, 1.5f)
                    }
                }
                lx = e.x; ly = e.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (e.actionIndex == 0) 1 else 0
                if (i < e.pointerCount) { lx = e.getX(i); ly = e.getY(i) }
            }
            MotionEvent.ACTION_UP -> {
                if (grab >= 0) {
                    grab = -1
                    onDragEnd?.invoke()
                } else if (!moved && !two && !st.readOnly) {
                    pick(e.x, e.y)
                }
                two = false
            }
            MotionEvent.ACTION_CANCEL -> {
                if (grab >= 0) onDragEnd?.invoke()
                grab = -1
                two = false
            }
        }
        return true
    }

    // ---------------------------------------------------------------- renderer
    private inner class Rend : GLSurfaceView.Renderer {
        private var gfx = Gfx()
        private val vp = FloatArray(16)
        private val ident = FloatArray(16)
        private val model = FloatArray(16)
        private val faces = FloatArray(24).also { f -> for (i in 0 until 6) { f[i * 4 + 2] = 1f; f[i * 4 + 3] = 1f } }
        private val light = floatArrayOf(0.42f, 0.30f, 0.86f)

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            gfx = Gfx()
            gfx.init()
            Matrix.setIdentityM(ident, 0)
            GLES30.glEnable(GLES30.GL_DEPTH_TEST)
            GLES30.glDisable(GLES30.GL_CULL_FACE)
        }

        override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
            GLES30.glViewport(0, 0, w, h)
            st.vw = w
            st.vh = h
        }

        private fun box(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, c: Int) {
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, x, y, z)
            gfx.box(model, sx, sy, sz, c, faces)
        }

        private fun cube(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, c: Int) {
            box((x0 + x1) / 2f, (y0 + y1) / 2f, (z0 + z1) / 2f, x1 - x0, y1 - y0, z1 - z0, c)
        }

        private fun outline(b: EBox, t: Float, c: Int) {
            val mn = floatArrayOf(b.x, b.y, b.z)
            val mx = floatArrayOf(b.x + b.w, b.y + b.d, b.z + b.h)
            for (a in 0..2) {
                val a1 = (a + 1) % 3
                val a2 = (a + 2) % 3
                for (i in 0..1) for (j in 0..1) {
                    val lo = FloatArray(3)
                    val hi = FloatArray(3)
                    lo[a] = mn[a] - t; hi[a] = mx[a] + t
                    lo[a1] = (if (i == 0) mn[a1] else mx[a1]) - t; hi[a1] = lo[a1] + 2f * t
                    lo[a2] = (if (j == 0) mn[a2] else mx[a2]) - t; hi[a2] = lo[a2] + 2f * t
                    cube(lo[0], lo[1], lo[2], hi[0], hi[1], hi[2], 0xFFFFE066.toInt())
                }
            }
        }

        override fun onDrawFrame(gl: GL10?) {
            val doc = st.doc
            val sky = doc.skyBot
            GLES30.glClearColor(((sky shr 16) and 255) / 255f, ((sky shr 8) and 255) / 255f, (sky and 255) / 255f, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
            if (!gfx.ok) return
            st.viewProj(vp)
            gfx.beginMain(vp, ident, light, sky, 600f, 2200f, false)
            gfx.mode = 1
            gfx.useTex(gfx.worldTex)
            if (doc.hasFloor) {
                box((doc.fx0 + doc.fx1) / 2f, (doc.fy0 + doc.fy1) / 2f, -0.75f, doc.fx1 - doc.fx0, doc.fy1 - doc.fy0, 1.5f, doc.floorColor)
            }
            for (b in doc.boxes) box(b.x + b.w / 2f, b.y + b.d / 2f, b.z + b.h / 2f, b.w, b.d, b.h, b.color)
            // spawn marker
            cube(doc.sx - 0.4f, doc.sy - 0.4f, 0f, doc.sx + 0.4f, doc.sy + 0.4f, 2.5f, 0xFF43A047.toInt())
            cube(doc.sx - 0.7f, doc.sy - 0.7f, 2.5f, doc.sx + 0.7f, doc.sy + 0.7f, 3.4f, 0xFF66BB6A.toInt())
            val sb = st.selBox()
            if (sb != null) {
                outline(sb, st.dist * 0.003f + 0.04f, 0)
                GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT)
                if (!st.readOnly) drawGizmo(sb)
            }
        }

        private fun drawGizmo(b: EBox) {
            val colors = intArrayOf(0xFFE53935.toInt(), 0xFF43A047.toInt(), 0xFF1E88E5.toInt())
            val pt = FloatArray(6)
            val tt = st.dist * 0.005f
            val tip = if (st.tool == 1) tt * 3.2f else tt * 2.2f
            for (a in 0..2) {
                handlePts(b, a, pt)
                cube(min(pt[0], pt[3]) - tt, min(pt[1], pt[4]) - tt, min(pt[2], pt[5]) - tt,
                    max(pt[0], pt[3]) + tt, max(pt[1], pt[4]) + tt, max(pt[2], pt[5]) + tt, colors[a])
                cube(pt[3] - tip, pt[4] - tip, pt[5] - tip, pt[3] + tip, pt[4] + tip, pt[5] + tip, colors[a])
            }
        }
    }
}
