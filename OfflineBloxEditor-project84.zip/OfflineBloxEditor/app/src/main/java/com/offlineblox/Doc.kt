package com.offlineblox

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList

class EBox(
    var x: Float, var y: Float, var z: Float, var w: Float, var d: Float, var h: Float, var color: Int,
    var kind: Int = 0, var mx: Float = 0f, var my: Float = 0f, var mz: Float = 0f,
    var period: Float = 0f, var phase: Float = 0f, var extra: JSONObject? = null
) {
    fun copy2(): EBox = EBox(x, y, z, w, d, h, color, kind, mx, my, mz, period, phase, extra?.let { JSONObject(it.toString()) })
}

/** The map in memory. toJson()/parse() are the .map format of the game; unknown fields are kept. */
class EDoc {
    var version = 1
    var name = "New Map"
    var desc = "Made with OfflineBlox Editor"
    var sx = 0f
    var sy = 0f
    var skyTop = 0xFF4A90D9.toInt()
    var skyBot = 0xFFBFE0FF.toInt()
    var hasFloor = true
    var fx0 = -100f
    var fy0 = -100f
    var fx1 = 100f
    var fy1 = 100f
    var floorColor = 0xFF7A7F85.toInt()
    val boxes = CopyOnWriteArrayList<EBox>()
    var extra: JSONObject? = null

    fun toJson(pretty: Boolean): String {
        val o = JSONObject()
        o.put("version", version)
        o.put("name", name)
        o.put("desc", desc)
        o.put("spawn", JSONArray().put(r(sx)).put(r(sy)))
        o.put("sky", JSONArray().put(hex(skyTop)).put(hex(skyBot)))
        if (hasFloor) {
            val fo = JSONObject()
            fo.put("rect", JSONArray().put(r(fx0)).put(r(fy0)).put(r(fx1)).put(r(fy1)))
            fo.put("color", hex(floorColor))
            o.put("floor", fo)
        }
        val arr = JSONArray()
        for (b in boxes) {
            val j = JSONObject()
            j.put("x", r(b.x)); j.put("y", r(b.y)); j.put("z", r(b.z))
            j.put("w", r(b.w)); j.put("d", r(b.d)); j.put("h", r(b.h))
            j.put("color", hex(b.color))
            if (b.kind != 0) j.put("kind", b.kind)
            if (b.mx != 0f || b.my != 0f || b.mz != 0f) j.put("move", JSONArray().put(r(b.mx)).put(r(b.my)).put(r(b.mz)))
            if (b.period != 0f) j.put("period", r(b.period))
            if (b.phase != 0f) j.put("phase", r(b.phase))
            putExtra(j, b.extra)
            arr.put(j)
        }
        o.put("boxes", arr)
        putExtra(o, extra)
        return if (pretty) o.toString(2) else o.toString()
    }

    companion object {
        private val KNOWN_TOP = setOf("version", "name", "desc", "spawn", "sky", "floor", "boxes")
        private val KNOWN_BOX = setOf("x", "y", "z", "w", "d", "h", "color", "kind", "move", "period", "phase")

        fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

        fun col(s: String?, def: Int): Int {
            if (s.isNullOrEmpty()) return def
            return try { Color.parseColor(s) } catch (_: Exception) { def }
        }

        private fun r(v: Float): Double = Math.round(v * 1000f) / 1000.0

        private fun putExtra(o: JSONObject, ex: JSONObject?) {
            if (ex == null) return
            val ks = ex.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                o.put(k, ex.get(k))
            }
        }

        /** Throws if the text is not valid JSON or is too big. */
        fun parse(text: String): EDoc {
            if (text.length > 4000000) throw IllegalArgumentException("file too large")
            val o = JSONObject(text)
            val d = EDoc()
            d.version = o.optInt("version", 1)
            d.name = o.optString("name", "Map").take(40)
            d.desc = o.optString("desc", "").take(120)
            val sp = o.optJSONArray("spawn")
            d.sx = (sp?.optDouble(0, 0.0) ?: 0.0).toFloat()
            d.sy = (sp?.optDouble(1, 0.0) ?: 0.0).toFloat()
            val sk = o.optJSONArray("sky")
            d.skyTop = col(sk?.optString(0, ""), 0xFF4A90D9.toInt())
            d.skyBot = col(sk?.optString(1, ""), 0xFFBFE0FF.toInt())
            val fl = o.optJSONObject("floor")
            d.hasFloor = fl != null
            if (fl != null) {
                val rc = fl.optJSONArray("rect")
                if (rc != null && rc.length() >= 4) {
                    d.fx0 = rc.getDouble(0).toFloat(); d.fy0 = rc.getDouble(1).toFloat()
                    d.fx1 = rc.getDouble(2).toFloat(); d.fy1 = rc.getDouble(3).toFloat()
                }
                d.floorColor = col(fl.optString("color", ""), d.floorColor)
            }
            val arr = o.optJSONArray("boxes") ?: JSONArray()
            if (arr.length() > 8000) throw IllegalArgumentException("too many boxes (max 8000)")
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                val mv = j.optJSONArray("move")
                var ex: JSONObject? = null
                val ks = j.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    if (k !in KNOWN_BOX) {
                        if (ex == null) ex = JSONObject()
                        ex.put(k, j.get(k))
                    }
                }
                d.boxes.add(EBox(
                    j.optDouble("x", 0.0).toFloat(), j.optDouble("y", 0.0).toFloat(), j.optDouble("z", 0.0).toFloat(),
                    j.optDouble("w", 1.0).toFloat(), j.optDouble("d", 1.0).toFloat(), j.optDouble("h", 1.0).toFloat(),
                    col(j.optString("color", ""), 0xFFB0B8C0.toInt()),
                    j.optInt("kind", 0).coerceIn(0, 7),
                    (mv?.optDouble(0, 0.0) ?: 0.0).toFloat(), (mv?.optDouble(1, 0.0) ?: 0.0).toFloat(), (mv?.optDouble(2, 0.0) ?: 0.0).toFloat(),
                    j.optDouble("period", 0.0).toFloat(), j.optDouble("phase", 0.0).toFloat(), ex
                ))
            }
            var ext: JSONObject? = null
            val tk = o.keys()
            while (tk.hasNext()) {
                val k = tk.next()
                if (k !in KNOWN_TOP) {
                    if (ext == null) ext = JSONObject()
                    ext.put(k, o.get(k))
                }
            }
            d.extra = ext
            return d
        }
    }
}
