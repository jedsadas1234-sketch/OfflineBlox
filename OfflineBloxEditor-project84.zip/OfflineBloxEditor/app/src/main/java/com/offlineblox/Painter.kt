package com.offlineblox

/** What Gfx implements: draw a box with a rigid model matrix plus a size. */
interface Painter {
    var mode: Int
    fun box(model: FloatArray, sx: Float, sy: Float, sz: Float, color: Int, faces: FloatArray)
}
