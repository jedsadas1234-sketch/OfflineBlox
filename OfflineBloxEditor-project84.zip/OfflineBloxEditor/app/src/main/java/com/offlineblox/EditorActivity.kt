package com.offlineblox

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private object L {
    var th = Locale.getDefault().language == "th"
    fun t(en: String, thai: String) = if (th) thai else en
}

/**
 * OfflineBlox map editor. The map lives in memory (EDoc); the .map JSON is written to the project
 * file continuously while you edit. The JSON button pauses that and lets you type the JSON yourself;
 * closing the JSON panel validates it, loads it, and the automatic writing continues.
 */
class EditorActivity : Activity() {
    private val st = EditorState()
    private lateinit var view: EditorView
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private val undo = ArrayList<String>()
    private val redo = ArrayList<String>()
    private var jsonOpen = false
    private var jsonBackup = ""
    private var jsonValid = true
    private var updatingProps = false
    private var saveScheduled = false
    private lateinit var status: TextView
    private lateinit var explorer: ListView
    private val items = ArrayList<String>()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var propsScroll: ScrollView
    private lateinit var propsBox: LinearLayout
    private lateinit var rightPane: FrameLayout
    private lateinit var jsonPanel: LinearLayout
    private lateinit var jsonEdit: EditText
    private lateinit var jsonErr: TextView
    private val propFields = ArrayList<Pair<String, EditText>>()
    private val toolBtns = ArrayList<TextView>()
    private lateinit var snapBtn: TextView
    private val snaps = floatArrayOf(0f, 0.5f, 1f, 2f, 5f)
    private var snapIdx = 2

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun bg(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(5).toFloat() }
    private fun kindNames() = arrayOf(
        L.t("Solid", "ทึบ"), L.t("Lava", "ลาวา"), L.t("Bounce pad", "แท่นเด้ง"), L.t("Moving platform", "แท่นเลื่อน"),
        L.t("Blinking platform", "แท่นกระพริบ"), L.t("Checkpoint", "เช็กพอยต์"), L.t("Moving lava", "ลาวาเลื่อน"), L.t("Decor", "ตกแต่ง")
    )

    // ------------------------------------------------------------------ setup
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = getSharedPreferences("editor", MODE_PRIVATE)
        L.th = prefs.getBoolean("th", L.th)
        File(filesDir, "projects").mkdirs()
        buildUi()
        var d: EDoc? = null
        val last = prefs.getString("last", null)
        if (last != null) {
            try { d = EDoc.parse(File(File(filesDir, "projects"), last).readText()) } catch (_: Exception) {}
        }
        loadDoc(d ?: sampleDoc())
        handleIncoming(intent)
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        setIntent(i)
        handleIncoming(i)
    }

    override fun onPause() {
        commitUndo()
        saveNow()
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (jsonOpen) closeJson() else super.onBackPressed()
    }

    private fun sampleDoc(): EDoc {
        val d = EDoc()
        d.boxes.add(EBox(10f, -5f, 0f, 10f, 10f, 3f, 0xFFC4281C.toInt()))
        d.boxes.add(EBox(24f, -2f, 0f, 4f, 4f, 6f, 0xFF0D69AC.toInt()))
        d.boxes.add(EBox(-14f, -2f, 0f, 4f, 4f, 0.4f, 0xFFFF5FA2.toInt(), 2))
        return d
    }

    private fun tbtn(t: String, f: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 13f
        v.setTextColor(Color.WHITE)
        v.setPadding(dp(10), dp(6), dp(10), dp(6))
        v.background = bg(0xFF4A4A4A.toInt())
        v.setOnClickListener { f() }
        return v
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF1E1E1E.toInt())

        val tbScroll = HorizontalScrollView(this)
        tbScroll.setBackgroundColor(0xFF333333.toInt())
        val tb = LinearLayout(this)
        tb.orientation = LinearLayout.HORIZONTAL
        tb.setPadding(dp(4), dp(4), dp(4), dp(4))
        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(3), 0, dp(3), 0)
            tb.addView(v, lp)
        }
        add(tbtn(L.t("File", "ไฟล์")) { fileMenu() })
        val mv = tbtn(L.t("Move", "ย้าย")) { setTool(0) }
        val sc = tbtn(L.t("Scale", "ย่อขยาย")) { setTool(1) }
        toolBtns.add(mv); toolBtns.add(sc)
        add(mv); add(sc)
        add(tbtn("+ Box") { addBox() })
        add(tbtn(L.t("Duplicate", "ทำซ้ำ")) { dupBox() })
        add(tbtn(L.t("Delete", "ลบ")) { delBox() })
        add(tbtn(L.t("Undo", "ย้อนกลับ")) { undoOp() })
        add(tbtn(L.t("Redo", "ทำใหม่")) { redoOp() })
        snapBtn = tbtn("") { cycleSnap() }
        add(snapBtn)
        add(tbtn("JSON") { toggleJson() })
        add(tbtn(if (L.th) "EN" else "ไทย") { toggleLang() })
        tbScroll.addView(tb)
        root.addView(tbScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.HORIZONTAL
        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.textSize = 11f
                v.setTextColor(Color.WHITE)
                v.setBackgroundColor(if (position == st.sel) 0xFF1F5FA8.toInt() else 0)
                return v
            }
        }
        explorer = ListView(this)
        explorer.adapter = adapter
        explorer.setBackgroundColor(0xFF2A2A2A.toInt())
        explorer.setOnItemClickListener { _, _, pos, _ -> selectBox(pos, true) }
        mid.addView(explorer, LinearLayout.LayoutParams(dp(150), ViewGroup.LayoutParams.MATCH_PARENT))

        view = EditorView(this, st)
        view.onSelect = { i -> selectBox(i, false) }
        view.onEdited = { refreshPropValues(); changed() }
        view.onDragEnd = { refreshPropValues(); changed() }
        mid.addView(view, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        rightPane = FrameLayout(this)
        propsScroll = ScrollView(this)
        propsScroll.setBackgroundColor(0xFF2A2A2A.toInt())
        propsBox = LinearLayout(this)
        propsBox.orientation = LinearLayout.VERTICAL
        propsScroll.addView(propsBox)
        rightPane.addView(propsScroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        jsonPanel = buildJsonPanel()
        jsonPanel.visibility = View.GONE
        rightPane.addView(jsonPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        mid.addView(rightPane, LinearLayout.LayoutParams(dp(250), ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(mid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this)
        status.textSize = 11f
        status.setTextColor(0xFFAAAAAA.toInt())
        status.setPadding(dp(8), dp(3), dp(8), dp(3))
        status.setBackgroundColor(0xFF333333.toInt())
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        updateSnapLabel()
        setTool(0)
    }

    private fun setTool(t: Int) {
        st.tool = t
        for (i in toolBtns.indices) toolBtns[i].background = bg(if (i == t) 0xFF1F5FA8.toInt() else 0xFF4A4A4A.toInt())
    }

    private fun cycleSnap() {
        snapIdx = (snapIdx + 1) % snaps.size
        st.snap = snaps[snapIdx]
        updateSnapLabel()
    }

    private fun updateSnapLabel() {
        st.snap = snaps[snapIdx]
        snapBtn.text = L.t("Snap: ", "สแนป: ") + (if (st.snap == 0f) L.t("off", "ปิด") else st.snap.toString())
    }

    // ------------------------------------------------------------------ document
    private fun loadDoc(d: EDoc) {
        st.doc = d
        st.sel = -1
        fitCamera(d)
        undo.clear(); redo.clear()
        undo.add(d.toJson(false))
        refreshExplorer()
        rebuildProps()
        saveNow()
    }

    private fun fitCamera(d: EDoc) {
        if (d.boxes.isEmpty()) { st.tx = 0f; st.ty = 0f; st.tz = 0f; st.dist = 70f; return }
        var x0 = 1e9f; var y0 = 1e9f; var z0 = 1e9f
        var x1 = -1e9f; var y1 = -1e9f; var z1 = -1e9f
        for (b in d.boxes) {
            x0 = min(x0, b.x); y0 = min(y0, b.y); z0 = min(z0, b.z)
            x1 = max(x1, b.x + b.w); y1 = max(y1, b.y + b.d); z1 = max(z1, b.z + b.h)
        }
        st.tx = (x0 + x1) / 2f; st.ty = (y0 + y1) / 2f; st.tz = (z0 + z1) / 2f
        st.dist = (max(x1 - x0, max(y1 - y0, z1 - z0)) * 0.9f + 30f).coerceIn(30f, 900f)
    }

    private fun projectFile(): File = File(File(filesDir, "projects"), sanitize(st.doc.name) + ".map")

    private fun sanitize(n: String): String {
        val s = n.replace(Regex("[^\\p{L}\\p{N} _-]"), "_").trim()
        return if (s.isEmpty()) "map" else s
    }

    /** Something changed: write the JSON soon (about 8x per second while dragging) and snapshot for undo when things settle. */
    private fun changed() {
        if (jsonOpen) return
        if (!saveScheduled) {
            saveScheduled = true
            ui.postDelayed({ saveScheduled = false; saveNow() }, if (st.doc.boxes.size > 1500) 500L else 120L)
        }
        ui.removeCallbacks(undoRun)
        ui.postDelayed(undoRun, 700)
    }

    private val undoRun = Runnable { commitUndo() }

    private fun saveNow() {
        if (jsonOpen) return
        val text = st.doc.toJson(false)
        try {
            val f = projectFile()
            f.writeText(text)
            prefs.edit().putString("last", f.name).apply()
            val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            status.text = "\u25CF " + L.t("auto-saved ", "บันทึกอัตโนมัติ ") + t + "  \u00B7  " + st.doc.boxes.size + " boxes  \u00B7  " +
                (text.length / 1024) + " KB  \u00B7  " + f.name
        } catch (e: Exception) {
            status.text = L.t("Save failed: ", "บันทึกไม่ได้: ") + (e.message ?: "")
        }
    }

    // ------------------------------------------------------------------ undo / redo
    private fun commitUndo() {
        if (jsonOpen) return
        val s = st.doc.toJson(false)
        if (undo.isEmpty() || undo[undo.size - 1] != s) {
            undo.add(s)
            redo.clear()
            var total = 0L
            for (x in undo) total += x.length
            while (undo.size > 2 && (undo.size > 50 || total > 12000000L)) {
                total -= undo[0].length
                undo.removeAt(0)
            }
        }
    }

    private fun undoOp() {
        if (jsonOpen) return
        commitUndo()
        if (undo.size < 2) return
        redo.add(undo.removeAt(undo.size - 1))
        restore(undo[undo.size - 1])
    }

    private fun redoOp() {
        if (jsonOpen || redo.isEmpty()) return
        val s = redo.removeAt(redo.size - 1)
        undo.add(s)
        restore(s)
    }

    private fun restore(json: String) {
        try {
            val d = EDoc.parse(json)
            st.doc = d
            if (st.sel >= d.boxes.size) st.sel = -1
            refreshExplorer()
            rebuildProps()
            changed()
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ editing operations
    private fun snapV(v: Float): Float = if (st.snap > 0f) Math.round(v / st.snap) * st.snap else v

    private fun addBox() {
        if (jsonOpen) return
        val b = EBox(snapV(st.tx - 2f), snapV(st.ty - 2f), 0f, 4f, 4f, 4f, 0xFFB0B8C0.toInt())
        st.doc.boxes.add(b)
        refreshExplorer()
        selectBox(st.doc.boxes.size - 1, false)
        changed()
    }

    private fun dupBox() {
        if (jsonOpen) return
        val s = st.selBox() ?: return
        val c = s.copy2()
        c.x += max(s.w, 1f)
        st.doc.boxes.add(c)
        refreshExplorer()
        selectBox(st.doc.boxes.size - 1, false)
        changed()
    }

    private fun delBox() {
        if (jsonOpen) return
        val i = st.sel
        if (i < 0 || i >= st.doc.boxes.size) return
        st.doc.boxes.removeAt(i)
        st.sel = -1
        refreshExplorer()
        rebuildProps()
        changed()
    }

    private fun selectBox(i: Int, focusCam: Boolean) {
        st.sel = if (i >= 0 && i < st.doc.boxes.size) i else -1
        val b = st.selBox()
        if (focusCam && b != null) {
            st.tx = b.x + b.w / 2f; st.ty = b.y + b.d / 2f; st.tz = b.z + b.h / 2f
        }
        rebuildProps()
        adapter.notifyDataSetChanged()
        if (st.sel >= 0) explorer.setSelection(st.sel)
    }

    private fun fmt(v: Float): String = (Math.round(v * 100f) / 100.0).toString()

    private fun refreshExplorer() {
        items.clear()
        val kn = kindNames()
        for ((i, b) in st.doc.boxes.withIndex()) items.add("$i  ${kn[b.kind.coerceIn(0, 7)]}  ${fmt(b.w)}x${fmt(b.d)}x${fmt(b.h)}")
        adapter.notifyDataSetChanged()
    }

    // ------------------------------------------------------------------ properties panel
    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 11f
        v.setTextColor(0xFFBBBBBB.toInt())
        v.setPadding(dp(8), dp(6), dp(8), 0)
        return v
    }

    private fun title(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 15f
        v.setTypeface(v.typeface, Typeface.BOLD)
        v.setTextColor(Color.WHITE)
        v.setPadding(dp(8), dp(8), dp(8), dp(2))
        return v
    }

    private fun field(key: String, value: String, numeric: Boolean): EditText {
        val e = EditText(this)
        e.setText(value)
        e.setSingleLine()
        e.textSize = 13f
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(0xFF777777.toInt())
        e.setBackgroundColor(0xFF1B1B1B.toInt())
        e.setPadding(dp(8), dp(6), dp(8), dp(6))
        if (numeric) e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!updatingProps) applyField(key, s.toString())
            }
        })
        propFields.add(Pair(key, e))
        return e
    }

    private fun row(key: String, labelText: String, numeric: Boolean) {
        propsBox.addView(label(labelText))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(8), dp(2), dp(8), 0)
        val e = field(key, valueOf(key), numeric)
        if (key == "color" || key == "skyTop" || key == "skyBot" || key == "floorColor") {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.addView(e, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val sw = View(this)
            fun paintSwatch() { sw.background = bg(EDoc.col(e.text.toString(), 0xFF888888.toInt())) }
            paintSwatch()
            sw.setOnClickListener { pickColor(EDoc.col(e.text.toString(), 0xFFB0B8C0.toInt())) { c -> e.setText(EDoc.hex(c)) } }
            e.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { paintSwatch() }
            })
            val slp = LinearLayout.LayoutParams(dp(44), dp(34))
            slp.setMargins(dp(6), 0, 0, 0)
            line.addView(sw, slp)
            propsBox.addView(line, lp)
        } else {
            propsBox.addView(e, lp)
        }
    }

    private fun toggleLang() {
        if (jsonOpen) { toast(L.t("Close the JSON panel first", "ปิดหน้า JSON ก่อน")); return }
        commitUndo()
        saveNow()
        prefs.edit().putBoolean("th", !L.th).apply()
        recreate()
    }

    /** Colour dialog: tap the wheel, drag the brightness bar, or type a #RRGGBB code. */
    private fun pickColor(initial: Int, onPick: (Int) -> Unit) {
        var cur = initial or 0xFF000000.toInt()
        val wheel = ColorWheelView(this)
        val hexEdit = EditText(this)
        val swatch = View(this)
        val bright = SeekBar(this)
        bright.max = 100
        var busy = false
        fun apply(c: Int, from: Int) {
            busy = true
            cur = c or 0xFF000000.toInt()
            val h = FloatArray(3)
            Color.colorToHSV(cur, h)
            if (from != 0) wheel.setColor(cur)
            if (from != 1) bright.progress = Math.round(h[2] * 100f)
            if (from != 2) hexEdit.setText(EDoc.hex(cur))
            swatch.background = bg(cur)
            busy = false
        }
        wheel.onColor = { c -> if (!busy) apply(c, 0) }
        bright.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, pr: Int, user: Boolean) {
                if (!busy && user) { wheel.setValue(pr / 100f); apply(wheel.color(), 1) }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        hexEdit.setSingleLine()
        hexEdit.setTextColor(Color.WHITE)
        hexEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val t = s.toString()
                if (!busy && t.length == 7 && t[0] == '#') apply(EDoc.col(t, cur), 2)
            }
        })
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(12), dp(16), dp(4))
        box.addView(wheel, LinearLayout.LayoutParams(dp(240), dp(240)))
        val lab = TextView(this)
        lab.text = L.t("Brightness", "ความสว่าง")
        lab.setTextColor(0xFFBBBBBB.toInt())
        box.addView(lab)
        box.addView(bright, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.gravity = Gravity.CENTER_VERTICAL
        hrow.addView(hexEdit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val slp = LinearLayout.LayoutParams(dp(48), dp(34))
        slp.setMargins(dp(8), 0, 0, 0)
        hrow.addView(swatch, slp)
        box.addView(hrow)
        apply(cur, 3)
        AlertDialog.Builder(this).setTitle(L.t("Colour", "สี")).setView(box)
            .setPositiveButton("OK") { _, _ -> onPick(cur) }
            .setNegativeButton(L.t("Cancel", "ยกเลิก"), null).show()
    }

    private fun rebuildProps() {
        propsBox.removeAllViews()
        propFields.clear()
        updatingProps = true
        val b = st.selBox()
        val d = st.doc
        if (b != null) {
            propsBox.addView(title("Box #" + st.sel))
            for (k in listOf("x", "y", "z", "w", "d", "h")) row(k, k, true)
            row("color", "color #RRGGBB", false)
            propsBox.addView(label("kind"))
            val kb = tbtn(kindNames()[b.kind.coerceIn(0, 7)]) { kindDialog() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(8), dp(2), dp(8), 0)
            propsBox.addView(kb, lp)
            for (k in listOf("mx", "my", "mz", "period", "phase")) row(k, k, true)
        } else {
            propsBox.addView(title(L.t("Map settings", "ตั้งค่าแมพ")))
            row("name", "name", false)
            row("desc", "desc", false)
            row("sx", "spawn x", true)
            row("sy", "spawn y", true)
            row("skyTop", "sky top #RRGGBB", false)
            row("skyBot", "sky bottom #RRGGBB", false)
            val cb = CheckBox(this)
            cb.text = L.t("Floor", "พื้น")
            cb.setTextColor(Color.WHITE)
            cb.isChecked = d.hasFloor
            cb.setOnCheckedChangeListener { _, v -> if (!updatingProps) { st.doc.hasFloor = v; changed() } }
            propsBox.addView(cb)
            for (k in listOf("fx0", "fy0", "fx1", "fy1")) row(k, "floor $k", true)
            row("floorColor", "floor color #RRGGBB", false)
        }
        updatingProps = false
    }

    private fun kindDialog() {
        val b = st.selBox() ?: return
        AlertDialog.Builder(this).setTitle("kind").setItems(kindNames()) { _, i ->
            b.kind = i
            rebuildProps()
            refreshExplorer()
            changed()
        }.show()
    }

    private fun f3(v: Float): String = (Math.round(v * 1000f) / 1000.0).toString()

    private fun valueOf(key: String): String {
        val b = st.selBox()
        val d = st.doc
        if (b != null) {
            return when (key) {
                "x" -> f3(b.x); "y" -> f3(b.y); "z" -> f3(b.z)
                "w" -> f3(b.w); "d" -> f3(b.d); "h" -> f3(b.h)
                "color" -> EDoc.hex(b.color)
                "mx" -> f3(b.mx); "my" -> f3(b.my); "mz" -> f3(b.mz)
                "period" -> f3(b.period); "phase" -> f3(b.phase)
                else -> ""
            }
        }
        return when (key) {
            "name" -> d.name; "desc" -> d.desc
            "sx" -> f3(d.sx); "sy" -> f3(d.sy)
            "skyTop" -> EDoc.hex(d.skyTop); "skyBot" -> EDoc.hex(d.skyBot)
            "fx0" -> f3(d.fx0); "fy0" -> f3(d.fy0); "fx1" -> f3(d.fx1); "fy1" -> f3(d.fy1)
            "floorColor" -> EDoc.hex(d.floorColor)
            else -> ""
        }
    }

    private fun refreshPropValues() {
        updatingProps = true
        for ((k, e) in propFields) {
            if (e.hasFocus()) continue
            val v = valueOf(k)
            if (e.text.toString() != v) e.setText(v)
        }
        updatingProps = false
    }

    private fun applyField(key: String, s: String) {
        if (jsonOpen) return
        val b = st.selBox()
        val d = st.doc
        val f = s.toFloatOrNull()
        val isColor = s.length == 7 && s[0] == '#'
        if (b != null) {
            when (key) {
                "x" -> if (f != null) b.x = f
                "y" -> if (f != null) b.y = f
                "z" -> if (f != null) b.z = f
                "w" -> if (f != null && f > 0f) b.w = f
                "d" -> if (f != null && f > 0f) b.d = f
                "h" -> if (f != null && f > 0f) b.h = f
                "color" -> if (isColor) b.color = EDoc.col(s, b.color)
                "mx" -> if (f != null) b.mx = f
                "my" -> if (f != null) b.my = f
                "mz" -> if (f != null) b.mz = f
                "period" -> if (f != null) b.period = f
                "phase" -> if (f != null) b.phase = f
            }
        } else {
            when (key) {
                "name" -> d.name = s.take(40)
                "desc" -> d.desc = s.take(120)
                "sx" -> if (f != null) d.sx = f
                "sy" -> if (f != null) d.sy = f
                "skyTop" -> if (isColor) d.skyTop = EDoc.col(s, d.skyTop)
                "skyBot" -> if (isColor) d.skyBot = EDoc.col(s, d.skyBot)
                "fx0" -> if (f != null) d.fx0 = f
                "fy0" -> if (f != null) d.fy0 = f
                "fx1" -> if (f != null) d.fx1 = f
                "fy1" -> if (f != null) d.fy1 = f
                "floorColor" -> if (isColor) d.floorColor = EDoc.col(s, d.floorColor)
            }
        }
        changed()
    }

    // ------------------------------------------------------------------ JSON panel
    private fun buildJsonPanel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setBackgroundColor(0xFF202020.toInt())
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(4), dp(4), dp(4), dp(4))
        val ttl = TextView(this)
        ttl.text = L.t("JSON  (auto-write paused)", "JSON  (หยุดเขียนอัตโนมัติ)")
        ttl.textSize = 12f
        ttl.setTextColor(0xFFFFE066.toInt())
        head.addView(ttl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(tbtn(L.t("Format", "จัดรูป")) { formatJson() })
        head.addView(tbtn(L.t("Close", "ปิด")) { closeJson() })
        p.addView(head)
        jsonEdit = EditText(this)
        jsonEdit.typeface = Typeface.MONOSPACE
        jsonEdit.textSize = 10f
        jsonEdit.setTextColor(Color.WHITE)
        jsonEdit.setBackgroundColor(0xFF121212.toInt())
        jsonEdit.gravity = Gravity.TOP
        jsonEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        jsonEdit.setHorizontallyScrolling(false)
        jsonEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (jsonOpen) { ui.removeCallbacks(jsonRun); ui.postDelayed(jsonRun, 500) }
            }
        })
        val sv = ScrollView(this)
        sv.addView(jsonEdit)
        p.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        jsonErr = TextView(this)
        jsonErr.textSize = 11f
        jsonErr.setTextColor(0xFFFF6666.toInt())
        jsonErr.setPadding(dp(6), dp(3), dp(6), dp(3))
        p.addView(jsonErr)
        return p
    }

    private val jsonRun = Runnable { parseJsonText() }

    private fun parseJsonText() {
        if (!jsonOpen) return
        try {
            val d = EDoc.parse(jsonEdit.text.toString())
            jsonValid = true
            jsonErr.text = L.t("OK: ", "ถูกต้อง: ") + d.boxes.size + " boxes"
            jsonErr.setTextColor(0xFF66BB6A.toInt())
            st.doc = d
            if (st.sel >= d.boxes.size) st.sel = -1
            refreshExplorer()
        } catch (e: Exception) {
            jsonValid = false
            jsonErr.text = (e.message ?: "invalid JSON").take(300)
            jsonErr.setTextColor(0xFFFF6666.toInt())
        }
    }

    private fun toggleJson() { if (jsonOpen) closeJson() else openJson() }

    private fun openJson() {
        commitUndo()
        saveNow()
        jsonOpen = true
        jsonBackup = st.doc.toJson(false)
        jsonValid = true
        st.readOnly = true
        jsonErr.text = ""
        jsonEdit.setText(st.doc.toJson(true))
        propsScroll.visibility = View.GONE
        jsonPanel.visibility = View.VISIBLE
        rightPane.layoutParams.width = dp(430)
        rightPane.requestLayout()
    }

    private fun formatJson() {
        if (jsonOpen && jsonValid) jsonEdit.setText(st.doc.toJson(true))
    }

    private fun closeJson() {
        ui.removeCallbacks(jsonRun)
        parseJsonText()
        if (!jsonValid) {
            AlertDialog.Builder(this)
                .setTitle(L.t("JSON has an error", "JSON มีข้อผิดพลาด"))
                .setMessage(jsonErr.text)
                .setPositiveButton(L.t("Keep editing", "แก้ต่อ"), null)
                .setNegativeButton(L.t("Discard my edits", "ทิ้งที่แก้")) { _, _ ->
                    try { st.doc = EDoc.parse(jsonBackup) } catch (_: Exception) {}
                    finishJson()
                }.show()
            return
        }
        finishJson()
    }

    private fun finishJson() {
        jsonOpen = false
        st.readOnly = false
        if (st.sel >= st.doc.boxes.size) st.sel = -1
        jsonPanel.visibility = View.GONE
        propsScroll.visibility = View.VISIBLE
        rightPane.layoutParams.width = dp(250)
        rightPane.requestLayout()
        refreshExplorer()
        rebuildProps()
        commitUndo()
        changed()
        saveNow()
    }

    // ------------------------------------------------------------------ files / game link
    private fun fileMenu() {
        val names = arrayOf(
            L.t("New map", "แมพใหม่"), L.t("Open .map file", "เปิดไฟล์ .map"), L.t("Open a map from the game", "เปิดแมพจากเกม"),
            L.t("My projects", "โปรเจกต์ของฉัน"), L.t("Save as .map file", "บันทึกเป็นไฟล์ .map"), L.t("Test in game", "ทดลองเล่นในเกม")
        )
        AlertDialog.Builder(this).setTitle(L.t("File", "ไฟล์")).setItems(names) { _, i ->
            when (i) {
                0 -> { if (!jsonOpen) loadDoc(EDoc()) }
                1 -> pickFile()
                2 -> openFromGame()
                3 -> openProjects()
                4 -> saveAs()
                5 -> testInGame()
            }
        }.show()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "*/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, L.t("Choose a .map file", "เลือกไฟล์ .map")), 1)
    }

    private fun saveAs() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/octet-stream"
        i.putExtra(Intent.EXTRA_TITLE, sanitize(st.doc.name) + ".map")
        startActivityForResult(i, 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            if (req == 1) {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return
                loadDoc(EDoc.parse(text))
            } else if (req == 2) {
                commitUndo()
                contentResolver.openOutputStream(uri)?.use { it.write(st.doc.toJson(false).toByteArray(Charsets.UTF_8)) }
                toast(L.t("Saved", "บันทึกแล้ว"))
            }
        } catch (e: Exception) {
            toast(L.t("Error: ", "ผิดพลาด: ") + (e.message ?: ""))
        }
    }

    private fun openProjects() {
        val files = File(filesDir, "projects").listFiles()?.filter { it.name.endsWith(".map") }?.sortedByDescending { it.lastModified() }
        if (files == null || files.isEmpty()) { toast(L.t("No projects yet", "ยังไม่มีโปรเจกต์")); return }
        val names = files.map { it.nameWithoutExtension }.toTypedArray()
        AlertDialog.Builder(this).setTitle(L.t("My projects", "โปรเจกต์ของฉัน")).setItems(names) { _, i ->
            try { loadDoc(EDoc.parse(files[i].readText())) } catch (e: Exception) { toast(e.message ?: "error") }
        }.show()
    }

    /** Pulls maps from the game through its content provider (includes the built-in maps). */
    private fun openFromGame() {
        try {
            val c = contentResolver.query(Uri.parse("content://com.offlineblox.maps/maps"), null, null, null, null)
            val names = ArrayList<String>()
            if (c != null) {
                val ni = c.getColumnIndex("name")
                while (c.moveToNext()) names.add(c.getString(ni))
                c.close()
            }
            if (names.isEmpty()) { toast(L.t("Game not found", "ไม่พบเกม OfflineBlox")); return }
            AlertDialog.Builder(this).setTitle(L.t("Maps in the game", "แมพในเกม")).setItems(names.toTypedArray()) { _, i ->
                loadFromGame(names[i])
            }.show()
        } catch (e: Exception) {
            toast(L.t("Cannot reach the game: ", "เชื่อมเกมไม่ได้: ") + (e.message ?: ""))
        }
    }

    private fun loadFromGame(name: String) {
        try {
            val c = contentResolver.query(Uri.parse("content://com.offlineblox.maps/maps/" + Uri.encode(name)), null, null, null, null)
            var json: String? = null
            if (c != null) {
                val ji = c.getColumnIndex("json")
                if (c.moveToFirst()) json = c.getString(ji)
                c.close()
            }
            if (json.isNullOrEmpty()) { toast(L.t("Empty map data", "ไม่มีข้อมูลแมพ")); return }
            if (!jsonOpen) loadDoc(EDoc.parse(json))
        } catch (e: Exception) {
            toast(L.t("Error: ", "ผิดพลาด: ") + (e.message ?: ""))
        }
    }

    private fun testInGame() {
        if (jsonOpen) { toast(L.t("Close the JSON panel first", "ปิดหน้า JSON ก่อน")); return }
        commitUndo()
        saveNow()
        val i = Intent("com.offlineblox.IMPORT_MAP")
        i.setPackage("com.offlineblox")
        i.putExtra("json", st.doc.toJson(false))
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast(L.t("OfflineBlox game is not installed", "ยังไม่ได้ติดตั้งเกม OfflineBlox"))
        }
    }

    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val act = i.action ?: return
        if (act != Intent.ACTION_VIEW && act != Intent.ACTION_SEND) return
        try {
            var text: String? = i.getStringExtra(Intent.EXTRA_TEXT)
            if (text == null) {
                @Suppress("DEPRECATION")
                val uri = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: i.data
                if (uri != null) text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            }
            if (text != null && !jsonOpen) loadDoc(EDoc.parse(text))
        } catch (e: Exception) {
            toast(L.t("Not a valid .map file: ", "ไฟล์ .map ไม่ถูกต้อง: ") + (e.message ?: ""))
        }
    }
}
