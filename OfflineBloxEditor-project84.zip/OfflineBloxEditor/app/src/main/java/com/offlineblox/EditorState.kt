package com.offlineblox

import android.opengl.Matrix
import kotlin.math.cos
import kotlin.math.sin

/** Shared between the UI thread and the GL thread. */
class EditorState {
    @Volatile var doc = EDoc()
    @Volatile var sel = -1
    @Volatile var tool = 0          // 0 move, 1 scale
    @Volatile var snap = 1f
    @Volatile var readOnly = false
    @Volatile var yaw = 0.8f
    @Volatile var pitch = 0.55f
    @Volatile var dist = 70f
    @Volatile var tx = 0f
    @Volatile var ty = 0f
    @Volatile var tz = 0f
    @Volatile var vw = 1
    @Volatile var vh = 1

    fun selBox(): EBox? {
        val i = sel
        val b = doc.boxes
        return if (i >= 0 && i < b.size) b[i] else null
    }

    fun eye(o: FloatArray) {
        val cp = cos(pitch)
        val sp = sin(pitch)
        o[0] = tx - cos(yaw) * cp * dist
        o[1] = ty - sin(yaw) * cp * dist
        o[2] = tz + sp * dist
    }

    fun viewProj(out: FloatArray) {
        val e = FloatArray(3)
        eye(e)
        val proj = FloatArray(16)
        val view = FloatArray(16)
        Matrix.perspectiveM(proj, 0, 60f, vw.toFloat() / vh.coerceAtLeast(1), 0.5f, 3000f)
        Matrix.setLookAtM(view, 0, e[0], e[1], e[2], tx, ty, tz, 0f, 0f, 1f)
        Matrix.multiplyMM(out, 0, proj, 0, view, 0)
    }
}
