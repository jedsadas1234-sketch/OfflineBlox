package com.offlineblox

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Colour wheel: angle = hue, distance from the centre = saturation. Brightness is set from outside. */
class ColorWheelView(ctx: Context) : View(ctx) {
    var onColor: ((Int) -> Unit)? = null
    private val hsv = floatArrayOf(0f, 0f, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cx = 0f
    private var cy = 0f
    private var rad = 0f
    private var sweep: Shader? = null
    private var radial: Shader? = null
    private val d = resources.displayMetrics.density

    fun color(): Int = Color.HSVToColor(hsv)
    fun setColor(c: Int) { Color.colorToHSV(c, hsv); invalidate() }
    fun setValue(v: Float) { hsv[2] = v.coerceIn(0f, 1f); invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f
        cy = h / 2f
        rad = min(w, h) / 2f - 8f * d
        sweep = SweepGradient(cx, cy, intArrayOf(0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
            0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()), null)
        radial = RadialGradient(cx, cy, rad, 0xFFFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        p.style = Paint.Style.FILL
        p.shader = sweep
        c.drawCircle(cx, cy, rad, p)
        p.shader = radial
        c.drawCircle(cx, cy, rad, p)
        p.shader = null
        p.color = Color.argb(((1f - hsv[2]) * 255f).toInt(), 0, 0, 0)
        c.drawCircle(cx, cy, rad, p)
        val a = Math.toRadians(hsv[0].toDouble()).toFloat()
        val ix = cx + cos(a) * hsv[1] * rad
        val iy = cy + sin(a) * hsv[1] * rad
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f * d
        p.color = 0xFFFFFFFF.toInt()
        c.drawCircle(ix, iy, 9f * d, p)
        p.strokeWidth = 1.5f * d
        p.color = 0xFF000000.toInt()
        c.drawCircle(ix, iy, 11f * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            val dx = e.x - cx
            val dy = e.y - cy
            hsv[1] = min(1f, hypot(dx, dy) / rad)
            hsv[0] = ((Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()) + 360f) % 360f
            invalidate()
            onColor?.invoke(color())
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        return true
    }
}
