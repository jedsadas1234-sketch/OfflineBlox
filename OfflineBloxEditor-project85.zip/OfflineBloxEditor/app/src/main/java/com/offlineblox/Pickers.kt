package com.offlineblox

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Dialogs for choosing a texture or a model. Texts follow the editor language (L). */
object Pickers {
    private class Opt(val id: String?, val bmp: Bitmap?, val label: String, val glyph: String)

    private fun dp(a: Activity, v: Int): Int = (v * a.resources.displayMetrics.density).toInt()

    private fun rounded(a: Activity, c: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(c)
        g.cornerRadius = dp(a, 6).toFloat()
        return g
    }

    private fun cell(a: Activity, o: Opt, selected: Boolean, onClick: () -> Unit): View {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(a, 4), dp(a, 4), dp(a, 4), dp(a, 4))
        box.background = rounded(a, if (selected) 0xFF1F5FA8.toInt() else 0xFF3A3A3A.toInt())
        if (o.bmp != null) {
            val img = ImageView(a)
            img.setImageBitmap(o.bmp)
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            box.addView(img, LinearLayout.LayoutParams(dp(a, 64), dp(a, 64)))
        } else {
            val g = TextView(a)
            g.text = o.glyph
            g.textSize = 26f
            g.gravity = Gravity.CENTER
            g.setTextColor(Color.WHITE)
            g.background = rounded(a, 0xFF222222.toInt())
            box.addView(g, LinearLayout.LayoutParams(dp(a, 64), dp(a, 64)))
        }
        val tv = TextView(a)
        tv.text = o.label
        tv.textSize = 10f
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        box.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.setOnClickListener { onClick() }
        return box
    }

    private fun header(a: Activity, t: String): TextView {
        val v = TextView(a)
        v.text = t
        v.textSize = 12f
        v.setTextColor(0xFFFFE066.toInt())
        v.setPadding(dp(a, 4), dp(a, 10), dp(a, 4), dp(a, 4))
        return v
    }

    private fun addGrid(a: Activity, col: LinearLayout, opts: List<Opt>, isSel: (Opt) -> Boolean, pick: (Opt) -> Unit) {
        val per = 4
        var i = 0
        while (i < opts.size) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until per) {
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(a, 3), dp(a, 3), dp(a, 3), dp(a, 3))
                if (i + k < opts.size) {
                    val o = opts[i + k]
                    row.addView(cell(a, o, isSel(o)) { pick(o) }, lp)
                } else {
                    row.addView(View(a), lp)
                }
            }
            col.addView(row)
            i += per
        }
    }

    /**
     * Texture chooser. [current]: null = automatic (when [autoLabel] is given) or none; TEX_NONE = none; otherwise an id.
     * [onPick] gets null for "automatic", TEX_NONE for "none" or the id. [onImport] is called for "import a picture".
     */
    fun texture(a: Activity, doc: EDoc, current: String?, autoLabel: String?, onPick: (String?) -> Unit, onImport: () -> Unit) {
        val th = L.th
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(a, 8), dp(a, 4), dp(a, 8), dp(a, 4))
        var dlg: AlertDialog? = null

        val imp = TextView(a)
        imp.text = L.t("+ Import a picture from the phone", "+ นำเข้ารูปจากเครื่อง")
        imp.textSize = 13f
        imp.setTextColor(Color.WHITE)
        imp.setPadding(dp(a, 10), dp(a, 8), dp(a, 10), dp(a, 8))
        imp.background = rounded(a, 0xFF2E7D32.toInt())
        imp.setOnClickListener { dlg?.dismiss(); onImport() }
        col.addView(imp)

        val first = ArrayList<Opt>()
        if (autoLabel != null) first.add(Opt(null, null, autoLabel, "A"))
        first.add(Opt(TEX_NONE, null, L.t("None (plain colour)", "ไม่ใช้ (สีล้วน)"), "∅"))
        col.addView(header(a, L.t("Basic", "พื้นฐาน")))
        val none = current == null && autoLabel == null
        addGrid(a, col, first, { o ->
            if (o.id == null) current == null && autoLabel != null
            else o.id == TEX_NONE && (current == TEX_NONE || none)
        }) { o -> dlg?.dismiss(); onPick(o.id) }

        val mine = ArrayList<Opt>()
        for (t in doc.textures.values.sortedBy { it.name }) {
            if (t.id.startsWith("sys_")) continue
            mine.add(Opt(t.id, t.bmp, t.name, ""))
        }
        if (mine.isNotEmpty()) {
            col.addView(header(a, L.t("Pictures in this map", "รูปในแมพนี้")))
            addGrid(a, col, mine, { o -> o.id == current }) { o -> dlg?.dismiss(); onPick(o.id) }
        }

        val lib = ArrayList<Opt>()
        for (id in Tex.ids) {
            val t = Tex.builtin(id) ?: continue
            lib.add(Opt(id, t.bmp, Tex.label(id, th), ""))
        }
        col.addView(header(a, L.t("Built-in", "มีมาในตัว")))
        addGrid(a, col, lib, { o -> o.id == current }) { o -> dlg?.dismiss(); onPick(o.id) }

        val sv = ScrollView(a)
        sv.addView(col)
        dlg = AlertDialog.Builder(a).setTitle(L.t("Texture", "พื้นผิว (texture)")).setView(sv)
            .setNegativeButton(L.t("Cancel", "ยกเลิก"), null).show()
    }

    /** Model chooser: import a new one, pick one already in the map, or (when [allowNone]) remove it from the box. */
    fun model(a: Activity, doc: EDoc, current: String?, allowNone: Boolean, onPick: (String?) -> Unit, onImport: () -> Unit) {
        val names = ArrayList<String>()
        val ids = ArrayList<String?>()
        names.add(L.t("+ Import a model file…", "+ นำเข้าไฟล์โมเดล…"))
        ids.add("\u0000import")
        if (allowNone) {
            names.add(L.t("None (ordinary box)", "ไม่ใช้ (กล่องธรรมดา)"))
            ids.add(null)
        }
        for (m in doc.models.values.sortedBy { it.name }) {
            names.add((if (m.id == current) "✔ " else "") + m.name + "  (" + m.tris + L.t(" triangles", " สามเหลี่ยม") + ")")
            ids.add(m.id)
        }
        AlertDialog.Builder(a).setTitle(L.t("3D model", "โมเดล 3D")).setItems(names.toTypedArray()) { _, i ->
            val id = ids[i]
            if (id == "\u0000import") onImport() else onPick(id)
        }.setNegativeButton(L.t("Cancel", "ยกเลิก"), null).show()
    }
}
