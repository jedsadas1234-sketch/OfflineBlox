package com.offlineblox

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.Base64
import java.io.ByteArrayOutputStream

/** Built-in texture library (drawn by code, nothing to ship) and image helpers. */
object Tex {
    const val S = 64
    const val MAX_SIDE = 256

    private val cache = HashMap<String, ETex>()

    /** Library order = order in the picker. The first group belongs to the special block types. */
    val ids: List<String> = listOf(
        "sys_lava", "sys_mlava", "sys_bounce", "sys_move", "sys_blink", "sys_check", "sys_spawn", "sys_decor",
        "sys_grass", "sys_dirt", "sys_stone", "sys_brick", "sys_wood", "sys_sand", "sys_ice", "sys_metal",
        "sys_checker", "sys_white"
    )

    fun label(id: String, th: Boolean): String = when (id) {
        "sys_lava" -> if (th) "ลาวา" else "Lava"
        "sys_mlava" -> if (th) "ลาวาเลื่อน" else "Moving lava"
        "sys_bounce" -> if (th) "แท่นเด้ง" else "Bounce pad"
        "sys_move" -> if (th) "แท่นเลื่อน" else "Moving platform"
        "sys_blink" -> if (th) "แท่นกระพริบ" else "Blinking platform"
        "sys_check" -> if (th) "เช็กพอยต์" else "Checkpoint"
        "sys_spawn" -> if (th) "จุดเกิด (spawn)" else "Spawn"
        "sys_decor" -> if (th) "ตกแต่ง" else "Decor"
        "sys_grass" -> if (th) "หญ้า" else "Grass"
        "sys_dirt" -> if (th) "ดิน" else "Dirt"
        "sys_stone" -> if (th) "หิน" else "Stone"
        "sys_brick" -> if (th) "อิฐ" else "Brick"
        "sys_wood" -> if (th) "ไม้" else "Wood"
        "sys_sand" -> if (th) "ทราย" else "Sand"
        "sys_ice" -> if (th) "น้ำแข็ง" else "Ice"
        "sys_metal" -> if (th) "โลหะ" else "Metal"
        "sys_checker" -> if (th) "หมากรุก" else "Checker"
        "sys_white" -> if (th) "ขาวล้วน" else "White"
        else -> id
    }

    fun builtin(id: String): ETex? {
        if (!id.startsWith("sys_")) return null
        synchronized(cache) {
            val c = cache[id]
            if (c != null) return c
            if (!ids.contains(id)) return null
            val bmp = draw(id)
            val e = ETex(id, label(id, false), encode(bmp), bmp)
            cache[id] = e
            return e
        }
    }

    // ------------------------------------------------------------------ image helpers
    fun encode(bmp: Bitmap): String {
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    /** Removes a "data:image/png;base64," prefix and white space. */
    fun clean(s: String): String {
        var t = s
        if (t.startsWith("data:")) {
            val c = t.indexOf(',')
            if (c >= 0) t = t.substring(c + 1)
        }
        return t.trim()
    }

    fun decode(b64: String): Bitmap? {
        return try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }

    /** Decodes any picture the phone can read and shrinks it so the longest side is at most [maxSide]. */
    fun fromBytes(bytes: ByteArray, maxSide: Int = MAX_SIDE): Bitmap? {
        return try {
            val bo = BitmapFactory.Options()
            bo.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bo)
            if (bo.outWidth <= 0 || bo.outHeight <= 0) return null
            var sample = 1
            while (bo.outWidth / (sample * 2) >= maxSide && bo.outHeight / (sample * 2) >= maxSide) sample *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            o.inPreferredConfig = Bitmap.Config.ARGB_8888
            val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o) ?: return null
            shrink(src, maxSide)
        } catch (_: Exception) {
            null
        }
    }

    fun shrink(src: Bitmap, maxSide: Int): Bitmap {
        val m = Math.max(src.width, src.height)
        if (m <= maxSide) return src
        val k = maxSide.toFloat() / m
        val w = Math.max(1, Math.round(src.width * k))
        val h = Math.max(1, Math.round(src.height * k))
        return Bitmap.createScaledBitmap(src, w, h, true)
    }

    fun make(id: String, name: String, bmp: Bitmap): ETex = ETex(id, name, encode(bmp), bmp)

    fun uniqueId(prefix: String, taken: Collection<String>): String {
        var n = 1
        while (taken.contains(prefix + n)) n++
        return prefix + n
    }

    // ------------------------------------------------------------------ procedural drawing
    private fun hash(x: Int, y: Int, seed: Int): Float {
        var h = x * 374761393 + y * 668265263 + seed * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }

    private fun fill(c: Canvas, color: Int) {
        val p = Paint()
        p.color = color
        c.drawRect(0f, 0f, S.toFloat(), S.toFloat(), p)
    }

    private fun rect(c: Canvas, x0: Int, y0: Int, x1: Int, y1: Int, color: Int) {
        val p = Paint()
        p.color = color
        c.drawRect(x0.toFloat(), y0.toFloat(), x1.toFloat(), y1.toFloat(), p)
    }

    private fun cells(c: Canvas, cell: Int, seed: Int, pick: (Float) -> Int) {
        val n = S / cell
        for (j in 0 until n) for (i in 0 until n) {
            rect(c, i * cell, j * cell, (i + 1) * cell, (j + 1) * cell, pick(hash(i, j, seed)))
        }
    }

    private fun border(c: Canvas, w: Int, color: Int) {
        rect(c, 0, 0, S, w, color); rect(c, 0, S - w, S, S, color)
        rect(c, 0, 0, w, S, color); rect(c, S - w, 0, S, S, color)
    }

    private fun line(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float, w: Float, color: Int) {
        val p = Paint()
        p.color = color
        p.strokeWidth = w
        p.style = Paint.Style.STROKE
        c.drawLine(x0, y0, x1, y1, p)
    }

    private fun lavaBase(c: Canvas, seed: Int) {
        cells(c, 4, seed) { h ->
            if (h > 0.84f) 0xFFFFE066.toInt()
            else if (h > 0.56f) 0xFFFF8A1F.toInt()
            else if (h > 0.26f) 0xFFE8500A.toInt()
            else 0xFFA02C06.toInt()
        }
        cells(c, 8, seed + 1) { h -> if (h > 0.7f) 0x994A1604.toInt() else 0 }
    }

    private fun draw(id: String): Bitmap {
        val bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sf = S.toFloat()
        when (id) {
            "sys_lava" -> lavaBase(c, 11)
            "sys_mlava" -> {
                lavaBase(c, 23)
                for (k in 0 until 2) {
                    val oy = k * 32f
                    line(c, 18f, 10f + oy, 34f, 22f + oy, 4f, 0xCCFFF3B0.toInt())
                    line(c, 34f, 22f + oy, 18f, 34f + oy, 4f, 0xCCFFF3B0.toInt())
                    line(c, 40f, 10f + oy, 56f, 22f + oy, 4f, 0x99FFF3B0.toInt())
                    line(c, 56f, 22f + oy, 40f, 34f + oy, 4f, 0x99FFF3B0.toInt())
                }
            }
            "sys_bounce" -> {
                fill(c, 0xFFFF5FA2.toInt())
                cells(c, 8, 31) { h -> if (h > 0.6f) 0x30FFFFFF else 0 }
                border(c, 4, 0xFFFF9CC8.toInt())
                border(c, 1, 0xFFB02A66.toInt())
                val p = Paint()
                p.color = 0xFFFFFFFF.toInt()
                val path = Path()
                path.moveTo(32f, 10f); path.lineTo(50f, 32f); path.lineTo(39f, 32f)
                path.lineTo(39f, 52f); path.lineTo(25f, 52f); path.lineTo(25f, 32f)
                path.lineTo(14f, 32f); path.close()
                c.drawPath(path, p)
            }
            "sys_move" -> {
                fill(c, 0xFF4A6FA5.toInt())
                cells(c, 8, 41) { h -> if (h > 0.65f) 0x28FFFFFF else if (h < 0.2f) 0x28000000 else 0 }
                for (k in -8 until 16) {
                    val x = k * 8f
                    line(c, x, 0f, x + 6f, 6f, 5f, 0xFFFFC107.toInt())
                    line(c, x, sf - 6f, x + 6f, sf, 5f, 0xFFFFC107.toInt())
                }
                line(c, 8f, 32f, 56f, 32f, 4f, 0xFFFFFFFF.toInt())
                line(c, 8f, 32f, 18f, 24f, 4f, 0xFFFFFFFF.toInt()); line(c, 8f, 32f, 18f, 40f, 4f, 0xFFFFFFFF.toInt())
                line(c, 56f, 32f, 46f, 24f, 4f, 0xFFFFFFFF.toInt()); line(c, 56f, 32f, 46f, 40f, 4f, 0xFFFFFFFF.toInt())
            }
            "sys_blink" -> {
                fill(c, 0xFF5CC8FF.toInt())
                cells(c, 8, 51) { h -> if (h > 0.5f) 0x38FFFFFF else 0x18003C78 }
                for (k in 0 until 8) {
                    if (k % 2 == 0) {
                        rect(c, k * 8, 0, k * 8 + 8, 4, 0xFFFFFFFF.toInt())
                        rect(c, k * 8, S - 4, k * 8 + 8, S, 0xFFFFFFFF.toInt())
                        rect(c, 0, k * 8, 4, k * 8 + 8, 0xFFFFFFFF.toInt())
                        rect(c, S - 4, k * 8, S, k * 8 + 8, 0xFFFFFFFF.toInt())
                    }
                }
                line(c, 14f, 50f, 50f, 14f, 5f, 0xAAFFFFFF.toInt())
            }
            "sys_check" -> {
                cells(c, 16, 0) { _ -> 0xFF2E9E4F.toInt() }
                for (j in 0 until 4) for (i in 0 until 4) {
                    rect(c, i * 16, j * 16, i * 16 + 16, j * 16 + 16, if ((i + j) % 2 == 0) 0xFF2E9E4F.toInt() else 0xFF7BE095.toInt())
                }
                border(c, 3, 0xFFFFFFFF.toInt())
                line(c, 24f, 16f, 24f, 50f, 4f, 0xFFFFFFFF.toInt())
                val p = Paint()
                p.color = 0xFFFFEB3B.toInt()
                val path = Path()
                path.moveTo(26f, 16f); path.lineTo(46f, 24f); path.lineTo(26f, 32f); path.close()
                c.drawPath(path, p)
            }
            "sys_spawn" -> {
                fill(c, 0xFF2F8F4A.toInt())
                cells(c, 4, 61) { h -> if (h > 0.7f) 0x30FFFFFF else if (h < 0.25f) 0x30000000 else 0 }
                border(c, 3, 0xFFB8F5C8.toInt())
                rect(c, 12, 12, 52, 15, 0xFFFFFFFF.toInt()); rect(c, 12, 49, 52, 52, 0xFFFFFFFF.toInt())
                rect(c, 12, 12, 15, 52, 0xFFFFFFFF.toInt()); rect(c, 49, 12, 52, 52, 0xFFFFFFFF.toInt())
                rect(c, 29, 22, 35, 42, 0xFFFFFFFF.toInt()); rect(c, 22, 29, 42, 35, 0xFFFFFFFF.toInt())
            }
            "sys_decor" -> {
                fill(c, 0xFFE8DFC8.toInt())
                cells(c, 4, 71) { h -> if (h > 0.8f) 0xFFD8CDB0.toInt() else if (h < 0.1f) 0xFFF4EEDC.toInt() else 0 }
                border(c, 2, 0xFFCFC3A4.toInt())
                rect(c, 28, 28, 36, 36, 0xFFCFC3A4.toInt())
            }
            "sys_grass" -> {
                cells(c, 4, 81) { h ->
                    if (h > 0.7f) 0xFF6CC24A.toInt() else if (h > 0.35f) 0xFF58A93A.toInt() else 0xFF478C2D.toInt()
                }
                cells(c, 2, 82) { h -> if (h > 0.88f) 0xFF8BDB66.toInt() else 0 }
            }
            "sys_dirt" -> {
                cells(c, 4, 91) { h ->
                    if (h > 0.7f) 0xFF9A6B43.toInt() else if (h > 0.3f) 0xFF855A38.toInt() else 0xFF6E4A2E.toInt()
                }
                cells(c, 8, 92) { h -> if (h > 0.8f) 0xFF5A3C25.toInt() else 0 }
            }
            "sys_stone" -> {
                cells(c, 8, 101) { h ->
                    if (h > 0.66f) 0xFF9A9EA3.toInt() else if (h > 0.33f) 0xFF868A90.toInt() else 0xFF74787E.toInt()
                }
                cells(c, 4, 102) { h -> if (h > 0.85f) 0x30FFFFFF else if (h < 0.12f) 0x30000000 else 0 }
                border(c, 1, 0xFF5E6268.toInt())
            }
            "sys_brick" -> {
                fill(c, 0xFFBDB4A4.toInt())
                for (row in 0 until 4) {
                    val off = if (row % 2 == 0) 0 else 16
                    for (k in -1 until 3) {
                        val x0 = off + k * 32
                        val v = hash(k, row, 111)
                        val col = if (v > 0.66f) 0xFFC2593F.toInt() else if (v > 0.33f) 0xFFB5523B.toInt() else 0xFFA64A34.toInt()
                        rect(c, x0 + 1, row * 16 + 1, x0 + 31, row * 16 + 15, col)
                    }
                }
            }
            "sys_wood" -> {
                for (k in 0 until 4) {
                    val v = hash(k, 0, 121)
                    val col = if (v > 0.5f) 0xFFB98A55.toInt() else 0xFFA97B48.toInt()
                    rect(c, k * 16, 0, k * 16 + 16, S, col)
                    rect(c, k * 16, 0, k * 16 + 1, S, 0xFF6B4A28.toInt())
                    for (g in 0 until 6) {
                        val y = (hash(k, g, 122) * 60f).toInt()
                        rect(c, k * 16 + 3 + (g % 3) * 4, y, k * 16 + 5 + (g % 3) * 4, y + 6, 0x30000000)
                    }
                }
            }
            "sys_sand" -> {
                cells(c, 2, 131) { h ->
                    if (h > 0.7f) 0xFFEBD9A0.toInt() else if (h > 0.3f) 0xFFE0CC90.toInt() else 0xFFD3BE80.toInt()
                }
            }
            "sys_ice" -> {
                fill(c, 0xFFA8DCF5.toInt())
                cells(c, 8, 141) { h -> if (h > 0.6f) 0x40FFFFFF else if (h < 0.2f) 0x30609FC8 else 0 }
                line(c, 4f, 40f, 30f, 6f, 3f, 0xAAFFFFFF.toInt())
                line(c, 30f, 62f, 60f, 24f, 3f, 0x99FFFFFF.toInt())
                border(c, 1, 0xFF7FBCDD.toInt())
            }
            "sys_metal" -> {
                fill(c, 0xFF98A2AC.toInt())
                cells(c, 2, 151) { h -> if (h > 0.8f) 0x25FFFFFF else if (h < 0.15f) 0x20000000 else 0 }
                border(c, 3, 0xFF6E7882.toInt())
                border(c, 1, 0xFF4A525A.toInt())
                val p = Paint()
                p.color = 0xFF4A525A.toInt()
                c.drawCircle(9f, 9f, 3f, p); c.drawCircle(sf - 9f, 9f, 3f, p)
                c.drawCircle(9f, sf - 9f, 3f, p); c.drawCircle(sf - 9f, sf - 9f, 3f, p)
            }
            "sys_checker" -> {
                for (j in 0 until 4) for (i in 0 until 4) {
                    rect(c, i * 16, j * 16, i * 16 + 16, j * 16 + 16, if ((i + j) % 2 == 0) 0xFFF2F2F2.toInt() else 0xFF303030.toInt())
                }
            }
            else -> fill(c, 0xFFFFFFFF.toInt())
        }
        return bmp
    }
}
