package com.offlineblox

import android.graphics.Bitmap
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/** "no texture" marker stored in a box / map setting (a plain colour is drawn instead). */
const val TEX_NONE = "none"
/** Built-in texture used for the spawn marker unless the map says otherwise. */
const val TEX_SPAWN = "sys_spawn"
/** Placeholder written in place of big data in the JSON editor panel (the real data is kept). */
const val EMBEDDED = "<embedded>"

/** Texture that a block type gets when its box does not pick one itself. null = plain colour. */
fun autoTex(kind: Int): String? = when (kind) {
    1 -> "sys_lava"
    2 -> "sys_bounce"
    3 -> "sys_move"
    4 -> "sys_blink"
    5 -> "sys_check"
    6 -> "sys_mlava"
    7 -> "sys_decor"
    else -> null
}

/** An image stored inside the map. [png] is the base64 text that goes into the .map JSON. */
class ETex(val id: String, val name: String, val png: String, val bmp: Bitmap) {
    val sig: Long = png.length * 31L + png.hashCode().toLong()

    val json: JSONObject by lazy {
        val o = JSONObject()
        o.put("name", name)
        o.put("w", bmp.width)
        o.put("h", bmp.height)
        o.put("png", png)
        o
    }

    fun stub(): JSONObject {
        val o = JSONObject()
        o.put("name", name)
        o.put("w", bmp.width)
        o.put("h", bmp.height)
        o.put("png", EMBEDDED)
        return o
    }
}

/**
 * A triangle mesh converted from an outside model file. Positions in [v] are scaled into the
 * unit cube 0..1 on every axis; the box that uses the model stretches that cube to its w/d/h.
 * [uv] (optional) is 2 floats per vertex, [col] (optional) is one 0xRRGGBB int per vertex.
 * [sx],[sy],[sz] are the size a new box with this model starts with.
 */
class EModel(
    val id: String, val name: String, val v: FloatArray, val idx: IntArray,
    val uv: FloatArray?, val col: IntArray?, val sx: Float, val sy: Float, val sz: Float, val tex: String?
) {
    val tris: Int get() = idx.size / 3

    private fun r4(f: Float): Double = if (f.isNaN() || f.isInfinite()) 0.0 else Math.round(f * 10000f) / 10000.0
    private fun r3(f: Float): Double = Math.round(f * 1000f) / 1000.0

    private fun head(): JSONObject {
        val o = JSONObject()
        o.put("name", name)
        o.put("size", JSONArray().put(r3(sx)).put(r3(sy)).put(r3(sz)))
        if (tex != null) o.put("tex", tex)
        return o
    }

    val json: JSONObject by lazy {
        val o = head()
        val va = JSONArray()
        for (f in v) va.put(r4(f))
        o.put("v", va)
        val ia = JSONArray()
        for (i in idx) ia.put(i)
        o.put("i", ia)
        if (uv != null) {
            val ua = JSONArray()
            for (f in uv) ua.put(r4(f))
            o.put("uv", ua)
        }
        if (col != null) {
            val ca = JSONArray()
            for (c in col) ca.put(c and 0xFFFFFF)
            o.put("c", ca)
        }
        o
    }

    fun stub(): JSONObject {
        val o = head()
        o.put("tris", tris)
        o.put("embedded", true)
        return o
    }
}

class EBox(
    var x: Float, var y: Float, var z: Float, var w: Float, var d: Float, var h: Float, var color: Int,
    var kind: Int = 0, var mx: Float = 0f, var my: Float = 0f, var mz: Float = 0f,
    var period: Float = 0f, var phase: Float = 0f, var extra: JSONObject? = null,
    /** texture id: null = automatic (follows the block type / model), TEX_NONE = plain colour */
    var tex: String? = null,
    /** multiply the texture by [color] */
    var tint: Boolean = false,
    /** stretch the picture over each face once instead of repeating it */
    var fit: Boolean = false,
    /** world units covered by one repeat of the picture (when not [fit]) */
    var tile: Float = 4f,
    /** id of an entry of EDoc.models, or null for an ordinary box */
    var model: String? = null
) {
    fun copy2(): EBox = EBox(
        x, y, z, w, d, h, color, kind, mx, my, mz, period, phase,
        extra?.let { JSONObject(it.toString()) }, tex, tint, fit, tile, model
    )
}

/** The map in memory. toJson()/parse() are the .map format of the game; unknown fields are kept. */
class EDoc {
    var version = 1
    var name = "New Map"
    var desc = "Made with OfflineBlox Editor"
    var sx = 0f
    var sy = 0f
    var skyTop = 0xFF4A90D9.toInt()
    var skyBot = 0xFFBFE0FF.toInt()
    var hasFloor = true
    var fx0 = -100f
    var fy0 = -100f
    var fx1 = 100f
    var fy1 = 100f
    var floorColor = 0xFF7A7F85.toInt()
    /** null or TEX_NONE = plain colour */
    var floorTex: String? = null
    var floorTint = false
    var floorTile = 4f
    /** null = built-in spawn texture, TEX_NONE = plain coloured marker */
    var spawnTex: String? = null
    val boxes = CopyOnWriteArrayList<EBox>()
    val textures = ConcurrentHashMap<String, ETex>()
    val models = ConcurrentHashMap<String, EModel>()
    var extra: JSONObject? = null

    /** Looks in the map first, then in the built-in library. */
    fun texOf(id: String?): ETex? {
        if (id == null || id == TEX_NONE) return null
        return textures[id] ?: Tex.builtin(id)
    }

    /** Texture a box shows when it did not pick one. */
    fun defaultTexOf(b: EBox): String? {
        val m = b.model
        if (m != null) {
            val md = models[m]
            if (md != null) return md.tex
        }
        return autoTex(b.kind)
    }

    /** The texture a box really shows (null = plain colour). */
    fun texIdOf(b: EBox): String? {
        val t = b.tex
        if (t == TEX_NONE) return null
        if (t != null) return t
        return defaultTexOf(b)
    }

    fun spawnTexId(): String? = when (spawnTex) {
        null -> TEX_SPAWN
        TEX_NONE -> null
        else -> spawnTex
    }

    fun floorTexId(): String? {
        val t = floorTex
        return if (t == null || t == TEX_NONE) null else t
    }

    /** [strip]: replace big embedded data by a short placeholder (used by the JSON editor panel). */
    fun toJson(pretty: Boolean, strip: Boolean = false): String {
        val used = LinkedHashSet<String>()
        val usedModels = LinkedHashSet<String>()
        val o = JSONObject()
        o.put("version", version)
        o.put("name", name)
        o.put("desc", desc)
        o.put("spawn", JSONArray().put(r(sx)).put(r(sy)))
        o.put("sky", JSONArray().put(hex(skyTop)).put(hex(skyBot)))
        val sp = spawnTexId()
        if (sp != null) { o.put("spawnTex", sp); used.add(sp) } else o.put("spawnTex", TEX_NONE)
        if (hasFloor) {
            val fo = JSONObject()
            fo.put("rect", JSONArray().put(r(fx0)).put(r(fy0)).put(r(fx1)).put(r(fy1)))
            fo.put("color", hex(floorColor))
            val ft = floorTexId()
            if (ft != null) {
                fo.put("tex", ft)
                used.add(ft)
                if (floorTint) fo.put("tint", true)
                if (floorTile != 4f) fo.put("tile", r(floorTile))
            }
            o.put("floor", fo)
        }
        val arr = JSONArray()
        for (b in boxes) {
            val j = JSONObject()
            j.put("x", r(b.x)); j.put("y", r(b.y)); j.put("z", r(b.z))
            j.put("w", r(b.w)); j.put("d", r(b.d)); j.put("h", r(b.h))
            j.put("color", hex(b.color))
            if (b.kind != 0) j.put("kind", b.kind)
            if (b.mx != 0f || b.my != 0f || b.mz != 0f) j.put("move", JSONArray().put(r(b.mx)).put(r(b.my)).put(r(b.mz)))
            if (b.period != 0f) j.put("period", r(b.period))
            if (b.phase != 0f) j.put("phase", r(b.phase))
            val mid = b.model
            if (mid != null) {
                j.put("model", mid)
                if (models.containsKey(mid)) usedModels.add(mid)
            }
            val rt = texIdOf(b)
            if (rt != null) {
                j.put("tex", rt)
                used.add(rt)
                if (b.tint) j.put("tint", true)
                if (b.fit) j.put("fit", true)
                if (b.tile != 4f) j.put("tile", r(b.tile))
            } else if (b.tex == TEX_NONE && defaultTexOf(b) != null) {
                j.put("tex", TEX_NONE)
            }
            putExtra(j, b.extra)
            arr.put(j)
        }
        o.put("boxes", arr)
        if (usedModels.isNotEmpty()) {
            val mj = JSONObject()
            for (id in usedModels.sorted()) {
                val m = models[id] ?: continue
                m.tex?.let { used.add(it) }
                mj.put(id, if (strip) m.stub() else m.json)
            }
            o.put("models", mj)
        }
        if (used.isNotEmpty()) {
            val tj = JSONObject()
            for (id in used.sorted()) {
                val t = texOf(id) ?: continue
                tj.put(id, if (strip) t.stub() else t.json)
            }
            if (tj.length() > 0) o.put("textures", tj)
        }
        putExtra(o, extra)
        return if (pretty) o.toString(2) else o.toString()
    }

    companion object {
        private val KNOWN_TOP = setOf("version", "name", "desc", "spawn", "spawnTex", "sky", "floor", "boxes", "textures", "models")
        private val KNOWN_BOX = setOf("x", "y", "z", "w", "d", "h", "color", "kind", "move", "period", "phase", "tex", "tint", "fit", "tile", "model")
        const val MAX_TEXTURES = 96
        const val MAX_MODELS = 48
        const val MAX_MODEL_TRIS = 60000

        fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

        fun col(s: String?, def: Int): Int {
            if (s.isNullOrEmpty()) return def
            return try { Color.parseColor(s) } catch (_: Exception) { def }
        }

        private fun r(v: Float): Double = Math.round(v * 1000f) / 1000.0

        private fun putExtra(o: JSONObject, ex: JSONObject?) {
            if (ex == null) return
            val ks = ex.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                o.put(k, ex.get(k))
            }
        }

        private fun optId(o: JSONObject, key: String): String? {
            val s = o.optString(key, "")
            return if (s.isEmpty() || s == "null") null else s.take(60)
        }

        /**
         * Throws if the text is not valid JSON or is too big.
         * [base]: the doc the text was made from with strip = true; its images / models fill the placeholders.
         */
        fun parse(text: String, base: EDoc? = null): EDoc {
            if (text.length > 24000000) throw IllegalArgumentException("file too large")
            val o = JSONObject(text)
            val d = EDoc()
            d.version = o.optInt("version", 1)
            d.name = o.optString("name", "Map").take(40)
            d.desc = o.optString("desc", "").take(120)
            val sp = o.optJSONArray("spawn")
            d.sx = (sp?.optDouble(0, 0.0) ?: 0.0).toFloat()
            d.sy = (sp?.optDouble(1, 0.0) ?: 0.0).toFloat()
            val sk = o.optJSONArray("sky")
            d.skyTop = col(sk?.optString(0, ""), 0xFF4A90D9.toInt())
            d.skyBot = col(sk?.optString(1, ""), 0xFFBFE0FF.toInt())
            val st = optId(o, "spawnTex")
            d.spawnTex = if (st == TEX_SPAWN) null else st
            val fl = o.optJSONObject("floor")
            d.hasFloor = fl != null
            if (fl != null) {
                val rc = fl.optJSONArray("rect")
                if (rc != null && rc.length() >= 4) {
                    d.fx0 = rc.getDouble(0).toFloat(); d.fy0 = rc.getDouble(1).toFloat()
                    d.fx1 = rc.getDouble(2).toFloat(); d.fy1 = rc.getDouble(3).toFloat()
                }
                d.floorColor = col(fl.optString("color", ""), d.floorColor)
                d.floorTex = optId(fl, "tex")
                d.floorTint = fl.optBoolean("tint", false)
                d.floorTile = fl.optDouble("tile", 4.0).toFloat().coerceIn(0.05f, 1000f)
            }

            // embedded images
            val tj = o.optJSONObject("textures")
            if (tj != null) {
                val ks = tj.keys()
                while (ks.hasNext()) {
                    val id = ks.next()
                    if (d.textures.size >= MAX_TEXTURES) break
                    val e = tj.optJSONObject(id) ?: continue
                    val data = e.optString("png", "")
                    if (data == EMBEDDED) {
                        val old = base?.textures?.get(id)
                        if (old != null) d.textures[id] = old
                        continue
                    }
                    val clean = Tex.clean(data)
                    val bmp = Tex.decode(clean) ?: continue
                    d.textures[id] = ETex(id, e.optString("name", id).take(40), clean, bmp)
                }
            }

            // embedded models
            val mj = o.optJSONObject("models")
            if (mj != null) {
                val ks = mj.keys()
                while (ks.hasNext()) {
                    val id = ks.next()
                    if (d.models.size >= MAX_MODELS) break
                    val e = mj.optJSONObject(id) ?: continue
                    if (!e.has("v")) {
                        val old = base?.models?.get(id)
                        if (old != null) d.models[id] = old
                        continue
                    }
                    val m = parseModel(id, e) ?: continue
                    d.models[id] = m
                }
            }

            val arr = o.optJSONArray("boxes") ?: JSONArray()
            if (arr.length() > 8000) throw IllegalArgumentException("too many boxes (max 8000)")
            for (i in 0 until arr.length()) {
                val j = arr.getJSONObject(i)
                val mv = j.optJSONArray("move")
                var ex: JSONObject? = null
                val ks = j.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    if (k !in KNOWN_BOX) {
                        if (ex == null) ex = JSONObject()
                        ex.put(k, j.get(k))
                    }
                }
                d.boxes.add(EBox(
                    j.optDouble("x", 0.0).toFloat(), j.optDouble("y", 0.0).toFloat(), j.optDouble("z", 0.0).toFloat(),
                    j.optDouble("w", 1.0).toFloat(), j.optDouble("d", 1.0).toFloat(), j.optDouble("h", 1.0).toFloat(),
                    col(j.optString("color", ""), 0xFFB0B8C0.toInt()),
                    j.optInt("kind", 0).coerceIn(0, 7),
                    (mv?.optDouble(0, 0.0) ?: 0.0).toFloat(), (mv?.optDouble(1, 0.0) ?: 0.0).toFloat(), (mv?.optDouble(2, 0.0) ?: 0.0).toFloat(),
                    j.optDouble("period", 0.0).toFloat(), j.optDouble("phase", 0.0).toFloat(), ex,
                    optId(j, "tex"), j.optBoolean("tint", false), j.optBoolean("fit", false),
                    j.optDouble("tile", 4.0).toFloat().coerceIn(0.05f, 1000f), optId(j, "model")
                ))
            }
            // a texture that is just what the block would show anyway means "automatic"
            for (b in d.boxes) {
                val t = b.tex ?: continue
                val dt = d.defaultTexOf(b)
                if (t == dt || (t == TEX_NONE && dt == null)) b.tex = null
            }
            var ext: JSONObject? = null
            val tk = o.keys()
            while (tk.hasNext()) {
                val k = tk.next()
                if (k !in KNOWN_TOP) {
                    if (ext == null) ext = JSONObject()
                    ext.put(k, o.get(k))
                }
            }
            d.extra = ext
            return d
        }

        /** Returns null when the model data is broken (the rest of the map still loads). */
        private fun parseModel(id: String, e: JSONObject): EModel? {
            val va = e.optJSONArray("v") ?: return null
            val ia = e.optJSONArray("i") ?: return null
            if (va.length() < 9 || va.length() % 3 != 0) return null
            if (ia.length() < 3 || ia.length() % 3 != 0 || ia.length() > 3 * MAX_MODEL_TRIS) return null
            val nv = va.length() / 3
            val v = FloatArray(va.length())
            for (k in v.indices) v[k] = va.optDouble(k, 0.0).toFloat()
            val idx = IntArray(ia.length())
            for (k in idx.indices) {
                val n = ia.optInt(k, -1)
                if (n < 0 || n >= nv) return null
                idx[k] = n
            }
            val ua = e.optJSONArray("uv")
            var uv: FloatArray? = null
            if (ua != null && ua.length() == nv * 2) {
                val u = FloatArray(nv * 2)
                for (k in u.indices) u[k] = ua.optDouble(k, 0.0).toFloat()
                uv = u
            }
            val ca = e.optJSONArray("c")
            var col: IntArray? = null
            if (ca != null && ca.length() == nv) {
                val c = IntArray(nv)
                for (k in c.indices) c[k] = ca.optInt(k, 0xFFFFFF) and 0xFFFFFF
                col = c
            }
            val sz = e.optJSONArray("size")
            val sx = (sz?.optDouble(0, 4.0) ?: 4.0).toFloat().coerceIn(0.01f, 2000f)
            val sy = (sz?.optDouble(1, 4.0) ?: 4.0).toFloat().coerceIn(0.01f, 2000f)
            val sz3 = (sz?.optDouble(2, 4.0) ?: 4.0).toFloat().coerceIn(0.01f, 2000f)
            return EModel(id, e.optString("name", id).take(40), v, idx, uv, col, sx, sy, sz3, optId(e, "tex"))
        }
    }
}
