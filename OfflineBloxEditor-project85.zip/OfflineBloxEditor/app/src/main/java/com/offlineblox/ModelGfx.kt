package com.offlineblox

import android.opengl.GLES30
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Draws EModel meshes (own small shader, same lighting and fog as the box shader).
 * Everything here runs on the GL thread. A mesh is uploaded once and re-uploaded only when the EModel object changes.
 */
class ModelGfx {
    companion object {
        private const val TAG = "OfflineBlox"

        private const val VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;
layout(location = 3) in vec4 aCol;
uniform mat4 uVP;
uniform vec3 uScale;
uniform vec3 uOff;
out vec3 vN;
out vec2 vUV;
out vec4 vCol;
out vec3 vWorld;
out float vDist;
void main() {
  vec3 wp = aPos * uScale + uOff;
  vWorld = wp;
  vN = normalize(aNormal / uScale);
  vUV = aUV;
  vCol = aCol;
  gl_Position = uVP * vec4(wp, 1.0);
  vDist = gl_Position.w;
}
"""

        private const val FS = """#version 300 es
precision highp float;
in vec3 vN;
in vec2 vUV;
in vec4 vCol;
in vec3 vWorld;
in float vDist;
uniform sampler2D uTex;
uniform float uHasTex;
uniform float uWorldUV;
uniform float uTile;
uniform vec3 uTint;
uniform vec3 uLightDir;
uniform vec3 uFog;
uniform vec2 uFogRange;
out vec4 fragColor;
void main() {
  vec3 n = normalize(vN);
  if (!gl_FrontFacing) { n = -n; }
  vec3 base = vCol.rgb * uTint;
  if (uHasTex > 0.5) {
    if (uWorldUV > 0.5) {
      vec3 an = abs(n);
      vec2 w;
      if (an.z > 0.5) { w = vWorld.xy; } else if (an.x > 0.5) { w = vWorld.yz; } else { w = vWorld.xz; }
      base *= texture(uTex, w / uTile).rgb;
    } else if (vUV.x > -50.0) {
      base *= texture(uTex, vUV).rgb;
    }
  }
  float ndl = max(dot(n, uLightDir), 0.0);
  float hemi = 0.5 + 0.5 * n.z;
  float light = (0.36 + 0.14 * hemi) + 0.62 * ndl;
  vec3 col = base * light;
  float fog = clamp((vDist - uFogRange.x) / (uFogRange.y - uFogRange.x), 0.0, 1.0);
  col = mix(col, uFog, fog);
  fragColor = vec4(col, 1.0);
}
"""
    }

    private class Mesh(val src: EModel, val vao: Int, val vbo: Int, val count: Int)

    var ok = false
    private var prog = 0
    private val meshes = HashMap<String, Mesh>()
    private var uVP = 0; private var uScale = 0; private var uOff = 0; private var uTex = 0
    private var uHasTex = 0; private var uWorldUV = 0; private var uTile = 0; private var uTint = 0
    private var uLightDir = 0; private var uFog = 0; private var uFogRange = 0

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val st = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) {
            Log.e(TAG, GLES30.glGetShaderInfoLog(s))
            GLES30.glDeleteShader(s)
            return 0
        }
        return s
    }

    fun init() {
        val a = compile(GLES30.GL_VERTEX_SHADER, VS)
        val b = compile(GLES30.GL_FRAGMENT_SHADER, FS)
        if (a == 0 || b == 0) return
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, a)
        GLES30.glAttachShader(p, b)
        GLES30.glLinkProgram(p)
        val st = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) {
            Log.e(TAG, GLES30.glGetProgramInfoLog(p))
            return
        }
        prog = p
        uVP = GLES30.glGetUniformLocation(p, "uVP")
        uScale = GLES30.glGetUniformLocation(p, "uScale")
        uOff = GLES30.glGetUniformLocation(p, "uOff")
        uTex = GLES30.glGetUniformLocation(p, "uTex")
        uHasTex = GLES30.glGetUniformLocation(p, "uHasTex")
        uWorldUV = GLES30.glGetUniformLocation(p, "uWorldUV")
        uTile = GLES30.glGetUniformLocation(p, "uTile")
        uTint = GLES30.glGetUniformLocation(p, "uTint")
        uLightDir = GLES30.glGetUniformLocation(p, "uLightDir")
        uFog = GLES30.glGetUniformLocation(p, "uFog")
        uFogRange = GLES30.glGetUniformLocation(p, "uFogRange")
        ok = true
    }

    fun begin(vp: FloatArray, light: FloatArray, fog: Int, near: Float, far: Float) {
        if (!ok) return
        GLES30.glUseProgram(prog)
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0)
        GLES30.glUniform3f(uLightDir, light[0], light[1], light[2])
        GLES30.glUniform3f(uFog, ((fog shr 16) and 255) / 255f, ((fog shr 8) and 255) / 255f, (fog and 255) / 255f)
        GLES30.glUniform2f(uFogRange, near, far)
        GLES30.glUniform1i(uTex, 0)
    }

    private fun upload(m: EModel): Mesh {
        val tris = m.idx.size / 3
        val stride = 36
        val bb = ByteBuffer.allocateDirect(tris * 3 * stride).order(ByteOrder.nativeOrder())
        for (t in 0 until tris) {
            val ia = m.idx[t * 3]
            val ib = m.idx[t * 3 + 1]
            val ic = m.idx[t * 3 + 2]
            val ax = m.v[ia * 3]; val ay = m.v[ia * 3 + 1]; val az = m.v[ia * 3 + 2]
            val bx = m.v[ib * 3]; val by = m.v[ib * 3 + 1]; val bz = m.v[ib * 3 + 2]
            val cx = m.v[ic * 3]; val cy = m.v[ic * 3 + 1]; val cz = m.v[ic * 3 + 2]
            val ux = bx - ax; val uy = by - ay; val uz = bz - az
            val wx = cx - ax; val wy = cy - ay; val wz = cz - az
            var nx = uy * wz - uz * wy
            var ny = uz * wx - ux * wz
            var nz = ux * wy - uy * wx
            val l = Math.sqrt((nx * nx + ny * ny + nz * nz).toDouble()).toFloat()
            if (l > 1e-12f) { nx /= l; ny /= l; nz /= l } else { nx = 0f; ny = 0f; nz = 1f }
            for (k in 0 until 3) {
                val vi = if (k == 0) ia else if (k == 1) ib else ic
                bb.putFloat(m.v[vi * 3]); bb.putFloat(m.v[vi * 3 + 1]); bb.putFloat(m.v[vi * 3 + 2])
                bb.putFloat(nx); bb.putFloat(ny); bb.putFloat(nz)
                val uvs = m.uv
                if (uvs != null) { bb.putFloat(uvs[vi * 2]); bb.putFloat(uvs[vi * 2 + 1]) } else { bb.putFloat(0f); bb.putFloat(0f) }
                val cs = m.col
                val c = if (cs != null) cs[vi] else 0xFFFFFF
                bb.put(((c shr 16) and 255).toByte()); bb.put(((c shr 8) and 255).toByte()); bb.put((c and 255).toByte()); bb.put(255.toByte())
            }
        }
        bb.position(0)
        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        val vao = ids[0]
        GLES30.glBindVertexArray(vao)
        val bufs = IntArray(1)
        GLES30.glGenBuffers(1, bufs, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, bufs[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, tris * 3 * stride, bb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, stride, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, stride, 24)
        GLES30.glEnableVertexAttribArray(3)
        GLES30.glVertexAttribPointer(3, 4, GLES30.GL_UNSIGNED_BYTE, true, stride, 32)
        return Mesh(m, vao, bufs[0], tris * 3)
    }

    private fun meshFor(m: EModel): Mesh {
        val old = meshes[m.id]
        if (old != null && old.src === m) return old
        if (old != null) free(old)
        val fresh = upload(m)
        meshes[m.id] = fresh
        return fresh
    }

    private fun free(m: Mesh) {
        GLES30.glDeleteBuffers(1, intArrayOf(m.vbo), 0)
        GLES30.glDeleteVertexArrays(1, intArrayOf(m.vao), 0)
    }

    /** [tex] = GL texture name or 0, [worldUV] = project the picture from world space instead of the model's own UV. */
    fun draw(m: EModel, x: Float, y: Float, z: Float, w: Float, d: Float, h: Float, tint: Int, tex: Int, worldUV: Boolean, tile: Float) {
        if (!ok) return
        val mesh = meshFor(m)
        GLES30.glBindVertexArray(mesh.vao)
        GLES30.glUniform3f(uScale, Math.max(w, 0.001f), Math.max(d, 0.001f), Math.max(h, 0.001f))
        GLES30.glUniform3f(uOff, x, y, z)
        GLES30.glUniform3f(uTint, ((tint shr 16) and 255) / 255f, ((tint shr 8) and 255) / 255f, (tint and 255) / 255f)
        if (tex != 0) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        }
        GLES30.glUniform1f(uHasTex, if (tex != 0) 1f else 0f)
        GLES30.glUniform1f(uWorldUV, if (worldUV) 1f else 0f)
        GLES30.glUniform1f(uTile, tile)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, mesh.count)
    }

    /** Frees meshes whose model is gone from the map. */
    fun prune(doc: EDoc) {
        val it = meshes.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (doc.models[e.key] !== e.value.src && !doc.models.containsKey(e.key)) {
                free(e.value)
                it.remove()
            }
        }
    }
}
