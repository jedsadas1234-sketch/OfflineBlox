# .map format additions (editor v0.2)

All new fields are optional. Old maps load unchanged; unknown fields are kept.

## Top level
- `spawnTex`: texture id for the spawn marker (`"sys_spawn"` default, `"none"` = plain).
- `textures`: `{ id: { "name", "w", "h", "png": "<base64 PNG, no data: prefix>" } }`. Only textures used by the map are embedded, built-in `sys_*` ones included.
- `models`: `{ id: { "name", "size": [w,d,h], "v": [x,y,z,...], "i": [a,b,c,...], "uv"?: [u,v,...], "c"?: [0xRRGGBB,...], "tex"?: id } }`

## floor
`tex`, `tint` (bool), `tile` (units per repeat, default 4).

## box
- `tex`: texture id (`"none"` = plain colour). The editor always writes the resolved id, e.g. a Lava block (`kind` 1) gets `"sys_lava"` unless another one is picked.
- `tint`: multiply texture by `color` (default false: texture is drawn as is).
- `fit`: true = stretch the picture once over each face; false = repeat in world space every `tile` units (default 4), projected by face normal (z: xy, x: yz, else xz).
- `model`: id in `models`.

## Default textures by `kind`
1 `sys_lava`, 2 `sys_bounce`, 3 `sys_move`, 4 `sys_blink`, 5 `sys_check`, 6 `sys_mlava`, 7 `sys_decor`, 0 none. Spawn: `sys_spawn`.

## Model rules
- `v` is scaled into the unit cube 0..1 on each axis. A box with `model` stretches that cube to its `w,d,h` and puts the min corner at `x,y,z` (so selecting, moving and scaling work like a normal box).
- Z is up. `i` = triangle list, 3 indices each. Flat shading: compute face normals; light both sides.
- `uv` origin top-left (same as image row 0). A UV of `-100,-100` = "do not sample the texture here" (flat vertex colour).
- Final colour = `c` (or white) * texture (if any) * box `color` (only if `tint`).
- Limits: 60000 triangles per model, 48 models, 96 textures, 8000 boxes. Editor imports at most 30000 triangles (simplifies above that).

The game must read these fields to show textures / models; the editor preview already does.
