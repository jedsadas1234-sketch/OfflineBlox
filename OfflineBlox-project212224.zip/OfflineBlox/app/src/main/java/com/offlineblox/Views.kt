package com.offlineblox

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Rotating 3D preview of the avatar (character screen / home). */
class AvatarPreview(ctx: Context, get: () -> Avatar) : GLSurfaceView(ctx) {
    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 0, 24, 0)
        setRenderer(PreviewRenderer(get))
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}

private class PreviewRenderer(private val get: () -> Avatar) : GLSurfaceView.Renderer {
    private var gfx = Gfx()
    private var rig = Rig(gfx)
    private var tex = 0
    private var texKey = ""
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val ident = FloatArray(16)
    private val model = FloatArray(16)
    private val light = floatArrayOf(0.42f, 0.30f, 0.86f)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        gfx = Gfx()
        gfx.init()
        rig = Rig(gfx)
        tex = 0
        texKey = ""
        Matrix.setIdentityM(ident, 0)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES30.glViewport(0, 0, w, h)
        Matrix.perspectiveM(proj, 0, 35f, w.toFloat() / maxOf(1, h), 1f, 100f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClearColor(0.75f, 0.88f, 1f, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (!gfx.ok) return
        val a = get()
        val key = a.ser() + "#" + Skins.ver
        if (key != texKey) {
            if (tex != 0) GLES30.glDeleteTextures(1, intArrayOf(tex), 0)
            val bmp = AvatarTex.make(a)
            tex = gfx.makeTexture(bmp, false, false)
            bmp.recycle()
            texKey = key
        }
        Matrix.setLookAtM(view, 0, 12f, -8f, 6f, 0f, 0f, 2.6f, 0f, 0f, 1f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        gfx.beginMain(vp, ident, light, 0xFFBFE0FF.toInt(), 80f, 200f, false)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, 0f, 0f, -0.2f)
        gfx.mode = 1
        gfx.useTex(gfx.worldTex)
        gfx.box(model, 6f, 6f, 0.4f, 0xFFB0B8C0.toInt(), AvatarTex.white)
        gfx.mode = 0
        gfx.useTex(tex)
        val yaw = (SystemClock.uptimeMillis() % 9000L) / 9000f * 360f
        rig.draw(a, 0f, 0f, 0f, yaw, 0f, 0f, 0f)
    }
}
