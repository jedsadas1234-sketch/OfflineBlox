package com.offlineblox

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Wrapper: 3D surface at the bottom, touch + HUD overlay on top. */
class GameView(ctx: Context, net: Net, gm: GameMap, av: Avatar) : FrameLayout(ctx) {
    interface Listener { fun onMenu(); fun onChat() }

    var listener: Listener? = null
    private val hud = GameHud(ctx, net, gm, av)
    private val surface = GLSurfaceView(ctx)

    var shadows: Boolean
        get() = hud.shadows
        set(v) { hud.shadows = v }

    /** Experimental ray tracing: lower resolution, heavy. */
    var rt: Boolean
        get() = hud.rt
        set(v) {
            hud.rt = v
            if (v) surface.holder.setFixedSize(max(1, (width * 0.55f).toInt()), max(1, (height * 0.55f).toInt()))
            else surface.holder.setSizeFromLayout()
        }
    val rtSupported: Boolean
        get() = hud.rtError.isEmpty()

    init {
        surface.setEGLContextClientVersion(3)
        surface.setEGLConfigChooser(8, 8, 8, 0, 24, 0)
        surface.setRenderer(WorldRenderer(hud))
        surface.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        addView(surface, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        hud.listener = object : GameHud.Listener {
            override fun onMenu() { listener?.onMenu() }
            override fun onChat() { listener?.onChat() }
        }
        addView(hud, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    fun respawn() = hud.respawn()
}

class GameHud(ctx: Context, val net: Net, val gm: GameMap, val av: Avatar) : View(ctx) {
    interface Listener { fun onMenu(); fun onChat() }

    var listener: Listener? = null
    @Volatile var shadows = true
    @Volatile var glError = ""
    @Volatile var rt = false
    @Volatile var rtError = ""
    @Volatile var camEx = 0f
    @Volatile var camEy = 0f
    @Volatile var camEz = 0f

    private val d = resources.displayMetrics.density
    private val rad = 57.29578f

    // state read by the GL thread
    @Volatile var px = gm.sx
    @Volatile var py = gm.sy
    @Volatile var pz = 0f
    @Volatile var yaw = 0f
    @Volatile var phase = 0f
    @Volatile var swing = 0f
    @Volatile var airT = 0f
    @Volatile var firstPerson = false
    @Volatile var vp = FloatArray(16)

    private var vz = 0f
    private var tNow = (System.currentTimeMillis() % 600000L) / 1000f
    private var tPrev = tNow
    private var rideIdx = -1
    private var gIdx = -1
    private var spX = gm.sx
    private var spY = gm.sy
    private var spZ = 1f
    private var onGround = true
    private var targetYaw = 0f
    private var camYaw = 0f
    private var camPitch = 0.35f
    private var camDist = 12f
    private var camTZ = 0f
    private var last = System.nanoTime()
    private var lastSend = 0L
    private var fps = 60f

    private var joyId = -1
    private var jox = 0f
    private var joy = 0f
    private var jx = 0f
    private var jy = 0f
    private var jumpId = -1
    private var running = false
    private var runX = 0f
    private var runY = 0f
    private var camId = -1
    private var cam2Id = -1
    private val lx = FloatArray(2)
    private val ly = FloatArray(2)
    private var pinchPrev = 0f

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val pin = FloatArray(4)
    private val pout = FloatArray(4)
    private var sxp = 0f
    private var syp = 0f
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val menuR = RectF()
    private val chatR = RectF()
    private var jumpX = 0f
    private var jumpY = 0f
    private var jumpR = 0f
    private val body = 0.7f

    init {
        Matrix.setIdentityM(vp, 0)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        menuR.set(8 * d, 8 * d, 76 * d, 36 * d)
        chatR.set(82 * d, 8 * d, 150 * d, 36 * d)
        jumpX = w - 90 * d; jumpY = h - 90 * d; jumpR = 52 * d
        runX = w - 185 * d; runY = h - 55 * d
    }

    fun respawn() { px = spX; py = spY; pz = spZ; vz = 0f }

    private fun clock() = (System.currentTimeMillis() % 600000L) / 1000f

    // ---------- physics ----------
    private fun blocked(nx: Float, ny: Float, z: Float): Boolean {
        for (b in gm.solids) {
            if (b.kind == 1 || b.kind == 6 || !b.on(tNow)) continue
            val bx = b.cx(tNow)
            val by = b.cy(tNow)
            val bz = b.cz(tNow)
            val top = bz + b.h
            if (z < top - 0.3f && z + 4.5f > bz &&
                nx + body > bx && nx - body < bx + b.w && ny + body > by && ny - body < by + b.d) return true
        }
        return false
    }

    private fun deadly(): Boolean {
        for (b in gm.solids) {
            if (b.kind != 1 && b.kind != 6) continue
            val bx = b.cx(tNow)
            val by = b.cy(tNow)
            val bz = b.cz(tNow)
            if (px + 0.5f > bx && px - 0.5f < bx + b.w && py + 0.5f > by && py - 0.5f < by + b.d &&
                pz < bz + b.h - 0.1f && pz + 4.5f > bz) return true
        }
        return false
    }

    private fun groundAt(x: Float, y: Float, zFrom: Float): Float {
        var g = -1000f
        val f = gm.floor
        if (f != null && x > f[0] && x < f[2] && y > f[1] && y < f[3]) g = 0f
        gIdx = -1
        val list = gm.solids
        for (i in list.indices) {
            val b = list[i]
            if (b.kind == 1 || b.kind == 6 || !b.on(tNow)) continue
            val bx = b.cx(tNow)
            val by = b.cy(tNow)
            val top = b.cz(tNow) + b.h
            if (x + 0.4f > bx && x - 0.4f < bx + b.w && y + 0.4f > by && y - 0.4f < by + b.d && top <= zFrom + 0.3f && top > g) {
                g = top
                gIdx = i
            }
        }
        return g
    }

    private fun update(dt: Float) {
        tPrev = tNow
        tNow = clock()
        if (rideIdx >= 0 && rideIdx < gm.solids.size) {
            val rb = gm.solids[rideIdx]
            px += rb.cx(tNow) - rb.cx(tPrev)
            py += rb.cy(tNow) - rb.cy(tPrev)
        }
        val mag = min(1f, hypot(jx, jy))
        var moving = false
        if (mag > 0.12f) {
            val fx = cos(camYaw)
            val fy = sin(camYaw)
            var wx = fx * (-jy) + fy * jx
            var wy = fy * (-jy) - fx * jx
            val l = hypot(wx, wy)
            if (l > 0.0001f) {
                wx /= l; wy /= l
                val sp = (if (running) 15f else 9f) * min(1f, mag * 1.3f)
                val nx = px + wx * sp * dt
                if (!blocked(nx, py, pz)) px = nx
                val ny = py + wy * sp * dt
                if (!blocked(px, ny, pz)) py = ny
                targetYaw = atan2(wy, wx) * rad
                moving = true
            }
        }
        val dyaw = ((targetYaw - yaw + 540f) % 360f) - 180f
        yaw += dyaw * min(1f, dt * 12f)
        swing += ((if (moving) (if (running) 1.4f else 1f) else 0f) - swing) * min(1f, dt * 10f)
        phase += dt * 10f * swing * (if (running) 1.6f else 1f)

        if (jumpId != -1 && onGround) { vz = 12.5f; onGround = false }
        vz -= 34f * dt
        val nz = pz + vz * dt
        val g = groundAt(px, py, pz)
        if (vz <= 0f && nz <= g) { pz = g; vz = 0f; onGround = true } else { pz = nz; onGround = false }
        rideIdx = -1
        if (onGround && gIdx >= 0) {
            val gb = gm.solids[gIdx]
            when (gb.kind) {
                2 -> { vz = 30f; onGround = false }
                3 -> rideIdx = gIdx
                5 -> {
                    spX = gb.cx(tNow) + gb.w / 2f
                    spY = gb.cy(tNow) + gb.d / 2f
                    spZ = gb.cz(tNow) + gb.h + 0.5f
                }
            }
        }
        if (pz < -30f || deadly()) respawn()
        airT += ((if (onGround) 0f else 1f) - airT) * min(1f, dt * 10f)

        net.me.x = px; net.me.y = py; net.me.z = pz
        val tm = SystemClock.elapsedRealtime()
        if (tm - lastSend >= 50) { lastSend = tm; net.sendState(px, py, pz, yaw, !onGround) }

        for (r in net.peers.values) {
            if (!r.fresh) continue
            val dx = r.tx - r.x
            val dy = r.ty - r.y
            val k = min(1f, dt * 14f)
            r.x += dx * k; r.y += dy * k; r.z += (r.tz - r.z) * k
            r.yaw += (((r.tyaw - r.yaw + 540f) % 360f) - 180f) * min(1f, dt * 12f)
            val spd = hypot(dx, dy) * 14f
            val mv = spd > 0.7f
            r.swing += ((if (mv) min(1.4f, spd / 9f) else 0f) - r.swing) * min(1f, dt * 10f)
            r.phase += dt * 10f * r.swing * (if (spd > 11f) 1.6f else 1f)
            r.airT += ((if (r.air) 1f else 0f) - r.airT) * min(1f, dt * 10f)
        }
    }

    // ---------- camera ----------
    private fun hit(x: Float, y: Float, z: Float): Boolean {
        val f = gm.floor
        if (f != null && x > f[0] && x < f[2] && y > f[1] && y < f[3] && z < 0.25f) return true
        for (b in gm.solids) {
            if (b.kind == 1 || b.kind == 6) continue
            if (x > b.x && x < b.x + b.w && y > b.y && y < b.y + b.d && z > b.z && z < b.z + b.h) return true
        }
        return false
    }

    private fun pullIn(tx: Float, ty: Float, tz: Float, bx: Float, by: Float, bz: Float, dist: Float): Float {
        var t = 0.6f
        while (t < dist) {
            if (hit(tx + bx * t, ty + by * t, tz + bz * t)) return max(1.0f, t - 0.6f)
            t += 0.4f
        }
        return dist
    }

    private fun computeCamera(dt: Float) {
        camTZ += (pz - camTZ) * min(1f, dt * 8f)
        val cp = cos(camPitch)
        val sp = sin(camPitch)
        val dx = cos(camYaw) * cp
        val dy = sin(camYaw) * cp
        val dz = -sp
        val fp = camDist < 1.4f
        firstPerson = fp
        val ex: Float
        val ey: Float
        val ez: Float
        val cx: Float
        val cy: Float
        val cz: Float
        if (fp) {
            ex = px; ey = py; ez = pz + 4.8f
            cx = ex + dx; cy = ey + dy; cz = ez + dz
        } else {
            val tx = px
            val ty = py
            val tz = camTZ + 3.3f
            val dist = pullIn(tx, ty, tz, -dx, -dy, -dz, camDist)
            ex = tx - dx * dist; ey = ty - dy * dist; ez = tz - dz * dist
            cx = tx; cy = ty; cz = tz
        }
        camEx = ex; camEy = ey; camEz = ez
        val w = max(1, width)
        val h = max(1, height)
        Matrix.perspectiveM(proj, 0, 60f, w.toFloat() / h, 0.3f, 400f)
        Matrix.setLookAtM(view, 0, ex, ey, ez, cx, cy, cz, 0f, 0f, 1f)
        val out = FloatArray(16)
        Matrix.multiplyMM(out, 0, proj, 0, view, 0)
        vp = out
    }

    private fun project(x: Float, y: Float, z: Float): Boolean {
        pin[0] = x; pin[1] = y; pin[2] = z; pin[3] = 1f
        Matrix.multiplyMV(pout, 0, vp, 0, pin, 0)
        if (pout[3] <= 0.05f) return false
        val nx = pout[0] / pout[3]
        val ny = pout[1] / pout[3]
        sxp = (nx * 0.5f + 0.5f) * width
        syp = (1f - (ny * 0.5f + 0.5f)) * height
        return true
    }

    // ---------- drawing ----------
    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        var dt = (now - last) / 1e9f
        last = now
        if (dt > 0.0001f) fps += (1f / dt - fps) * 0.1f
        if (dt > 0.05f) dt = 0.05f
        update(dt)
        computeCamera(dt)
        drawLabels(c)
        drawHud(c, width.toFloat(), height.toFloat())
        postInvalidateOnAnimation()
    }

    private fun label(c: Canvas, text: String, x: Float, y: Float, size: Float, bubble: Boolean) {
        txt.textSize = size * d
        txt.textAlign = Paint.Align.CENTER
        txt.typeface = Typeface.DEFAULT_BOLD
        if (bubble) {
            val tw = txt.measureText(text)
            pen.style = Paint.Style.FILL
            pen.color = 0xEEFFFFFF.toInt()
            c.drawRoundRect(x - tw / 2 - 6 * d, y - size * d - 4 * d, x + tw / 2 + 6 * d, y + 5 * d, 6 * d, 6 * d, pen)
            txt.color = 0xFF111111.toInt()
            c.drawText(text, x, y, txt)
        } else {
            txt.style = Paint.Style.STROKE; txt.strokeWidth = 3f; txt.color = 0xFF000000.toInt()
            c.drawText(text, x, y, txt)
            txt.style = Paint.Style.FILL; txt.color = 0xFFFFFFFF.toInt()
            c.drawText(text, x, y, txt)
        }
        txt.style = Paint.Style.FILL
    }

    private fun drawLabels(c: Canvas) {
        val now = SystemClock.elapsedRealtime()
        fun tag(name: String, chat: String, chatT: Long, x: Float, y: Float, z: Float) {
            if (!project(x, y, z + 6.3f)) return
            val sx = sxp
            val sy = syp
            label(c, name, sx, sy, 13f, false)
            if (chat.isNotEmpty() && now - chatT < 6000) label(c, chat, sx, sy - 22 * d, 13f, true)
        }
        if (!firstPerson) tag(net.me.name, net.me.chat, net.me.chatT, px, py, pz)
        for (r in net.peers.values) if (r.fresh) tag(r.name, r.chat, r.chatT, r.x, r.y, r.z)
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        for ((rect, t) in listOf(menuR to L.t("Menu", "เมนู"), chatR to L.t("Chat", "แชท"))) {
            pen.style = Paint.Style.FILL; pen.color = 0xAA222222.toInt()
            c.drawRect(rect, pen)
            pen.style = Paint.Style.STROKE; pen.strokeWidth = 2f; pen.color = 0xFFCCCCCC.toInt()
            c.drawRect(rect, pen)
            txt.textSize = 14f * d; txt.textAlign = Paint.Align.CENTER; txt.color = 0xFFFFFFFF.toInt(); txt.typeface = Typeface.DEFAULT_BOLD
            c.drawText(t, rect.centerX(), rect.centerY() + 5 * d, txt)
        }
        val rows = ArrayList<String>()
        rows.add(net.me.name)
        for (r in net.peers.values) rows.add(r.name)
        val pw = 130f * d
        val x0 = w - pw - 8 * d
        pen.style = Paint.Style.FILL; pen.color = 0xAA333333.toInt()
        c.drawRect(x0, 8 * d, x0 + pw, 8 * d + 22 * d, pen)
        pen.color = 0x88000000.toInt()
        c.drawRect(x0, 30 * d, x0 + pw, 30 * d + min(rows.size, 10) * 20 * d, pen)
        txt.textAlign = Paint.Align.LEFT; txt.textSize = 13f * d; txt.color = 0xFFFFFFFF.toInt(); txt.typeface = Typeface.DEFAULT_BOLD
        c.drawText(L.t("Players", "ผู้เล่น"), x0 + 6 * d, 24 * d, txt)
        txt.typeface = Typeface.DEFAULT
        for ((i, n) in rows.take(10).withIndex()) c.drawText(n, x0 + 6 * d, 45 * d + i * 20 * d, txt)
        val st = when (net.role) {
            1 -> L.t("SERVER ON  -  IP: ", "เซิร์ฟเปิดอยู่ - IP: ") + net.ipText
            2 -> L.t("Connected to server", "เชื่อมต่อเซิร์ฟแล้ว")
            else -> ""
        }
        if (st.isNotEmpty()) {
            txt.textAlign = Paint.Align.CENTER; txt.textSize = 12f * d; txt.color = 0xFFFFFF66.toInt()
            c.drawText(st, w / 2f, 24 * d, txt)
        }
        txt.textAlign = Paint.Align.RIGHT; txt.textSize = 10f * d; txt.color = 0xAAFFFFFF.toInt(); txt.typeface = Typeface.DEFAULT
        c.drawText("${fps.toInt()} fps" + (if (rt) " RT" else ""), w - 12 * d, h - 8 * d, txt)
        val err = glError
        if (err.isNotEmpty()) {
            txt.textAlign = Paint.Align.LEFT; txt.textSize = 11f * d; txt.color = 0xFFFF6666.toInt()
            var i = 0
            var y = h * 0.3f
            while (i < err.length && i < 360) {
                c.drawText(err.substring(i, min(err.length, i + 70)), 12 * d, y, txt)
                i += 70; y += 14 * d
            }
        }
        val now = SystemClock.elapsedRealtime()
        val lines = net.chatLog.filter { now - it.t < 12000 }.takeLast(6)
        txt.textAlign = Paint.Align.LEFT; txt.textSize = 12f * d
        for ((i, l) in lines.withIndex()) {
            val y = 56 * d + i * 16 * d
            txt.style = Paint.Style.STROKE; txt.strokeWidth = 3f; txt.color = 0xFF000000.toInt()
            c.drawText(l.text, 10 * d, y, txt)
            txt.style = Paint.Style.FILL; txt.color = 0xFFFFFFFF.toInt()
            c.drawText(l.text, 10 * d, y, txt)
        }
        pen.style = Paint.Style.STROKE; pen.strokeWidth = 3f * d / 2
        if (joyId != -1) {
            pen.color = 0x88FFFFFF.toInt()
            c.drawCircle(jox, joy, 50 * d, pen)
            pen.style = Paint.Style.FILL; pen.color = 0xAAFFFFFF.toInt()
            c.drawCircle(jox + jx * 50 * d, joy + jy * 50 * d, 20 * d, pen)
        } else {
            pen.color = 0x44FFFFFF
            c.drawCircle(100 * d, h - 100 * d, 50 * d, pen)
        }
        pen.style = Paint.Style.FILL; pen.color = if (jumpId != -1) 0xAAFFFFFF.toInt() else 0x66FFFFFF
        c.drawCircle(jumpX, jumpY, 38 * d, pen)
        txt.textAlign = Paint.Align.CENTER; txt.textSize = 13f * d; txt.color = 0xFF222222.toInt(); txt.typeface = Typeface.DEFAULT_BOLD
        c.drawText(L.t("JUMP", "กระโดด"), jumpX, jumpY + 5 * d, txt)
        pen.style = Paint.Style.FILL; pen.color = if (running) 0xCCFFE066.toInt() else 0x66FFFFFF
        c.drawCircle(runX, runY, 30 * d, pen)
        txt.textSize = 12f * d; txt.color = 0xFF222222.toInt()
        c.drawText(if (running) L.t("RUN ON", "วิ่งอยู่") else L.t("RUN", "วิ่ง"), runX, runY + 4 * d, txt)
    }

    // ---------- touch: left = joystick, right = drag camera, 2 fingers = zoom, circle = jump ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val x = e.getX(i)
                val y = e.getY(i)
                val id = e.getPointerId(i)
                if (menuR.contains(x, y)) listener?.onMenu()
                else if (chatR.contains(x, y)) listener?.onChat()
                else if (hypot(x - runX, y - runY) < 38 * d) running = !running
                else if (jumpId == -1 && hypot(x - jumpX, y - jumpY) < jumpR) jumpId = id
                else if (joyId == -1 && x < width * 0.45f) { joyId = id; jox = x; joy = y; jx = 0f; jy = 0f }
                else if (camId == -1) { camId = id; lx[0] = x; ly[0] = y }
                else if (cam2Id == -1) {
                    cam2Id = id; lx[1] = x; ly[1] = y
                    pinchPrev = hypot(lx[0] - lx[1], ly[0] - ly[1])
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    val x = e.getX(i)
                    val y = e.getY(i)
                    if (id == joyId) {
                        val dx = x - jox
                        val dy = y - joy
                        val mx = 50f * d
                        val l = hypot(dx, dy)
                        val k = if (l > mx) mx / l else 1f
                        jx = dx * k / mx; jy = dy * k / mx
                    } else if (id == camId) {
                        if (cam2Id == -1) {
                            camYaw -= (x - lx[0]) * 0.006f
                            camPitch = (camPitch + (y - ly[0]) * 0.005f).coerceIn(-0.35f, 1.4f)
                        }
                        lx[0] = x; ly[0] = y
                    } else if (id == cam2Id) {
                        lx[1] = x; ly[1] = y
                    }
                }
                if (camId != -1 && cam2Id != -1) {
                    val cur = hypot(lx[0] - lx[1], ly[0] - ly[1])
                    if (pinchPrev > 10f && cur > 10f) camDist = (camDist * pinchPrev / cur).coerceIn(0.6f, 45f)
                    pinchPrev = cur
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL) {
                    joyId = -1; jumpId = -1; camId = -1; cam2Id = -1; jx = 0f; jy = 0f
                }
                if (id == joyId) { joyId = -1; jx = 0f; jy = 0f }
                if (id == jumpId) jumpId = -1
                if (id == camId) {
                    camId = cam2Id; lx[0] = lx[1]; ly[0] = ly[1]; cam2Id = -1; pinchPrev = 0f
                } else if (id == cam2Id) {
                    cam2Id = -1; pinchPrev = 0f
                }
            }
        }
        return true
    }
}
