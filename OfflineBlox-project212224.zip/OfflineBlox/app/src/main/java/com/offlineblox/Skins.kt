package com.offlineblox

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Store of custom skin / clothing images, addressed by a short hash so they can be synced over the network. */
object Skins {
    private var dir: File? = null
    @Volatile var ver = 0
    private val bytes = ConcurrentHashMap<String, ByteArray>()
    private val bmps = ConcurrentHashMap<String, Bitmap>()

    fun init(ctx: Context) {
        val d = File(ctx.filesDir, "tex")
        d.mkdirs()
        dir = d
    }

    private fun hash(b: ByteArray): String {
        val d = MessageDigest.getInstance("SHA-1").digest(b)
        val sb = StringBuilder()
        for (i in 0 until 8) sb.append("%02x".format(d[i]))
        return sb.toString()
    }

    private fun valid(h: String) = h.length == 16 && h.all { (it in '0'..'9') || (it in 'a'..'f') }

    fun bytesOf(h: String): ByteArray? {
        if (!valid(h)) return null
        val c = bytes[h]
        if (c != null) return c
        val dd = dir ?: return null
        val f = File(dd, "$h.png")
        if (f.exists()) {
            val b = f.readBytes()
            bytes[h] = b
            return b
        }
        return null
    }

    fun has(h: String) = h.isEmpty() || bytesOf(h) != null

    fun put(b: ByteArray): String {
        val h = hash(b)
        bytes[h] = b
        val dd = dir
        if (dd != null) {
            try { File(dd, "$h.png").writeBytes(b) } catch (_: Exception) {}
        }
        ver++
        return h
    }

    fun putBitmap(b: Bitmap): String {
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.PNG, 100, o)
        return put(o.toByteArray())
    }

    fun encoded(h: String): String? {
        val b = bytesOf(h) ?: return null
        return Base64.encodeToString(b, Base64.NO_WRAP)
    }

    /** Receive an image from the network. Returns true only if it was new and valid. */
    fun putEncoded(h: String, b64: String): Boolean {
        if (!valid(h) || bytesOf(h) != null) return false
        if (b64.length > 900000) return false
        val b = try { Base64.decode(b64, Base64.NO_WRAP) } catch (e: Exception) { return false }
        if (hash(b) != h) return false
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        if (o.outWidth < 64 || o.outWidth > 1024 || o.outHeight < 32 || o.outHeight > 1024) return false
        put(b)
        return true
    }

    fun bitmap(h: String): Bitmap? {
        if (h.isEmpty()) return null
        val c = bmps[h]
        if (c != null) return c
        val b = bytesOf(h) ?: return null
        val bm = BitmapFactory.decodeByteArray(b, 0, b.size) ?: return null
        bmps[h] = bm
        return bm
    }

    /** Old 64x32 Minecraft skins -> 64x64 (left limbs = mirrored right limbs). */
    fun normalizeMc(src: Bitmap): Bitmap {
        if (src.height >= src.width) return src.copy(Bitmap.Config.ARGB_8888, false)
        val s = src.width / 64
        val out = Bitmap.createBitmap(src.width, src.width, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(src, 0f, 0f, null)
        val p = Paint()
        p.isFilterBitmap = false
        // sx, sy, dx, dy, w, h  (64-grid units)
        val m = arrayOf(
            intArrayOf(4, 20, 20, 52, 4, 12), intArrayOf(0, 20, 24, 52, 4, 12), intArrayOf(8, 20, 16, 52, 4, 12),
            intArrayOf(12, 20, 28, 52, 4, 12), intArrayOf(4, 16, 20, 48, 4, 4), intArrayOf(8, 16, 24, 48, 4, 4),
            intArrayOf(44, 20, 36, 52, 4, 12), intArrayOf(40, 20, 40, 52, 4, 12), intArrayOf(48, 20, 32, 52, 4, 12),
            intArrayOf(52, 20, 44, 52, 4, 12), intArrayOf(44, 16, 36, 48, 4, 4), intArrayOf(48, 16, 40, 48, 4, 4)
        )
        for (r in m) {
            val sr = Rect(r[0] * s, r[1] * s, (r[0] + r[4]) * s, (r[1] + r[5]) * s)
            val dx = r[2] * s.toFloat()
            val dy = r[3] * s.toFloat()
            val dw = r[4] * s.toFloat()
            val dh = r[5] * s.toFloat()
            c.save()
            c.scale(-1f, 1f, dx + dw / 2f, dy + dh / 2f)
            c.drawBitmap(src, sr, RectF(dx, dy, dx + dw, dy + dh), p)
            c.restore()
        }
        return out
    }
}
