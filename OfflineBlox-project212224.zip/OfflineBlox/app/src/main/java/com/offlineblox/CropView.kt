package com.offlineblox

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Crop window with a Minecraft-style template guide. kind: 0 shirt, 1 pants, 2 face.
 * Simple mode: one picture over the whole template (drag / pinch).
 * Advanced mode: tap a part, "Add image" puts another picture on just that part (clipped to it),
 * drag / pinch moves it, double-tap on a picture deletes it.
 */
class CropView(ctx: Context, private val src: Bitmap, private val kind: Int) : View(ctx) {
    companion object {
        /** bounding box in Minecraft 64x64 skin units: x, y, w, h */
        fun bbox(kind: Int): IntArray = when (kind) {
            0 -> intArrayOf(16, 16, 40, 16)
            1 -> intArrayOf(0, 16, 16, 16)
            else -> intArrayOf(8, 8, 8, 8)
        }
    }

    private class Layer(val bmp: Bitmap, val region: Int, val m: Matrix)

    var advanced = false
        set(v) {
            field = v
            selRegion = -1
            sel = layers.firstOrNull()
            invalidate()
        }

    private val bb = bbox(kind)
    private val frame = RectF()
    private val regions = ArrayList<RectF>()
    private val layers = ArrayList<Layer>()
    private var sel: Layer? = null
    private var selRegion = -1
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = 0xFFFFE066.toInt() }
    private val fillSel = Paint().apply { color = 0x44FFE066 }
    private val dim = Paint().apply { color = 0xB0000000.toInt() }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFE066.toInt(); textAlign = Paint.Align.CENTER }
    private var lx = 0f
    private var ly = 0f
    private var pan = false

    private val sg = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            active()?.m?.postScale(d.scaleFactor, d.scaleFactor, d.focusX, d.focusY)
            invalidate()
            return true
        }
    })
    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent): Boolean {
            if (advanced) selectAt(e.x, e.y)
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (advanced) deleteAt(e.x, e.y)
            return true
        }
    })

    private fun active(): Layer? = if (advanced) sel else layers.firstOrNull()

    private fun rectFor(l: Layer): RectF = if (l.region >= 0 && l.region < regions.size) regions[l.region] else frame

    private fun fit(bmp: Bitmap, r: RectF): Matrix {
        val m = Matrix()
        val sc = maxOf(r.width() / bmp.width, r.height() / bmp.height)
        m.postScale(sc, sc)
        m.postTranslate(r.centerX() - bmp.width * sc / 2f, r.centerY() - bmp.height * sc / 2f)
        return m
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val mw = w * 0.92f
        val mh = h * 0.86f
        val asp = bb[2].toFloat() / bb[3]
        var fw = mw
        var fh = fw / asp
        if (fh > mh) { fh = mh; fw = fh * asp }
        frame.set((w - fw) / 2f, (h - fh) / 2f, (w + fw) / 2f, (h + fh) / 2f)
        regions.clear()
        for (r in AvatarTex.MC) {
            val ok = when (kind) {
                0 -> r[0] == 1 || r[0] == 3
                1 -> r[0] == 5
                else -> r[0] == 0 && r[1] == 0
            }
            if (ok) regions.add(RectF(ux(r[2]), uy(r[3]), ux(r[2] + r[4]), uy(r[3] + r[5])))
        }
        if (layers.isEmpty()) {
            val base = Layer(src, -1, fit(src, frame))
            layers.add(base)
            sel = base
        }
    }

    private fun ux(x: Int) = frame.left + (x - bb[0]) / bb[2].toFloat() * frame.width()
    private fun uy(y: Int) = frame.top + (y - bb[1]) / bb[3].toFloat() * frame.height()

    private fun regionAt(x: Float, y: Float): Int {
        for (i in regions.indices) if (regions[i].contains(x, y)) return i
        return -1
    }

    private fun imgContains(l: Layer, x: Float, y: Float): Boolean {
        if (!rectFor(l).contains(x, y)) return false
        val rr = RectF(0f, 0f, l.bmp.width.toFloat(), l.bmp.height.toFloat())
        l.m.mapRect(rr)
        return rr.contains(x, y)
    }

    private fun selectAt(x: Float, y: Float) {
        selRegion = regionAt(x, y)
        var found: Layer? = null
        for (i in layers.indices.reversed()) {
            val l = layers[i]
            if (l.region == selRegion && imgContains(l, x, y)) { found = l; break }
        }
        if (found == null) found = layers.firstOrNull { it.region == -1 }
        sel = found
        invalidate()
    }

    private fun deleteAt(x: Float, y: Float) {
        val reg = regionAt(x, y)
        for (i in layers.indices.reversed()) {
            val l = layers[i]
            if (l.region == reg && imgContains(l, x, y)) {
                layers.removeAt(i)
                break
            }
        }
        sel = layers.lastOrNull()
        invalidate()
    }

    /** Advanced mode: put another picture on the selected part (or the whole template if none selected). */
    fun addLayer(bmp: Bitmap) {
        val reg = if (selRegion in regions.indices) selRegion else -1
        val l = Layer(bmp, reg, fit(bmp, if (reg >= 0) regions[reg] else frame))
        layers.add(l)
        sel = l
        invalidate()
    }

    private fun drawLayers(c: Canvas) {
        for (l in layers) {
            c.save()
            if (l.region >= 0) c.clipRect(rectFor(l))
            c.drawBitmap(l.bmp, l.m, paint)
            c.restore()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF1E1E1E.toInt())
        drawLayers(c)
        c.drawRect(0f, 0f, w, frame.top, dim)
        c.drawRect(0f, frame.bottom, w, h, dim)
        c.drawRect(0f, frame.top, frame.left, frame.bottom, dim)
        c.drawRect(frame.right, frame.top, w, frame.bottom, dim)
        c.drawRect(frame, line)
        for (r in regions) c.drawRect(r, line)
        if (advanced && selRegion in regions.indices) {
            c.drawRect(regions[selRegion], fillSel)
            line.strokeWidth = 5f
            c.drawRect(regions[selRegion], line)
            line.strokeWidth = 2f
        }
        text.textSize = frame.height() / 10f
        if (kind == 0) {
            c.drawText(L.t("FRONT", "หน้า"), ux(24), uy(26), text)
            c.drawText(L.t("BACK", "หลัง"), ux(36), uy(26), text)
            c.drawText(L.t("ARM", "แขน"), ux(46), uy(26), text)
        } else if (kind == 1) {
            c.drawText(L.t("FRONT", "หน้า"), ux(6), uy(26), text)
        } else {
            c.drawText(L.t("FACE", "ใบหน้า"), frame.centerX(), frame.centerY(), text)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sg.onTouchEvent(e)
        gd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; pan = true }
            MotionEvent.ACTION_POINTER_DOWN -> pan = false
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (e.actionIndex == 0) 1 else 0
                lx = e.getX(i); ly = e.getY(i)
                pan = e.pointerCount == 2
            }
            MotionEvent.ACTION_MOVE -> if (pan && e.pointerCount == 1 && !sg.isInProgress) {
                active()?.m?.postTranslate(e.x - lx, e.y - ly)
                lx = e.x; ly = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pan = false
        }
        return true
    }

    /** Everything inside the guide frame, rendered at 8 px per skin unit. */
    fun result(): Bitmap {
        val ow = bb[2] * 8
        val oh = bb[3] * 8
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.scale(ow / frame.width(), oh / frame.height())
        c.translate(-frame.left, -frame.top)
        drawLayers(c)
        return out
    }
}
