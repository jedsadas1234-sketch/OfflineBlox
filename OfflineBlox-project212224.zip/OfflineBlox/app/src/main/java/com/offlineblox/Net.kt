package com.offlineblox

import android.os.SystemClock
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

class Remote(val id: Int, var name: String, var av: Avatar) {
    @Volatile var x = 0f
    @Volatile var y = 0f
    @Volatile var z = 0f
    @Volatile var tx = 0f
    @Volatile var ty = 0f
    @Volatile var tz = 0f
    @Volatile var fresh = false
    @Volatile var tyaw = 0f
    @Volatile var yaw = 0f
    @Volatile var air = false
    var airT = 0f
    var phase = 0f
    var swing = 0f
    @Volatile var chat = ""
    @Volatile var chatT = 0L
}

class ServerInfo(val ip: String, val name: String, val map: String, val players: Int, val seen: Long)
class ChatLine(val text: String, val t: Long)

class Net {
    companion object {
        const val TCP = 47777
        const val UDP = 47778
    }

    val peers = ConcurrentHashMap<Int, Remote>()
    val chatLog = CopyOnWriteArrayList<ChatLine>()
    val servers = ConcurrentHashMap<String, ServerInfo>()
    var me = Remote(0, "Player", Avatar())

    @Volatile var role = 0 // 0 offline, 1 host, 2 client
    @Volatile var status = ""
    @Volatile var mapIdx = 0
    @Volatile var hostMapName = ""
    @Volatile var ipText = ""
    var onWelcome: ((Int) -> Unit)? = null
    var onClosed: (() -> Unit)? = null
    var onKicked: ((String) -> Unit)? = null

    private var serverSock: ServerSocket? = null
    private val conns = CopyOnWriteArrayList<Conn>()
    private var csock: Socket? = null
    private var cout: PrintWriter? = null
    @Volatile private var nextId = 1

    private inner class Conn(val sock: Socket) {
        var id = 0
        val w = PrintWriter(OutputStreamWriter(sock.getOutputStream(), "UTF-8"), true)
        private val q = LinkedBlockingQueue<String>()
        init {
            thread(isDaemon = true) {
                try {
                    while (!sock.isClosed) {
                        val m = q.poll(1, TimeUnit.SECONDS) ?: continue
                        w.println(m)
                    }
                } catch (_: Exception) {}
            }
        }
        fun send(s: String) { if (q.size < 400) q.offer(s) }
        fun sendNow(s: String) { synchronized(w) { w.println(s) } }
    }

    private fun clean(s: String) = s.replace("|", " ").replace("\n", " ").replace(",", " ").take(60)

    fun addChat(s: String) {
        chatLog.add(ChatLine(s, SystemClock.elapsedRealtime()))
        if (chatLog.size > 40) chatLog.removeAt(0)
    }

    // ---------- HOST ----------
    fun startHost(mi: Int, mapName: String): Boolean {
        if (role != 0) return false
        try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(TCP))
            serverSock = ss
        } catch (e: Exception) {
            status = "Cannot host: ${e.message}"; return false
        }
        role = 1; mapIdx = mi; hostMapName = mapName
        thread(isDaemon = true) { ipText = localIps() }
        val ss = serverSock!!
        thread(isDaemon = true) {
            while (role == 1) {
                try {
                    val s = ss.accept()
                    thread(isDaemon = true) { serve(s) }
                } catch (e: Exception) { break }
            }
        }
        thread(isDaemon = true) { announce(mapName) }
        addChat(L.t("* Server started", "* เปิดเซิร์ฟเวอร์แล้ว"))
        return true
    }

    private fun announce(mapName: String) {
        try {
            val ds = DatagramSocket()
            ds.broadcast = true
            while (role == 1) {
                val msg = "OFFLINEBLOX|${clean(me.name)}|${clean(mapName)}|${peers.size + 1}".toByteArray(Charsets.UTF_8)
                for (a in broadcastAddrs()) {
                    try { ds.send(DatagramPacket(msg, msg.size, a, UDP)) } catch (_: Exception) {}
                }
                Thread.sleep(1000)
            }
            ds.close()
        } catch (_: Exception) {}
    }

    private fun broadcastAddrs(): List<InetAddress> {
        val out = ArrayList<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) ia.broadcast?.let { out.add(it) }
            }
        } catch (_: Exception) {}
        try { out.add(InetAddress.getByName("255.255.255.255")) } catch (_: Exception) {}
        return out
    }

    fun localIps(): String {
        val l = ArrayList<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) if (a is Inet4Address && !a.isLoopbackAddress) l.add(a.hostAddress ?: "")
            }
        } catch (_: Exception) {}
        return if (l.isEmpty()) "?" else l.joinToString(" / ")
    }

    fun localIpSet(): Set<String> = localIps().split(" / ").toSet()

    private fun broadcast(msg: String, except: Int) {
        for (c in conns) if (c.id != except) c.send(msg)
    }

    private fun sys(t: String) { addChat(t); broadcast("T|$t", -1) }

    private fun setTarget(r: Remote, x: Float, y: Float, z: Float, yaw: Float, air: Boolean) {
        r.tx = x; r.ty = y; r.tz = z; r.tyaw = yaw; r.air = air
        if (!r.fresh) { r.x = x; r.y = y; r.z = z; r.yaw = yaw; r.fresh = true }
    }

    private fun serve(sock: Socket) {
        val c = Conn(sock)
        var added = false
        try {
            sock.tcpNoDelay = true
            val r = BufferedReader(InputStreamReader(sock.getInputStream(), "UTF-8"))
            val f = (r.readLine() ?: return).split("|")
            if (f.isNotEmpty() && f[0] == "Q") {
                c.sendNow("I|${clean(me.name)}|${clean(hostMapName)}|${peers.size + 1}")
                return
            }
            if (f.size < 3 || f[0] != "H") return
            val nm = clean(f[1])
            if (nm.equals(clean(me.name), true) || peers.values.any { it.name.equals(nm, true) }) {
                c.sendNow("K|$nm")
                return
            }
            c.id = nextId++
            val rem = Remote(c.id, nm, Avatar.parse(f[2]))
            c.send("W|${c.id}|$mapIdx")
            c.send("J|0|${clean(me.name)}|${me.av.ser()}")
            for (p in peers.values) c.send("J|${p.id}|${p.name}|${p.av.ser()}")
            peers[c.id] = rem
            conns.add(c)
            added = true
            broadcast("J|${c.id}|${rem.name}|${rem.av.ser()}", c.id)
            sys(L.t("* ${rem.name} joined", "* ${rem.name} เข้าห้องมาแล้ว"))
            requestMissing(c, rem.av)
            while (true) {
                val line = r.readLine() ?: break
                val p = line.split("|", limit = 4)
                when (p[0]) {
                    "S" -> {
                        val q = line.split("|")
                        if (q.size >= 6) {
                            val x = q[1].toFloatOrNull() ?: 0f
                            val y = q[2].toFloatOrNull() ?: 0f
                            val z = q[3].toFloatOrNull() ?: 0f
                            val yw = q[4].toFloatOrNull() ?: 0f
                            setTarget(rem, x, y, z, yw, q[5] == "1")
                            broadcast("S|${c.id}|$x|$y|$z|$yw|${q[5]}", c.id)
                        }
                    }
                    "C" -> if (p.size >= 2) {
                        val t = clean(line.substring(2))
                        rem.chat = t; rem.chatT = SystemClock.elapsedRealtime()
                        addChat("${rem.name}: $t")
                        broadcast("C|${c.id}|$t", c.id)
                    }
                    "N" -> {
                        val q = line.split("|")
                        if (q.size >= 2) Skins.encoded(q[1])?.let { c.send("X|${q[1]}|$it") }
                    }
                    "X" -> {
                        val q = line.split("|", limit = 3)
                        if (q.size >= 3 && Skins.putEncoded(q[1], q[2])) broadcast("X|${q[1]}|${q[2]}", c.id)
                    }
                    "A" -> if (p.size >= 2) {
                        rem.av = Avatar.parse(p[1])
                        broadcast("A|${c.id}|${p[1]}", c.id)
                        requestMissing(c, rem.av)
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            conns.remove(c)
            if (added && peers.remove(c.id) != null) {
                broadcast("L|${c.id}", -1)
                addChat(L.t("* a player left", "* มีคนออกจากห้อง"))
            }
            try { sock.close() } catch (_: Exception) {}
        }
    }

    // ---------- CLIENT ----------
    fun join(ip: String): Boolean {
        try {
            val s = Socket()
            s.connect(InetSocketAddress(ip, TCP), 4000)
            s.tcpNoDelay = true
            csock = s
            val w = PrintWriter(OutputStreamWriter(s.getOutputStream(), "UTF-8"), true)
            cout = w
            val q = LinkedBlockingQueue<String>()
            cq = q
            role = 2
            w.println("H|${clean(me.name)}|${me.av.ser()}")
            thread(isDaemon = true) {
                try {
                    while (!s.isClosed && role == 2) {
                        val m = q.poll(1, TimeUnit.SECONDS) ?: continue
                        w.println(m)
                    }
                } catch (_: Exception) {}
            }
            thread(isDaemon = true) { clientLoop(s) }
            return true
        } catch (e: Exception) {
            status = "Join failed: ${e.message}"
            role = 0
            return false
        }
    }

    private fun clientLoop(s: Socket) {
        try {
            val r = BufferedReader(InputStreamReader(s.getInputStream(), "UTF-8"))
            while (true) {
                val line = r.readLine() ?: break
                val p = line.split("|", limit = 4)
                when (p[0]) {
                    "W" -> if (p.size >= 3) {
                        mapIdx = (p[2].toIntOrNull() ?: 0).coerceIn(0, Maps.all.size - 1)
                        onWelcome?.invoke(mapIdx)
                    }
                    "J" -> if (p.size >= 4) {
                        val id = p[1].toIntOrNull() ?: continue
                        val nr = Remote(id, p[2], Avatar.parse(p[3]))
                        peers[id] = nr
                        needTex(nr.av)
                    }
                    "S" -> {
                        val q = line.split("|")
                        if (q.size >= 7) {
                            val id = q[1].toIntOrNull() ?: continue
                            peers[id]?.let {
                                setTarget(it, q[2].toFloatOrNull() ?: 0f, q[3].toFloatOrNull() ?: 0f,
                                    q[4].toFloatOrNull() ?: 0f, q[5].toFloatOrNull() ?: 0f, q[6] == "1")
                            }
                        }
                    }
                    "C" -> if (p.size >= 3) {
                        val id = p[1].toIntOrNull() ?: continue
                        val t = line.split("|", limit = 3)[2]
                        val rem = peers[id]
                        if (rem != null) { rem.chat = t; rem.chatT = SystemClock.elapsedRealtime(); addChat("${rem.name}: $t") }
                    }
                    "K" -> {
                        role = 0; peers.clear()
                        try { s.close() } catch (_: Exception) {}
                        onKicked?.invoke(p.getOrElse(1) { "" })
                    }
                    "T" -> if (p.size >= 2) addChat(line.substring(2))
                    "L" -> if (p.size >= 2) peers.remove(p[1].toIntOrNull() ?: -1)
                    "A" -> if (p.size >= 3) {
                        val pr = peers[p[1].toIntOrNull() ?: -1]
                        if (pr != null) { pr.av = Avatar.parse(p[2]); needTex(pr.av) }
                    }
                    "N" -> {
                        val q = line.split("|")
                        if (q.size >= 2) Skins.encoded(q[1])?.let { out("X|${q[1]}|$it") }
                    }
                    "X" -> {
                        val q = line.split("|", limit = 3)
                        if (q.size >= 3) Skins.putEncoded(q[1], q[2])
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            if (role == 2) { role = 0; peers.clear(); onClosed?.invoke() }
        }
    }

    // ---------- custom texture sync (by hash) ----------
    private fun texList(a: Avatar) = listOf(a.mc, a.shirtImg, a.pantsImg, a.faceImg).filter { it.isNotEmpty() }
    private fun requestMissing(c: Conn, a: Avatar) { for (h in texList(a)) if (!Skins.has(h)) c.send("N|$h") }
    private fun needTex(a: Avatar) { for (h in texList(a)) if (!Skins.has(h)) out("N|$h") }

    // ---------- shared ----------
    private var cq: LinkedBlockingQueue<String>? = null
    private fun out(s: String) { val q = cq ?: return; if (q.size < 400) q.offer(s) }

    fun sendState(x: Float, y: Float, z: Float, yaw: Float, air: Boolean) {
        val a = if (air) 1 else 0
        when (role) {
            1 -> broadcast("S|0|$x|$y|$z|$yaw|$a", -1)
            2 -> out("S|$x|$y|$z|$yaw|$a")
        }
    }

    fun sendChat(t0: String) {
        val t = clean(t0)
        me.chat = t; me.chatT = SystemClock.elapsedRealtime()
        addChat("${me.name}: $t")
        when (role) {
            1 -> broadcast("C|0|$t", -1)
            2 -> out("C|$t")
        }
    }

    fun stop() {
        role = 0
        try { serverSock?.close() } catch (_: Exception) {}
        serverSock = null
        for (c in conns) try { c.sock.close() } catch (_: Exception) {}
        conns.clear()
        try { csock?.close() } catch (_: Exception) {}
        csock = null; cout = null; cq = null
        peers.clear(); chatLog.clear(); nextId = 1
    }

    // ---------- discovery ----------
    @Volatile private var disc = false

    fun startDiscovery() {
        if (disc) return
        disc = true
        servers.clear()
        thread(isDaemon = true) {
            while (disc) {
                scanOnce()
                try { Thread.sleep(1200) } catch (_: Exception) {}
            }
        }
        thread(isDaemon = true) {
            try {
                val ds = DatagramSocket(null)
                ds.reuseAddress = true
                ds.bind(InetSocketAddress(UDP))
                ds.soTimeout = 1000
                val buf = ByteArray(512)
                val own = localIpSet()
                while (disc) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        ds.receive(p)
                        val s = String(p.data, 0, p.length, Charsets.UTF_8).split("|")
                        val ip = p.address.hostAddress
                        if (s.size >= 4 && s[0] == "OFFLINEBLOX" && ip != null && ip !in own) {
                            servers[ip] = ServerInfo(ip, s[1], s[2], s[3].toIntOrNull() ?: 1, SystemClock.elapsedRealtime())
                        }
                    } catch (_: SocketTimeoutException) {}
                }
                ds.close()
            } catch (e: Exception) {
                status = "Discovery error: ${e.message}"
                disc = false
            }
        }
    }

    private fun subnetBases(): List<String> {
        val out = ArrayList<String>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name ?: ""
                if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("tun") || n.startsWith("dummy") || n.startsWith("v4-")) continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        val b = a.address
                        val pre = "${b[0].toInt() and 255}.${b[1].toInt() and 255}.${b[2].toInt() and 255}."
                        if (pre !in out) out.add(pre)
                    }
                }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun scanOnce() {
        val own = localIpSet()
        val pool = Executors.newFixedThreadPool(48)
        for (pre in subnetBases()) for (i in 1..254) {
            val ip = pre + i
            if (ip in own) continue
            pool.execute { probe(ip) }
        }
        pool.shutdown()
        try { pool.awaitTermination(8, TimeUnit.SECONDS) } catch (_: Exception) {}
        pool.shutdownNow()
    }

    private fun probe(ip: String) {
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, TCP), 400)
                s.soTimeout = 800
                val w = PrintWriter(OutputStreamWriter(s.getOutputStream(), "UTF-8"), true)
                w.println("Q")
                val l = BufferedReader(InputStreamReader(s.getInputStream(), "UTF-8")).readLine() ?: return
                val p = l.split("|")
                if (p.size >= 4 && p[0] == "I") servers[ip] = ServerInfo(ip, p[1], p[2], p[3].toIntOrNull() ?: 1, SystemClock.elapsedRealtime())
            }
        } catch (_: Exception) {}
    }

    fun stopDiscovery() { disc = false }
}
