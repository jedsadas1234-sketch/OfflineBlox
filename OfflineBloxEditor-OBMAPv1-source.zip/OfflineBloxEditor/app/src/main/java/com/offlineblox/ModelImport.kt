package com.offlineblox

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.StringTokenizer

class ImportException(msg: String) : Exception(msg)

/** [model] goes into EDoc.models, [textures] into EDoc.textures. [note] = things the user should know (may be empty). */
class ImportResult(val model: EModel, val textures: List<ETex>, val note: String)

internal class FA {
    var a = FloatArray(1024)
    var n = 0
    fun add(v: Float) {
        if (n == a.size) a = a.copyOf(n * 2)
        a[n++] = v
    }
}

internal class IA {
    var a = IntArray(1024)
    var n = 0
    fun add(v: Int) {
        if (n == a.size) a = a.copyOf(n * 2)
        a[n++] = v
    }
}

/** Raw mesh while reading a file: every vertex has position, uv, colour and a "uses the texture" flag. */
internal class Builder {
    val pos = FA()
    val uv = FA()
    val col = IA()
    val flag = IA()
    val idx = IA()
    var count = 0
    var texBmp: Bitmap? = null
    var texKey = ""
    val tried = HashSet<String>()
    val notes = ArrayList<String>()

    fun vertex(x: Float, y: Float, z: Float, u: Float, v: Float, rgb: Int, textured: Boolean): Int {
        pos.add(x); pos.add(y); pos.add(z)
        uv.add(u); uv.add(v)
        col.add(rgb)
        flag.add(if (textured) 1 else 0)
        return count++
    }

    fun tri(a: Int, b: Int, c: Int) {
        idx.add(a); idx.add(b); idx.add(c)
    }

    /** Loads the picture [ref] once; true when vertices of that material should use the model texture. */
    fun useTexture(files: Map<String, ByteArray>, ref: String?): Boolean {
        if (ref == null) return false
        if (texBmp == null && !tried.contains(ref)) {
            tried.add(ref)
            val data = ModelImport.findFile(files, ref)
            val bm = if (data != null) Tex.fromBytes(data, Tex.MAX_SIDE) else null
            if (bm != null) {
                texBmp = bm
                texKey = ref
            } else {
                notes.add("texture file not loaded: " + ref)
            }
        }
        return texBmp != null && texKey == ref
    }
}

/**
 * Converts outside 3D model files (OBJ+MTL, STL, PLY, glTF/GLB) into an [EModel], the JSON mesh stored in the .map.
 * Several picked files can come together (model + .mtl + pictures + .bin); they are found by file name.
 */
object ModelImport {
    const val MAX_TRIS = 30000
    private const val MAX_TRIS_IN = 3000000
    val EXTS = listOf("obj", "stl", "ply", "glb", "gltf")

    fun extOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    private fun baseName(s: String): String {
        val a = s.replace('\\', '/')
        return a.substring(a.lastIndexOf('/') + 1).lowercase()
    }

    fun findFile(files: Map<String, ByteArray>, ref: String): ByteArray? {
        // glTF/OBJ references are commonly relative paths (for example textures/albedo.png).
        // Prefer an exact normalized path match so two folders may contain same-named images.
        fun norm(s: String): String = s.replace('\\', '/').trimStart('/')
            .split('/').filter { it.isNotEmpty() && it != "." }.joinToString("/").lowercase()
        val wanted = norm(ref)
        files[wanted]?.let { return it }
        for ((k, v) in files) if (norm(k) == wanted) return v
        // Some Android document providers flatten selected files to display names. In that case
        // use a suffix match before falling back to basename-only matching.
        for ((k, v) in files) {
            val candidate = norm(k)
            if (candidate.endsWith("/$wanted")) return v
        }
        val wantBase = baseName(ref)
        for ((k, v) in files) if (baseName(k) == wantBase) return v
        return null
    }

    /** The file that is the model itself among everything the user picked. */
    fun pickMain(files: Map<String, ByteArray>): String? {
        for (k in files.keys) if (extOf(k) in EXTS) return k
        for (k in files.keys) if (sniff(files[k]!!) != null) return k
        return null
    }

    /** Kind of model by content when the extension tells nothing. */
    private fun sniff(b: ByteArray): String? {
        if (b.size > 12 && b[0] == 'g'.code.toByte() && b[1] == 'l'.code.toByte() && b[2] == 'T'.code.toByte() && b[3] == 'F'.code.toByte()) return "glb"
        val head = String(b, 0, Math.min(b.size, 400), Charsets.ISO_8859_1)
        if (head.startsWith("ply")) return "ply"
        if (head.trimStart().startsWith("{") && head.contains("asset")) return "gltf"
        if (head.trimStart().startsWith("solid") && head.contains("facet")) return "stl"
        return null
    }

    /** Is the up-axis question worth asking for this file? (glTF is always Y-up, STL is nearly always Z-up.) */
    fun asksUpAxis(name: String): Boolean {
        val e = extOf(name)
        return e == "obj" || e == "ply"
    }

    fun defaultYUp(name: String): Boolean = extOf(name) != "stl"

    fun convert(files: Map<String, ByteArray>, main: String, yUp: Boolean, id: String, texId: String): ImportResult {
        val bytes = files[main] ?: throw ImportException("file missing")
        var kind = extOf(main)
        if (kind !in EXTS) kind = sniff(bytes) ?: throw ImportException("unknown model format (use OBJ, STL, PLY, GLB or glTF)")
        val b = Builder()
        var up = yUp
        try {
            when (kind) {
                "obj" -> parseObj(b, files, bytes)
                "stl" -> parseStl(b, bytes)
                "ply" -> parsePly(b, files, bytes)
                else -> { parseGltf(b, files, bytes); up = true }
            }
            val name = main.substringBeforeLast('.').take(40).ifEmpty { "model" }
            return finish(b, up, id, name, texId)
        } catch (e: ImportException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw ImportException("model is too big for this phone")
        } catch (e: Exception) {
            throw ImportException("cannot read the model: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    // ------------------------------------------------------------------ OBJ
    private class Mat(val rgb: Int, val tex: String?)

    private fun parseMtl(text: String, out: HashMap<String, Mat>) {
        var name: String? = null
        var rgb = 0xFFFFFF
        var tex: String? = null
        for (raw in text.split('\n')) {
            val s = raw.trim()
            if (s.isEmpty() || s[0] == '#') continue
            val st = StringTokenizer(s)
            val cmd = st.nextToken().lowercase()
            if (cmd == "newmtl") {
                val n0 = name
                if (n0 != null) out[n0] = Mat(rgb, tex)
                name = s.substring(cmd.length).trim().ifEmpty { "mat" }
                rgb = 0xFFFFFF
                tex = null
            } else if (cmd == "kd" && st.countTokens() >= 3) {
                val r = st.nextToken().toFloatOrNull() ?: 1f
                val g = st.nextToken().toFloatOrNull() ?: 1f
                val bl = st.nextToken().toFloatOrNull() ?: 1f
                rgb = pack(r, g, bl)
            } else if (cmd == "map_kd") {
                var last = ""
                while (st.hasMoreTokens()) last = st.nextToken()
                if (last.isNotEmpty()) tex = last
            }
        }
        val n1 = name
        if (n1 != null) out[n1] = Mat(rgb, tex)
    }

    private fun pack(r: Float, g: Float, b: Float): Int {
        val ri = Math.round(r.coerceIn(0f, 1f) * 255f)
        val gi = Math.round(g.coerceIn(0f, 1f) * 255f)
        val bi = Math.round(b.coerceIn(0f, 1f) * 255f)
        return (ri shl 16) or (gi shl 8) or bi
    }

    private fun parseObj(b: Builder, files: Map<String, ByteArray>, bytes: ByteArray) {
        val text = String(bytes, Charsets.UTF_8)
        val vx = FA()
        val vt = FA()
        val mats = HashMap<String, Mat>()
        val matIds = HashMap<String, Int>()
        matIds[""] = 0
        var curRgb = 0xFFFFFF
        var curTex: String? = null
        var curId = 0
        val keyMap = HashMap<Long, Int>()
        val fv = IA()
        var tris = 0
        for (raw in text.split('\n')) {
            val s = raw.trim()
            if (s.isEmpty() || s[0] == '#') continue
            val st = StringTokenizer(s)
            val cmd = st.nextToken()
            if (cmd == "v") {
                if (st.countTokens() < 3) continue
                vx.add(st.nextToken().toFloatOrNull() ?: 0f)
                vx.add(st.nextToken().toFloatOrNull() ?: 0f)
                vx.add(st.nextToken().toFloatOrNull() ?: 0f)
            } else if (cmd == "vt") {
                if (st.countTokens() < 2) continue
                vt.add(st.nextToken().toFloatOrNull() ?: 0f)
                vt.add(st.nextToken().toFloatOrNull() ?: 0f)
            } else if (cmd == "mtllib") {
                val ref = s.substring(cmd.length).trim()
                val data = findFile(files, ref)
                if (data != null) parseMtl(String(data, Charsets.UTF_8), mats)
            } else if (cmd == "usemtl") {
                val n = s.substring(cmd.length).trim()
                val m = mats[n]
                curRgb = m?.rgb ?: 0xFFFFFF
                curTex = m?.tex
                curId = matIds.getOrPut(n) { matIds.size }
            } else if (cmd == "f") {
                fv.n = 0
                var bad = false
                val vcount = vx.n / 3
                val tcount = vt.n / 2
                val textured = b.useTexture(files, curTex)
                while (st.hasMoreTokens()) {
                    val tk = st.nextToken()
                    val s1 = tk.indexOf('/')
                    var vi = 0
                    var ti = 0
                    if (s1 < 0) {
                        vi = tk.toIntOrNull() ?: 0
                    } else {
                        vi = tk.substring(0, s1).toIntOrNull() ?: 0
                        val s2 = tk.indexOf('/', s1 + 1)
                        val t = if (s2 < 0) tk.substring(s1 + 1) else tk.substring(s1 + 1, s2)
                        ti = t.toIntOrNull() ?: 0
                    }
                    val vIdx = if (vi > 0) vi - 1 else if (vi < 0) vcount + vi else -1
                    val tIdx = if (ti > 0) ti - 1 else if (ti < 0) tcount + ti else -1
                    if (vIdx < 0 || vIdx >= vcount || vIdx >= 2000000) { bad = true; break }
                    val tOk = tIdx in 0 until tcount && tIdx < 4000000
                    val key = (vIdx.toLong() shl 42) or ((if (tOk) tIdx + 1 else 0).toLong() shl 20) or curId.toLong()
                    var vi2 = keyMap[key]
                    if (vi2 == null) {
                        val u = if (tOk) vt.a[tIdx * 2] else 0f
                        val v = if (tOk) 1f - vt.a[tIdx * 2 + 1] else 0f
                        vi2 = b.vertex(vx.a[vIdx * 3], vx.a[vIdx * 3 + 1], vx.a[vIdx * 3 + 2], u, v, curRgb, textured)
                        keyMap[key] = vi2
                    }
                    fv.add(vi2)
                }
                if (bad || fv.n < 3) continue
                for (k in 1 until fv.n - 1) {
                    b.tri(fv.a[0], fv.a[k], fv.a[k + 1])
                    tris++
                }
                if (tris > MAX_TRIS_IN) throw ImportException("too many triangles")
            }
        }
    }

    // ------------------------------------------------------------------ STL
    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)

    private fun parseStl(b: Builder, bytes: ByteArray) {
        val bin = bytes.size >= 84 && run {
            val cnt = le32(bytes, 80)
            cnt >= 0 && 84L + 50L * cnt == bytes.size.toLong()
        }
        if (bin) {
            val cnt = le32(bytes, 80)
            if (cnt > MAX_TRIS_IN) throw ImportException("too many triangles")
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            var o = 84
            for (t in 0 until cnt) {
                val base = b.count
                for (k in 0 until 3) {
                    val p = o + 12 + k * 12
                    b.vertex(bb.getFloat(p), bb.getFloat(p + 4), bb.getFloat(p + 8), 0f, 0f, 0xFFFFFF, false)
                }
                b.tri(base, base + 1, base + 2)
                o += 50
            }
        } else {
            val text = String(bytes, Charsets.ISO_8859_1)
            val tmp = FloatArray(9)
            var n = 0
            for (raw in text.split('\n')) {
                val s = raw.trim()
                if (!s.startsWith("vertex")) continue
                val st = StringTokenizer(s)
                st.nextToken()
                if (st.countTokens() < 3) continue
                tmp[n * 3] = st.nextToken().toFloatOrNull() ?: 0f
                tmp[n * 3 + 1] = st.nextToken().toFloatOrNull() ?: 0f
                tmp[n * 3 + 2] = st.nextToken().toFloatOrNull() ?: 0f
                n++
                if (n == 3) {
                    val base = b.count
                    for (k in 0 until 3) b.vertex(tmp[k * 3], tmp[k * 3 + 1], tmp[k * 3 + 2], 0f, 0f, 0xFFFFFF, false)
                    b.tri(base, base + 1, base + 2)
                    n = 0
                    if (b.idx.n / 3 > MAX_TRIS_IN) throw ImportException("too many triangles")
                }
            }
        }
    }

    // ------------------------------------------------------------------ PLY
    private class PlyProp(val name: String, val type: String, val listCount: String?, val listItem: String?)

    private class PlyEl(val name: String, val count: Int) {
        val props = ArrayList<PlyProp>()
    }

    private class PlyReader(val bytes: ByteArray, var pos: Int, ascii: Boolean, little: Boolean) {
        val bb: ByteBuffer = ByteBuffer.wrap(bytes).order(if (little) ByteOrder.LITTLE_ENDIAN else ByteOrder.BIG_ENDIAN)
        val tok: StringTokenizer? = if (ascii) StringTokenizer(String(bytes, pos, bytes.size - pos, Charsets.ISO_8859_1)) else null

        private fun size(t: String): Int = when (t) {
            "char", "int8", "uchar", "uint8" -> 1
            "short", "int16", "ushort", "uint16" -> 2
            "int", "int32", "uint", "uint32", "float", "float32" -> 4
            "double", "float64" -> 8
            else -> throw ImportException("PLY: unknown type " + t)
        }

        fun read(t: String): Double {
            val tk = tok
            if (tk != null) {
                if (!tk.hasMoreTokens()) throw ImportException("PLY data ends too early")
                return tk.nextToken().toDouble()
            }
            val sz = size(t)
            if (pos + sz > bytes.size) throw ImportException("PLY data ends too early")
            val v: Double = when (t) {
                "char", "int8" -> bb.get(pos).toDouble()
                "uchar", "uint8" -> (bb.get(pos).toInt() and 0xFF).toDouble()
                "short", "int16" -> bb.getShort(pos).toDouble()
                "ushort", "uint16" -> (bb.getShort(pos).toInt() and 0xFFFF).toDouble()
                "int", "int32" -> bb.getInt(pos).toDouble()
                "uint", "uint32" -> (bb.getInt(pos).toLong() and 0xFFFFFFFFL).toDouble()
                "float", "float32" -> bb.getFloat(pos).toDouble()
                else -> bb.getDouble(pos)
            }
            pos += sz
            return v
        }
    }

    private fun indexOf(h: ByteArray, key: ByteArray): Int {
        var i = 0
        while (i <= h.size - key.size) {
            var ok = true
            for (k in key.indices) if (h[i + k] != key[k]) { ok = false; break }
            if (ok) return i
            i++
        }
        return -1
    }

    private fun parsePly(b: Builder, files: Map<String, ByteArray>, bytes: ByteArray) {
        val hp = indexOf(bytes, "end_header".toByteArray(Charsets.ISO_8859_1))
        if (hp < 0) throw ImportException("PLY header not found")
        var q = hp + 10
        while (q < bytes.size && bytes[q] != '\n'.code.toByte()) q++
        q++
        val header = String(bytes, 0, hp, Charsets.ISO_8859_1)
        var ascii = true
        var little = true
        var texFile: String? = null
        val els = ArrayList<PlyEl>()
        for (raw in header.split('\n')) {
            val s = raw.trim()
            if (s.isEmpty()) continue
            val st = StringTokenizer(s)
            val cmd = st.nextToken()
            if (cmd == "format") {
                val f = if (st.hasMoreTokens()) st.nextToken() else ""
                ascii = f == "ascii"
                little = f != "binary_big_endian"
            } else if (cmd == "comment") {
                val rest = s.substring(7).trim()
                if (rest.startsWith("TextureFile ")) texFile = rest.substring(12).trim()
            } else if (cmd == "element") {
                if (st.countTokens() < 2) continue
                val n = st.nextToken()
                val c = st.nextToken().toIntOrNull() ?: 0
                els.add(PlyEl(n, c))
            } else if (cmd == "property" && els.isNotEmpty()) {
                val t = if (st.hasMoreTokens()) st.nextToken() else ""
                if (t == "list" && st.countTokens() >= 3) {
                    val ct = st.nextToken()
                    val it = st.nextToken()
                    els[els.size - 1].props.add(PlyProp(st.nextToken(), t, ct, it))
                } else if (st.hasMoreTokens()) {
                    els[els.size - 1].props.add(PlyProp(st.nextToken(), t, null, null))
                }
            }
        }
        val rd = PlyReader(bytes, q, ascii, little)
        val textured = b.useTexture(files, texFile)
        var base = 0
        for (el in els) {
            if (el.count < 0 || el.count > 5000000) throw ImportException("PLY: bad element count")
            if (el.name == "vertex") {
                base = b.count
                for (i in 0 until el.count) {
                    var x = 0.0; var y = 0.0; var z = 0.0
                    var u = 0.0; var v = 0.0
                    var r = 255.0; var g = 255.0; var bl = 255.0
                    for (pr in el.props) {
                        if (pr.listCount != null) {
                            val n = rd.read(pr.listCount).toInt()
                            for (k in 0 until n) rd.read(pr.listItem ?: "int")
                            continue
                        }
                        val value = rd.read(pr.type)
                        val isF = pr.type.startsWith("float") || pr.type == "double"
                        when (pr.name) {
                            "x" -> x = value
                            "y" -> y = value
                            "z" -> z = value
                            "u", "s", "texture_u", "texture_s" -> u = value
                            "v", "t", "texture_v", "texture_t" -> v = value
                            "red" -> r = if (isF) value * 255.0 else value
                            "green" -> g = if (isF) value * 255.0 else value
                            "blue" -> bl = if (isF) value * 255.0 else value
                        }
                    }
                    val rgb = (r.toInt().coerceIn(0, 255) shl 16) or (g.toInt().coerceIn(0, 255) shl 8) or bl.toInt().coerceIn(0, 255)
                    b.vertex(x.toFloat(), y.toFloat(), z.toFloat(), u.toFloat(), (1.0 - v).toFloat(), rgb, textured)
                }
            } else if (el.name == "face") {
                val nv = b.count - base
                for (i in 0 until el.count) {
                    for (pr in el.props) {
                        if (pr.listCount == null) {
                            rd.read(pr.type)
                            continue
                        }
                        val n = rd.read(pr.listCount).toInt()
                        val ids = IntArray(Math.max(n, 0))
                        for (k in 0 until n) ids[k] = rd.read(pr.listItem ?: "int").toInt()
                        if (pr.name != "vertex_indices" && pr.name != "vertex_index") continue
                        var ok = n >= 3
                        for (k in 0 until n) if (ids[k] < 0 || ids[k] >= nv) ok = false
                        if (!ok) continue
                        for (k in 1 until n - 1) b.tri(base + ids[0], base + ids[k], base + ids[k + 1])
                    }
                    if (b.idx.n / 3 > MAX_TRIS_IN) throw ImportException("too many triangles")
                }
            } else {
                for (i in 0 until el.count) {
                    for (pr in el.props) {
                        if (pr.listCount != null) {
                            val n = rd.read(pr.listCount).toInt()
                            for (k in 0 until n) rd.read(pr.listItem ?: "int")
                        } else {
                            rd.read(pr.type)
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ glTF / GLB
    private class Acc(val buf: ByteArray, val off: Int, val stride: Int, val count: Int, val comps: Int, val ctype: Int, val norm: Boolean) {
        val bb: ByteBuffer = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        val csize: Int = if (ctype == 5120 || ctype == 5121) 1 else if (ctype == 5122 || ctype == 5123) 2 else 4

        fun f(e: Int, c: Int): Float {
            val p = off + e * stride + c * csize
            return when (ctype) {
                5126 -> bb.getFloat(p)
                5120 -> { val v = bb.get(p).toFloat(); if (norm) Math.max(v / 127f, -1f) else v }
                5121 -> { val v = (bb.get(p).toInt() and 0xFF).toFloat(); if (norm) v / 255f else v }
                5122 -> { val v = bb.getShort(p).toFloat(); if (norm) Math.max(v / 32767f, -1f) else v }
                5123 -> { val v = (bb.getShort(p).toInt() and 0xFFFF).toFloat(); if (norm) v / 65535f else v }
                5125 -> (bb.getInt(p).toLong() and 0xFFFFFFFFL).toFloat()
                else -> 0f
            }
        }

        fun i(e: Int): Int {
            val p = off + e * stride
            return when (ctype) {
                5121 -> bb.get(p).toInt() and 0xFF
                5123 -> bb.getShort(p).toInt() and 0xFFFF
                5125 -> bb.getInt(p)
                else -> 0
            }
        }
    }

    private fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val o = FloatArray(16)
        for (c in 0 until 4) for (r in 0 until 4) {
            var s = 0f
            for (k in 0 until 4) s += a[k * 4 + r] * b[c * 4 + k]
            o[c * 4 + r] = s
        }
        return o
    }

    private fun identity(): FloatArray {
        val m = FloatArray(16)
        m[0] = 1f; m[5] = 1f; m[10] = 1f; m[15] = 1f
        return m
    }

    private fun localMatrix(node: JSONObject): FloatArray {
        val mj = node.optJSONArray("matrix")
        if (mj != null && mj.length() == 16) {
            val m = FloatArray(16)
            for (k in 0 until 16) m[k] = mj.optDouble(k, 0.0).toFloat()
            return m
        }
        val t = node.optJSONArray("translation")
        val r = node.optJSONArray("rotation")
        val s = node.optJSONArray("scale")
        val tx = (t?.optDouble(0, 0.0) ?: 0.0).toFloat(); val ty = (t?.optDouble(1, 0.0) ?: 0.0).toFloat(); val tz = (t?.optDouble(2, 0.0) ?: 0.0).toFloat()
        var qx = (r?.optDouble(0, 0.0) ?: 0.0).toFloat(); var qy = (r?.optDouble(1, 0.0) ?: 0.0).toFloat()
        var qz = (r?.optDouble(2, 0.0) ?: 0.0).toFloat(); var qw = (r?.optDouble(3, 1.0) ?: 1.0).toFloat()
        val ql = Math.sqrt((qx * qx + qy * qy + qz * qz + qw * qw).toDouble()).toFloat()
        if (ql > 1e-6f) { qx /= ql; qy /= ql; qz /= ql; qw /= ql } else { qx = 0f; qy = 0f; qz = 0f; qw = 1f }
        val sx = (s?.optDouble(0, 1.0) ?: 1.0).toFloat(); val sy = (s?.optDouble(1, 1.0) ?: 1.0).toFloat(); val sz = (s?.optDouble(2, 1.0) ?: 1.0).toFloat()
        val m = FloatArray(16)
        m[0] = (1f - 2f * (qy * qy + qz * qz)) * sx
        m[1] = 2f * (qx * qy + qz * qw) * sx
        m[2] = 2f * (qx * qz - qy * qw) * sx
        m[4] = 2f * (qx * qy - qz * qw) * sy
        m[5] = (1f - 2f * (qx * qx + qz * qz)) * sy
        m[6] = 2f * (qy * qz + qx * qw) * sy
        m[8] = 2f * (qx * qz + qy * qw) * sz
        m[9] = 2f * (qy * qz - qx * qw) * sz
        m[10] = (1f - 2f * (qx * qx + qy * qy)) * sz
        m[12] = tx; m[13] = ty; m[14] = tz; m[15] = 1f
        return m
    }

    private class GltfCtx(val root: JSONObject, val glbBin: ByteArray?, val files: Map<String, ByteArray>) {
        val bufCache = HashMap<Int, ByteArray>()
        val imgCache = HashMap<Int, Bitmap?>()
        val accessors: JSONArray? = root.optJSONArray("accessors")
        val views: JSONArray? = root.optJSONArray("bufferViews")

        fun loadUri(uri: String): ByteArray? {
            if (uri.startsWith("data:")) {
                val c = uri.indexOf(',')
                if (c < 0) return null
                return try { Base64.decode(uri.substring(c + 1), Base64.DEFAULT) } catch (_: Exception) { null }
            }
            val name = try { java.net.URLDecoder.decode(uri.replace("+", "%2B"), "UTF-8") } catch (_: Exception) { uri }
            return findFile(files, name)
        }

        fun buffer(i: Int): ByteArray {
            val c = bufCache[i]
            if (c != null) return c
            val bufs = root.optJSONArray("buffers") ?: throw ImportException("glTF has no buffers")
            val bo = bufs.optJSONObject(i) ?: throw ImportException("glTF buffer " + i + " missing")
            val uri = bo.optString("uri", "")
            val data: ByteArray = if (uri.isEmpty()) {
                glbBin ?: throw ImportException("GLB data chunk missing")
            } else {
                loadUri(uri) ?: throw ImportException("select the buffer file too: " + uri)
            }
            bufCache[i] = data
            return data
        }

        fun acc(i: Int): Acc? {
            if (i < 0) return null
            val a = accessors?.optJSONObject(i) ?: return null
            val bvi = a.optInt("bufferView", -1)
            if (bvi < 0) return null
            val bv = views?.optJSONObject(bvi) ?: return null
            val buf = buffer(bv.optInt("buffer", 0))
            val comps = when (a.optString("type", "")) {
                "SCALAR" -> 1; "VEC2" -> 2; "VEC3" -> 3; "VEC4" -> 4; "MAT2" -> 4; "MAT3" -> 9; "MAT4" -> 16
                else -> 0
            }
            if (comps == 0) return null
            val ctype = a.optInt("componentType", 5126)
            val csize = if (ctype == 5120 || ctype == 5121) 1 else if (ctype == 5122 || ctype == 5123) 2 else 4
            val count = a.optInt("count", 0)
            val off = bv.optInt("byteOffset", 0) + a.optInt("byteOffset", 0)
            val bs = bv.optInt("byteStride", 0)
            val stride = if (bs > 0) bs else comps * csize
            if (count <= 0 || off < 0) return null
            if (off.toLong() + (count - 1).toLong() * stride + comps * csize > buf.size) throw ImportException("glTF accessor is outside its buffer")
            return Acc(buf, off, stride, count, comps, ctype, a.optBoolean("normalized", false))
        }

        fun image(i: Int): Bitmap? {
            if (imgCache.containsKey(i)) return imgCache[i]
            var bm: Bitmap? = null
            val im = root.optJSONArray("images")?.optJSONObject(i)
            if (im != null) {
                var data: ByteArray? = null
                val uri = im.optString("uri", "")
                if (uri.isNotEmpty()) {
                    data = loadUri(uri)
                } else {
                    val bv = views?.optJSONObject(im.optInt("bufferView", -1))
                    if (bv != null) {
                        val buf = buffer(bv.optInt("buffer", 0))
                        val off = bv.optInt("byteOffset", 0)
                        val len = bv.optInt("byteLength", 0)
                        if (off >= 0 && len > 0 && off + len <= buf.size) data = buf.copyOfRange(off, off + len)
                    }
                }
                if (data != null) bm = Tex.fromBytes(data, Tex.MAX_SIDE)
            }
            imgCache[i] = bm
            return bm
        }
    }

    private fun parseGltf(b: Builder, files: Map<String, ByteArray>, bytes: ByteArray) {
        var jsonText: String
        var bin: ByteArray? = null
        val isGlb = bytes.size >= 20 && bytes[0] == 'g'.code.toByte() && bytes[1] == 'l'.code.toByte() &&
            bytes[2] == 'T'.code.toByte() && bytes[3] == 'F'.code.toByte()
        if (isGlb) {
            var o = 12
            var js: String? = null
            while (o + 8 <= bytes.size) {
                val len = le32(bytes, o)
                val type = le32(bytes, o + 4)
                if (len < 0 || o + 8 + len > bytes.size) break
                if (type == 0x4E4F534A) js = String(bytes, o + 8, len, Charsets.UTF_8)
                else if (type == 0x004E4942 && bin == null) bin = bytes.copyOfRange(o + 8, o + 8 + len)
                o += 8 + ((len + 3) and 3.inv())
            }
            jsonText = js ?: throw ImportException("GLB has no JSON part")
        } else {
            jsonText = String(bytes, Charsets.UTF_8)
        }
        val root = JSONObject(jsonText)
        val req = root.optJSONArray("extensionsRequired")
        if (req != null) {
            for (k in 0 until req.length()) {
                val e = req.optString(k, "")
                if (e == "KHR_draco_mesh_compression" || e == "EXT_meshopt_compression") {
                    throw ImportException("compressed glTF ($e) is not supported - export it without compression")
                }
            }
        }
        val ctx = GltfCtx(root, bin, files)
        val nodes = root.optJSONArray("nodes")
        val meshes = root.optJSONArray("meshes") ?: throw ImportException("glTF has no meshes")
        var visited = 0

        fun addMesh(mi: Int, m: FloatArray) {
            val mesh = meshes.optJSONObject(mi) ?: return
            val prims = mesh.optJSONArray("primitives") ?: return
            for (pi in 0 until prims.length()) {
                val pr = prims.optJSONObject(pi) ?: continue
                val mode = pr.optInt("mode", 4)
                if (mode != 4 && mode != 5 && mode != 6) continue
                val at = pr.optJSONObject("attributes") ?: continue
                val pa = ctx.acc(at.optInt("POSITION", -1)) ?: continue
                if (pa.comps < 3) continue
                val ua = ctx.acc(at.optInt("TEXCOORD_0", -1))
                val ca = ctx.acc(at.optInt("COLOR_0", -1))
                val mat = root.optJSONArray("materials")?.optJSONObject(pr.optInt("material", -1))
                val pbr = mat?.optJSONObject("pbrMetallicRoughness")
                val bc = pbr?.optJSONArray("baseColorFactor")
                val mr = (bc?.optDouble(0, 1.0) ?: 1.0).toFloat()
                val mg = (bc?.optDouble(1, 1.0) ?: 1.0).toFloat()
                val mb = (bc?.optDouble(2, 1.0) ?: 1.0).toFloat()
                var textured = false
                val ti = pbr?.optJSONObject("baseColorTexture")?.optInt("index", -1) ?: -1
                if (ti >= 0 && ua != null) {
                    val src = root.optJSONArray("textures")?.optJSONObject(ti)?.optInt("source", -1) ?: -1
                    if (src >= 0) {
                        val bm = ctx.image(src)
                        if (bm != null) {
                            if (b.texBmp == null) { b.texBmp = bm; b.texKey = "img" + src }
                            textured = b.texKey == "img" + src
                        }
                    }
                }
                val base = b.count
                for (e in 0 until pa.count) {
                    val x = pa.f(e, 0); val y = pa.f(e, 1); val z = pa.f(e, 2)
                    val wx = m[0] * x + m[4] * y + m[8] * z + m[12]
                    val wy = m[1] * x + m[5] * y + m[9] * z + m[13]
                    val wz = m[2] * x + m[6] * y + m[10] * z + m[14]
                    var u = 0f; var v = 0f
                    if (ua != null && e < ua.count) { u = ua.f(e, 0); v = ua.f(e, 1) }
                    var cr = mr; var cg = mg; var cb = mb
                    if (ca != null && e < ca.count && ca.comps >= 3) {
                        cr *= ca.f(e, 0); cg *= ca.f(e, 1); cb *= ca.f(e, 2)
                    }
                    b.vertex(wx, wy, wz, u, v, pack(cr, cg, cb), textured)
                }
                val ia = ctx.acc(pr.optInt("indices", -1))
                val n = if (ia != null) ia.count else pa.count
                fun ix(k: Int): Int = if (ia != null) ia.i(k) else k
                fun put(p: Int, q: Int, r: Int) {
                    if (p < 0 || q < 0 || r < 0 || p >= pa.count || q >= pa.count || r >= pa.count) return
                    b.tri(base + p, base + q, base + r)
                }
                if (mode == 4) {
                    var k = 0
                    while (k + 2 < n) { put(ix(k), ix(k + 1), ix(k + 2)); k += 3 }
                } else if (mode == 5) {
                    for (k in 0 until n - 2) {
                        if (k % 2 == 0) put(ix(k), ix(k + 1), ix(k + 2)) else put(ix(k + 1), ix(k), ix(k + 2))
                    }
                } else {
                    for (k in 1 until n - 1) put(ix(0), ix(k), ix(k + 1))
                }
                if (b.idx.n / 3 > MAX_TRIS_IN) throw ImportException("too many triangles")
            }
        }

        fun walk(n: Int, parent: FloatArray, depth: Int) {
            if (depth > 64 || visited++ > 50000) return
            val node = nodes?.optJSONObject(n) ?: return
            val m = mul(parent, localMatrix(node))
            val mi = node.optInt("mesh", -1)
            if (mi >= 0) addMesh(mi, m)
            val ch = node.optJSONArray("children")
            if (ch != null) for (k in 0 until ch.length()) walk(ch.optInt(k, -1), m, depth + 1)
        }

        val scenes = root.optJSONArray("scenes")
        val sc = scenes?.optJSONObject(root.optInt("scene", 0)) ?: scenes?.optJSONObject(0)
        val roots = sc?.optJSONArray("nodes")
        if (nodes != null && roots != null) {
            for (k in 0 until roots.length()) walk(roots.optInt(k, -1), identity(), 0)
        } else if (nodes != null && nodes.length() > 0) {
            val isChild = BooleanArray(nodes.length())
            for (k in 0 until nodes.length()) {
                val ch = nodes.optJSONObject(k)?.optJSONArray("children") ?: continue
                for (c in 0 until ch.length()) {
                    val ci = ch.optInt(c, -1)
                    if (ci >= 0 && ci < isChild.size) isChild[ci] = true
                }
            }
            for (k in 0 until nodes.length()) if (!isChild[k]) walk(k, identity(), 0)
        } else {
            for (k in 0 until meshes.length()) addMesh(k, identity())
        }
    }

    // ------------------------------------------------------------------ common finishing
    private fun finish(b: Builder, up: Boolean, id: String, name: String, texId: String): ImportResult {
        if (b.count < 3 || b.idx.n < 3) throw ImportException("no triangles found in the file")
        val p = b.pos.a
        val nv = b.count
        if (up) {
            for (i in 0 until nv) {
                val y = p[i * 3 + 1]
                val z = p[i * 3 + 2]
                p[i * 3 + 1] = -z
                p[i * 3 + 2] = y
            }
        }
        var x0 = Float.MAX_VALUE; var y0 = Float.MAX_VALUE; var z0 = Float.MAX_VALUE
        var x1 = -Float.MAX_VALUE; var y1 = -Float.MAX_VALUE; var z1 = -Float.MAX_VALUE
        for (i in 0 until nv) {
            val x = p[i * 3]; val y = p[i * 3 + 1]; val z = p[i * 3 + 2]
            if (x.isNaN() || y.isNaN() || z.isNaN() || x.isInfinite() || y.isInfinite() || z.isInfinite()) throw ImportException("model has broken numbers")
            if (x < x0) x0 = x; if (x > x1) x1 = x
            if (y < y0) y0 = y; if (y > y1) y1 = y
            if (z < z0) z0 = z; if (z > z1) z1 = z
        }
        val ex = x1 - x0
        val ey = y1 - y0
        val ez = z1 - z0
        val big = Math.max(ex, Math.max(ey, ez))
        if (!(big > 1e-9f)) throw ImportException("model has no size")
        for (i in 0 until nv) {
            p[i * 3] = if (ex > 1e-9f) (p[i * 3] - x0) / ex else 0f
            p[i * 3 + 1] = if (ey > 1e-9f) (p[i * 3 + 1] - y0) / ey else 0f
            p[i * 3 + 2] = if (ez > 1e-9f) (p[i * 3 + 2] - z0) / ez else 0f
        }
        val k = 6f / big
        val sx = Math.max(ex * k, 0.05f)
        val sy = Math.max(ey * k, 0.05f)
        val sz = Math.max(ez * k, 0.05f)

        var work = b
        val trisIn = b.idx.n / 3
        var cut = false
        if (trisIn > MAX_TRIS) {
            cut = true
            var res = 160
            while (true) {
                work = cluster(b, res)
                if (work.idx.n / 3 <= MAX_TRIS || res <= 4) break
                res = Math.max(4, (res * 0.85f).toInt())
            }
            if (work.idx.n < 3) throw ImportException("model too complex to simplify")
        }

        // keep only vertices that are used
        val used = BooleanArray(work.count)
        for (i in 0 until work.idx.n) used[work.idx.a[i]] = true
        val remap = IntArray(work.count)
        var m = 0
        for (i in 0 until work.count) if (used[i]) remap[i] = m++
        val hasTex = b.texBmp != null
        val v = FloatArray(m * 3)
        val uv: FloatArray? = if (hasTex) FloatArray(m * 2) else null
        val col = IntArray(m)
        var anyCol = false
        for (i in 0 until work.count) {
            if (!used[i]) continue
            val o = remap[i]
            v[o * 3] = q4(work.pos.a[i * 3]); v[o * 3 + 1] = q4(work.pos.a[i * 3 + 1]); v[o * 3 + 2] = q4(work.pos.a[i * 3 + 2])
            if (uv != null) {
                if (work.flag.a[i] != 0) {
                    uv[o * 2] = q4(work.uv.a[i * 2]); uv[o * 2 + 1] = q4(work.uv.a[i * 2 + 1])
                } else {
                    uv[o * 2] = -100f; uv[o * 2 + 1] = -100f
                }
            }
            col[o] = work.col.a[i] and 0xFFFFFF
            if (col[o] != 0xFFFFFF) anyCol = true
        }
        val idx = IntArray(work.idx.n)
        for (i in idx.indices) idx[i] = remap[work.idx.a[i]]

        val texList = ArrayList<ETex>()
        var texRef: String? = null
        val bm = b.texBmp
        if (bm != null) {
            texList.add(Tex.make(texId, name.take(30), bm))
            texRef = texId
        }
        val model = EModel(id, name, v, idx, uv, if (anyCol) col else null, sx, sy, sz, texRef)
        val notes = ArrayList<String>(b.notes)
        if (cut) notes.add("simplified from " + trisIn + " to " + model.tris + " triangles")
        return ImportResult(model, texList, notes.joinToString("; "))
    }

    private fun q4(f: Float): Float = Math.round(f * 10000f) / 10000f

    /** Vertex clustering: all vertices in one cell of a [res]^3 grid become one vertex. */
    private fun cluster(b: Builder, res: Int): Builder {
        val nb = Builder()
        nb.texBmp = b.texBmp
        val map = HashMap<Long, Int>()
        val remap = IntArray(b.count)
        val cnt = IA()
        for (i in 0 until b.count) {
            val cx = Math.min(Math.max((b.pos.a[i * 3] * res).toInt(), 0), res - 1)
            val cy = Math.min(Math.max((b.pos.a[i * 3 + 1] * res).toInt(), 0), res - 1)
            val cz = Math.min(Math.max((b.pos.a[i * 3 + 2] * res).toInt(), 0), res - 1)
            val key = (cx.toLong() shl 40) or (cy.toLong() shl 20) or cz.toLong()
            val have = map[key]
            if (have == null) {
                val ni = nb.vertex(b.pos.a[i * 3], b.pos.a[i * 3 + 1], b.pos.a[i * 3 + 2], b.uv.a[i * 2], b.uv.a[i * 2 + 1], b.col.a[i], b.flag.a[i] != 0)
                map[key] = ni
                cnt.add(1)
                remap[i] = ni
            } else {
                nb.pos.a[have * 3] += b.pos.a[i * 3]
                nb.pos.a[have * 3 + 1] += b.pos.a[i * 3 + 1]
                nb.pos.a[have * 3 + 2] += b.pos.a[i * 3 + 2]
                cnt.a[have]++
                remap[i] = have
            }
        }
        for (i in 0 until nb.count) {
            val c = cnt.a[i].toFloat()
            nb.pos.a[i * 3] /= c; nb.pos.a[i * 3 + 1] /= c; nb.pos.a[i * 3 + 2] /= c
        }
        var t = 0
        while (t + 2 < b.idx.n) {
            val a = remap[b.idx.a[t]]
            val c1 = remap[b.idx.a[t + 1]]
            val c2 = remap[b.idx.a[t + 2]]
            if (a != c1 && c1 != c2 && a != c2) nb.tri(a, c1, c2)
            t += 3
        }
        return nb
    }
}
