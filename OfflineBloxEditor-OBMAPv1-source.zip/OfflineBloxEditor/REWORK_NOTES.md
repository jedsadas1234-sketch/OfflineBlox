# OfflineBlox Editor coordinated package pass

## Implemented in this source pass
- Added the shared OBMAP v1 package codec to both Editor and Engine.
- `.map` export writes a binary package: fixed header, readable JSON manifest, binary PNG texture chunks, binary mesh chunks, asset offsets and SHA-256 checksums.
- Editor `.map` open accepts OBMAP v1 and legacy JSON. Internal project autosaves and the Code panel remain readable JSON.
- Engine `.map` export/import and startup loading accept OBMAP v1 and legacy JSON, and preserve the package bytes on disk.
- Added an Editor GitHub Actions workflow. Engine workflow now explicitly installs the required Android SDK, NDK and CMake versions.
- Increased JSON source limits to accommodate embedded mesh data during the current compatibility bridge.

## Still outstanding
- Engine `WorldRenderer` is still primitive-box-only. This pass makes the package portable and readable, but does not claim in-game model/texture rendering is finished.
- Multi-material glTF/OBJ import still needs a richer per-primitive material representation. Current Editor `EModel` has one texture reference per model.
- Multiplayer currently transfers the legacy JSON representation, not the binary package stream.
- A full Android Gradle build could not be run in the current build environment because it has no Android SDK/NDK, no Gradle installation/wrapper JAR, and outbound network/DNS is unavailable. The GitHub Actions workflows are prepared to perform the real APK builds.
