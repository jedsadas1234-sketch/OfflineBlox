package com.offlineblox.app

import android.content.Context
import android.net.wifi.WifiManager
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.Collections
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

object Proto {
    const val TCP_PORT = 47777
    const val UDP_PORT = 47778
    const val MAGIC = "OFFLINEBLOX1"

    fun clean(s: String, max: Int = 16): String {
        val t = s.trim().replace(Regex("[\\s|,]+"), "_").take(max)
        return if (t.isEmpty()) "Player" else t
    }

    fun f(v: Float): String = String.format(Locale.US, "%.2f", v)

    fun stateLine(x: Float, y: Float, z: Float, yaw: Float, moving: Boolean): String =
        "${f(x)} ${f(y)} ${f(z)} ${f(yaw)} ${if (moving) 1 else 0}"
}

interface NetListener {
    fun onJoin(id: Int, name: String, avatar: String)
    fun onState(id: Int, x: Float, y: Float, z: Float, yaw: Float, moving: Boolean)
    fun onLeave(id: Int)
    fun onChat(id: Int, text: String)
    fun onStatus(msg: String)
}

class Conn(val id: Int, val sock: Socket) {
    private val out = BufferedWriter(OutputStreamWriter(sock.getOutputStream(), Charsets.UTF_8))
    val input = BufferedReader(InputStreamReader(sock.getInputStream(), Charsets.UTF_8))
    var name = "Player"
    var avatar = ""

    fun send(line: String): Boolean {
        return try {
            synchronized(out) {
                out.write(line)
                out.write("\n")
                out.flush()
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun close() {
        try { sock.close() } catch (e: Exception) { }
    }
}

/** เครื่องที่กด "เปิดเซิร์ฟ" เป็นโฮสต์: รับคนเข้า + ประกาศห้องทาง UDP */
class NetHost(
    private val roomName: String,
    private val mapId: String,
    private val myName: String,
    private val myAvatar: String,
    private val l: NetListener
) {
    private val conns = CopyOnWriteArrayList<Conn>()
    private val running = AtomicBoolean(false)
    private var server: ServerSocket? = null
    private var udp: DatagramSocket? = null
    private var nextId = 1

    fun playerCount(): Int = conns.size + 1

    fun start() {
        if (!running.compareAndSet(false, true)) return
        Thread { acceptLoop() }.apply { isDaemon = true }.start()
        Thread { announceLoop() }.apply { isDaemon = true }.start()
    }

    fun stop() {
        running.set(false)
        try { server?.close() } catch (e: Exception) { }
        try { udp?.close() } catch (e: Exception) { }
        for (c in conns) c.close()
        conns.clear()
    }

    private fun broadcast(line: String, except: Conn?) {
        for (c in conns) if (c !== except) c.send(line)
    }

    fun sendState(x: Float, y: Float, z: Float, yaw: Float, moving: Boolean) {
        broadcast("P 0 ${Proto.stateLine(x, y, z, yaw, moving)}", null)
    }

    fun sendChat(text: String) {
        val t = text.take(120)
        broadcast("M 0 $t", null)
        l.onChat(0, t)
    }

    private fun acceptLoop() {
        try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(Proto.TCP_PORT))
            server = ss
            l.onStatus("เปิดเซิร์ฟแล้ว (พอร์ต ${Proto.TCP_PORT})")
            while (running.get()) {
                val s = ss.accept()
                Thread { handle(s) }.apply { isDaemon = true }.start()
            }
        } catch (e: Exception) {
            if (running.getAndSet(false)) l.onStatus("เปิดเซิร์ฟไม่ได้: ${e.message}")
        }
    }

    private fun handle(s: Socket) {
        val id = synchronized(this) { nextId++ }
        val c = Conn(id, s)
        var joined = false
        try {
            s.tcpNoDelay = true
            s.soTimeout = 5000
            val hello = c.input.readLine() ?: return
            s.soTimeout = 0
            val p = hello.split(" ", limit = 3)
            if (p.size < 3 || p[0] != "HELLO") return
            c.name = Proto.clean(p[1])
            c.avatar = p[2]
            c.send("WELCOME $id $mapId")
            c.send("J 0 ${Proto.clean(myName)} $myAvatar")
            for (o in conns) c.send("J ${o.id} ${o.name} ${o.avatar}")
            conns.add(c)
            joined = true
            broadcast("J $id ${c.name} ${c.avatar}", c)
            l.onJoin(id, c.name, c.avatar)

            while (running.get()) {
                val line = c.input.readLine() ?: break
                if (line.startsWith("S ")) {
                    val t = line.split(" ")
                    if (t.size >= 6) {
                        val x = t[1].toFloatOrNull() ?: continue
                        val y = t[2].toFloatOrNull() ?: continue
                        val z = t[3].toFloatOrNull() ?: continue
                        val yaw = t[4].toFloatOrNull() ?: continue
                        val m = t[5] == "1"
                        broadcast("P $id ${Proto.stateLine(x, y, z, yaw, m)}", c)
                        l.onState(id, x, y, z, yaw, m)
                    }
                } else if (line.startsWith("C ")) {
                    val text = line.substring(2).take(120)
                    broadcast("M $id $text", null)
                    l.onChat(id, text)
                }
            }
        } catch (e: Exception) {
            // ผู้เล่นหลุด
        } finally {
            conns.remove(c)
            c.close()
            if (joined) {
                broadcast("L $id", null)
                l.onLeave(id)
            }
        }
    }

    private fun broadcastAddrs(): List<InetAddress> {
        val out = ArrayList<InetAddress>()
        try { out.add(InetAddress.getByName("255.255.255.255")) } catch (e: Exception) { }
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) {
                    val b = ia.broadcast
                    if (b != null) out.add(b)
                }
            }
        } catch (e: Exception) { }
        return out
    }

    private fun announceLoop() {
        try {
            val sock = DatagramSocket()
            sock.broadcast = true
            udp = sock
            while (running.get()) {
                val msg = "${Proto.MAGIC}|${Proto.clean(roomName)}|$mapId|${Proto.clean(myName)}|" +
                    "${Proto.TCP_PORT}|${playerCount()}"
                val bytes = msg.toByteArray(Charsets.UTF_8)
                for (a in broadcastAddrs()) {
                    try {
                        sock.send(DatagramPacket(bytes, bytes.size, a, Proto.UDP_PORT))
                    } catch (e: Exception) { }
                }
                Thread.sleep(1000)
            }
        } catch (e: Exception) {
            // ปิดแล้ว
        }
    }
}

/** เครื่องที่เข้าร่วมห้องของคนอื่น */
class NetClient(
    private val ip: String,
    private val myName: String,
    private val myAvatar: String,
    private val expectMap: String,
    private val l: NetListener
) {
    private var conn: Conn? = null
    private val running = AtomicBoolean(false)
    @Volatile var myId = -1

    fun start() {
        running.set(true)
        Thread { loop() }.apply { isDaemon = true }.start()
    }

    fun stop() {
        running.set(false)
        conn?.close()
    }

    fun sendState(x: Float, y: Float, z: Float, yaw: Float, moving: Boolean) {
        conn?.send("S ${Proto.stateLine(x, y, z, yaw, moving)}")
    }

    fun sendChat(text: String) {
        conn?.send("C ${text.take(120)}")
    }

    private fun loop() {
        var err = false
        try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(ip, Proto.TCP_PORT), 5000)
            val c = Conn(-1, s)
            conn = c
            c.send("HELLO ${Proto.clean(myName)} $myAvatar")
            l.onStatus("เชื่อมต่อแล้ว")
            while (running.get()) {
                val line = c.input.readLine() ?: break
                try { handle(line) } catch (e: Exception) { }
            }
        } catch (e: Exception) {
            err = true
            if (running.get()) l.onStatus("ต่อไม่ได้: ${e.message}")
        } finally {
            val was = running.getAndSet(false)
            conn?.close()
            if (was && !err) l.onStatus("หลุดจากเซิร์ฟเวอร์")
        }
    }

    private fun handle(line: String) {
        val t = line.split(" ", limit = 3)
        when (t[0]) {
            "WELCOME" -> {
                myId = t.getOrNull(1)?.toIntOrNull() ?: -1
                val hostMap = t.getOrNull(2) ?: expectMap
                if (hostMap != expectMap) {
                    l.onStatus("แมพไม่ตรง! โฮสต์ใช้ \"${Maps.byId(hostMap).name}\" ออกแล้วเลือกแมพให้ตรงก่อน")
                }
            }
            "J" -> {
                val p = line.split(" ")
                if (p.size >= 4) l.onJoin(p[1].toInt(), p[2], p[3])
            }
            "L" -> t.getOrNull(1)?.toIntOrNull()?.let { l.onLeave(it) }
            "M" -> if (t.size >= 3) l.onChat(t[1].toIntOrNull() ?: -1, t[2])
            "P" -> {
                val p = line.split(" ")
                if (p.size >= 7) {
                    l.onState(
                        p[1].toInt(), p[2].toFloat(), p[3].toFloat(), p[4].toFloat(),
                        p[5].toFloat(), p[6] == "1"
                    )
                }
            }
        }
    }
}

class Room(
    val ip: String, val name: String, val mapId: String,
    val host: String, val port: Int, val players: Int
) {
    var seen = 0L
}

/** ฟังประกาศห้องทาง UDP broadcast ใน wifi/hotspot เดียวกัน */
class Discovery(private val ctx: Context, private val onChange: (List<Room>) -> Unit) {
    private val rooms = LinkedHashMap<String, Room>()
    private val running = AtomicBoolean(false)
    private var sock: DatagramSocket? = null
    private var lock: WifiManager.MulticastLock? = null

    fun start() {
        running.set(true)
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val ml = wm.createMulticastLock("offlineblox")
            ml.setReferenceCounted(false)
            ml.acquire()
            lock = ml
        } catch (e: Exception) { }
        Thread {
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(Proto.UDP_PORT))
                s.soTimeout = 1000
                sock = s
                val buf = ByteArray(512)
                while (running.get()) {
                    var changed = false
                    try {
                        val pk = DatagramPacket(buf, buf.size)
                        s.receive(pk)
                        val msg = String(pk.data, 0, pk.length, Charsets.UTF_8)
                        val p = msg.split("|")
                        if (p.size >= 6 && p[0] == Proto.MAGIC) {
                            val ip = pk.address.hostAddress ?: ""
                            val r = Room(
                                ip, p[1], p[2], p[3],
                                p[4].toIntOrNull() ?: Proto.TCP_PORT, p[5].toIntOrNull() ?: 1
                            )
                            r.seen = System.currentTimeMillis()
                            synchronized(rooms) { rooms[ip] = r }
                            changed = true
                        }
                    } catch (e: SocketTimeoutException) { }
                    val now = System.currentTimeMillis()
                    synchronized(rooms) {
                        val it = rooms.values.iterator()
                        while (it.hasNext()) {
                            if (now - it.next().seen > 4000) { it.remove(); changed = true }
                        }
                    }
                    if (changed) {
                        val snapshot = synchronized(rooms) { ArrayList(rooms.values) }
                        onChange(snapshot)
                    }
                }
            } catch (e: Exception) { }
        }.apply { isDaemon = true }.start()
    }

    fun stop() {
        running.set(false)
        try { sock?.close() } catch (e: Exception) { }
        try { lock?.release() } catch (e: Exception) { }
    }
}
