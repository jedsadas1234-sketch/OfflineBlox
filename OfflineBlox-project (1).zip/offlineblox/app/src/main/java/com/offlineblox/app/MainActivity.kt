package com.offlineblox.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

class MainActivity : Activity() {
    private var selected = "grass"
    private lateinit var nameEdit: EditText
    private val cards = HashMap<String, LinearLayout>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(this)
        val prefs = getSharedPreferences("ob", MODE_PRIVATE)
        selected = prefs.getString("map", "grass") ?: "grass"

        val root = Ui.row(this)
        root.setBackgroundColor(Ui.BG)
        val pad = Ui.dp(this, 24)
        root.setPadding(pad, pad, pad, pad)

        // ซ้าย: ชื่อเกม + ปุ่มหลัก
        val left = Ui.col(this)
        left.gravity = Gravity.CENTER_VERTICAL
        left.addView(Ui.label(this, "OFFLINEBLOX", 36f, Ui.GREEN, true))
        left.addView(Ui.label(this, "เล่นด้วยกันผ่าน Wi-Fi / Hotspot ไม่ต้องใช้เน็ต ไม่ต้องแอดเพื่อน", 13f, Ui.DIM))

        nameEdit = EditText(this)
        nameEdit.setText(prefs.getString("name", "Player"))
        nameEdit.hint = "ชื่อของมึง"
        nameEdit.setTextColor(Ui.TEXT)
        nameEdit.setHintTextColor(Ui.DIM)
        nameEdit.setSingleLine(true)
        nameEdit.filters = arrayOf(InputFilter.LengthFilter(14))
        nameEdit.background = Ui.box(Ui.PANEL, 0x55FFFFFF, 2, this)
        nameEdit.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10))
        left.addView(nameEdit, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 8, this))

        left.addView(Ui.button(this, "▶  เล่นแมพนี้", Ui.GREEN) {
            start(saveName(), "solo", null)
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        left.addView(Ui.button(this, "📡  หาห้องใกล้ๆ / เข้าห้องเพื่อน", Ui.BLUE) {
            saveName()
            startActivity(Intent(this, RoomsActivity::class.java))
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        left.addView(Ui.button(this, "👕  แต่งตัว", Ui.GRAY) {
            saveName()
            startActivity(Intent(this, AvatarActivity::class.java))
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))

        root.addView(left, Ui.lp(0, Ui.MATCH, 1f, 0, this))

        // ขวา: เลือกแมพ
        val right = Ui.col(this)
        right.addView(Ui.label(this, "เลือกแมพ", 18f, Ui.TEXT, true))
        val list = Ui.col(this)
        for (m in Maps.all) {
            val card = Ui.col(this)
            card.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12))
            card.addView(Ui.label(this, m.name, 18f, Ui.TEXT, true))
            card.addView(Ui.label(this, m.desc, 13f, Ui.DIM))
            card.setOnClickListener { select(m.id) }
            cards[m.id] = card
            list.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 6, this))
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        right.addView(scroll, Ui.lp(Ui.MATCH, Ui.MATCH, 1f, 0, this))
        root.addView(right, Ui.lp(0, Ui.MATCH, 1f, 0, this))

        setContentView(root)
        select(selected)
    }

    override fun onResume() {
        super.onResume()
        Ui.immersive(this)
    }

    private fun select(id: String) {
        selected = id
        getSharedPreferences("ob", MODE_PRIVATE).edit().putString("map", id).apply()
        for ((mid, card) in cards) {
            card.background = if (mid == id) Ui.box(0xFF214A2B.toInt(), 0xFF4CD964.toInt(), 3, this)
            else Ui.box(Ui.PANEL, 0x33FFFFFF, 2, this)
        }
    }

    private fun saveName(): String {
        val n = nameEdit.text.toString().trim().ifEmpty { "Player" }
        getSharedPreferences("ob", MODE_PRIVATE).edit().putString("name", n).apply()
        return n
    }

    private fun start(name: String, mode: String, ip: String?) {
        val i = Intent(this, GameActivity::class.java)
        i.putExtra("mode", mode)
        i.putExtra("map", selected)
        i.putExtra("name", name)
        if (ip != null) i.putExtra("ip", ip)
        startActivity(i)
    }
}
