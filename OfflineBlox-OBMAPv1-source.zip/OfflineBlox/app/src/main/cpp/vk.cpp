// OfflineBlox Vulkan renderer (instanced boxes, textured + lit + shadow map).
#include <jni.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <vulkan/vulkan.h>
#include <vulkan/vulkan_android.h>
#include <vector>
#include <string>
#include <cstring>
#include <cstdint>
#include <algorithm>

#include "box_vert.inc"
#include "box_frag.inc"
#include "shadow_vert.inc"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "OfflineBloxVK", __VA_ARGS__)

static const uint32_t SHADOW_SIZE = 2048;
static const uint32_t ATLAS_W = 384, ATLAS_H = 448, ATLAS_LAYERS = 32;
static const uint32_t WORLD_SZ = 128;
static const uint32_t MAX_INST = 6000;
static const uint32_t INST_STRIDE = 96;
static const uint32_t UBO_SIZE = 240;
static const uint32_t RT_SIZE = 6144;

struct Ctx {
    VkInstance inst = VK_NULL_HANDLE;
    VkPhysicalDevice phys = VK_NULL_HANDLE;
    VkDevice dev = VK_NULL_HANDLE;
    VkQueue queue = VK_NULL_HANDLE;
    uint32_t qfam = 0;
    ANativeWindow* win = nullptr;
    VkSurfaceKHR surf = VK_NULL_HANDLE;
    VkSwapchainKHR sc = VK_NULL_HANDLE;
    VkFormat scFormat = VK_FORMAT_UNDEFINED;
    VkExtent2D ext{};
    std::vector<VkImage> scImages;
    std::vector<VkImageView> scViews;
    std::vector<VkFramebuffer> fbs;
    std::vector<VkSemaphore> renderDone;
    VkSemaphore imgAvail = VK_NULL_HANDLE;
    VkFence fence = VK_NULL_HANDLE;
    VkCommandPool pool = VK_NULL_HANDLE;
    VkCommandBuffer cmd = VK_NULL_HANDLE;
    VkFormat depthFmt = VK_FORMAT_UNDEFINED;
    VkImage depthImg = VK_NULL_HANDLE;
    VkDeviceMemory depthMem = VK_NULL_HANDLE;
    VkImageView depthView = VK_NULL_HANDLE;
    VkRenderPass rpMain = VK_NULL_HANDLE;
    VkRenderPass rpShadow = VK_NULL_HANDLE;
    VkImage shImg = VK_NULL_HANDLE;
    VkDeviceMemory shMem = VK_NULL_HANDLE;
    VkImageView shAttView = VK_NULL_HANDLE;
    VkImageView shSampView = VK_NULL_HANDLE;
    VkFramebuffer shFb = VK_NULL_HANDLE;
    VkSampler shSamp = VK_NULL_HANDLE;
    VkImage atlasImg = VK_NULL_HANDLE;
    VkDeviceMemory atlasMem = VK_NULL_HANDLE;
    VkImageView atlasView = VK_NULL_HANDLE;
    VkSampler atlasSamp = VK_NULL_HANDLE;
    VkImage worldImg = VK_NULL_HANDLE;
    VkDeviceMemory worldMem = VK_NULL_HANDLE;
    VkImageView worldView = VK_NULL_HANDLE;
    VkSampler worldSamp = VK_NULL_HANDLE;
    VkDescriptorSetLayout dsl = VK_NULL_HANDLE;
    VkDescriptorPool dpool = VK_NULL_HANDLE;
    VkDescriptorSet dset = VK_NULL_HANDLE;
    VkPipelineLayout plLayout = VK_NULL_HANDLE;
    VkPipeline plMain = VK_NULL_HANDLE;
    VkPipeline plShadow = VK_NULL_HANDLE;
    VkBuffer vbuf = VK_NULL_HANDLE, ibuf = VK_NULL_HANDLE, instBuf = VK_NULL_HANDLE, uboBuf = VK_NULL_HANDLE;
    VkDeviceMemory vmem = VK_NULL_HANDLE, imem = VK_NULL_HANDLE, instMem = VK_NULL_HANDLE, uboMem = VK_NULL_HANDLE;
    void* instMap = nullptr;
    void* uboMap = nullptr;
    VkBuffer rtBuf = VK_NULL_HANDLE;
    VkDeviceMemory rtMem = VK_NULL_HANDLE;
    void* rtMap = nullptr;
    bool ready = false;
};

static Ctx g;
static std::string gErr;

static bool bad(const char* what, VkResult r) {
    gErr = std::string(what) + " failed: " + std::to_string((int)r);
    LOGE("%s", gErr.c_str());
    return false;
}
#define CK(x) do { VkResult _r = (x); if (_r != VK_SUCCESS) return bad(#x, _r); } while (0)

// ---------------------------------------------------------------- helpers
static uint32_t findMem(uint32_t bits, VkMemoryPropertyFlags props) {
    VkPhysicalDeviceMemoryProperties mp;
    vkGetPhysicalDeviceMemoryProperties(g.phys, &mp);
    for (uint32_t i = 0; i < mp.memoryTypeCount; i++) {
        if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & props) == props) return i;
    }
    return 0xFFFFFFFFu;
}

static bool makeBuffer(VkDeviceSize size, VkBufferUsageFlags usage, VkMemoryPropertyFlags props, VkBuffer& buf, VkDeviceMemory& mem) {
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = size;
    bi.usage = usage;
    bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    CK(vkCreateBuffer(g.dev, &bi, nullptr, &buf));
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(g.dev, buf, &mr);
    uint32_t mt = findMem(mr.memoryTypeBits, props);
    if (mt == 0xFFFFFFFFu) { gErr = "no memory type for buffer"; return false; }
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = mt;
    CK(vkAllocateMemory(g.dev, &ai, nullptr, &mem));
    CK(vkBindBufferMemory(g.dev, buf, mem, 0));
    return true;
}

static bool makeImage(uint32_t w, uint32_t h, uint32_t layers, VkFormat fmt, VkImageUsageFlags usage, VkImage& img, VkDeviceMemory& mem) {
    VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    ii.imageType = VK_IMAGE_TYPE_2D;
    ii.format = fmt;
    ii.extent = {w, h, 1};
    ii.mipLevels = 1;
    ii.arrayLayers = layers;
    ii.samples = VK_SAMPLE_COUNT_1_BIT;
    ii.tiling = VK_IMAGE_TILING_OPTIMAL;
    ii.usage = usage;
    ii.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    CK(vkCreateImage(g.dev, &ii, nullptr, &img));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(g.dev, img, &mr);
    uint32_t mt = findMem(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    if (mt == 0xFFFFFFFFu) mt = findMem(mr.memoryTypeBits, 0);
    if (mt == 0xFFFFFFFFu) { gErr = "no memory type for image"; return false; }
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    ai.memoryTypeIndex = mt;
    CK(vkAllocateMemory(g.dev, &ai, nullptr, &mem));
    CK(vkBindImageMemory(g.dev, img, mem, 0));
    return true;
}

static VkImageView makeView(VkImage img, VkFormat fmt, VkImageAspectFlags asp, VkImageViewType type, uint32_t layers) {
    VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    vi.image = img;
    vi.viewType = type;
    vi.format = fmt;
    vi.subresourceRange = {asp, 0, 1, 0, layers};
    VkImageView v = VK_NULL_HANDLE;
    if (vkCreateImageView(g.dev, &vi, nullptr, &v) != VK_SUCCESS) { gErr = "vkCreateImageView failed"; return VK_NULL_HANDLE; }
    return v;
}

static VkSampler makeSampler(VkFilter filter, VkSamplerAddressMode mode, bool compare) {
    VkSamplerCreateInfo si{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
    si.magFilter = filter;
    si.minFilter = filter;
    si.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
    si.addressModeU = mode;
    si.addressModeV = mode;
    si.addressModeW = mode;
    si.maxLod = 0.0f;
    si.compareEnable = compare ? VK_TRUE : VK_FALSE;
    si.compareOp = VK_COMPARE_OP_LESS_OR_EQUAL;
    si.borderColor = VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE;
    VkSampler s = VK_NULL_HANDLE;
    if (vkCreateSampler(g.dev, &si, nullptr, &s) != VK_SUCCESS) { gErr = "vkCreateSampler failed"; return VK_NULL_HANDLE; }
    return s;
}

static VkCommandBuffer beginOnce() {
    VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    ai.commandPool = g.pool;
    ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ai.commandBufferCount = 1;
    VkCommandBuffer c = VK_NULL_HANDLE;
    vkAllocateCommandBuffers(g.dev, &ai, &c);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(c, &bi);
    return c;
}

static void endOnce(VkCommandBuffer c) {
    vkEndCommandBuffer(c);
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1;
    si.pCommandBuffers = &c;
    vkQueueSubmit(g.queue, 1, &si, VK_NULL_HANDLE);
    vkQueueWaitIdle(g.queue);
    vkFreeCommandBuffers(g.dev, g.pool, 1, &c);
}

static void barrier(VkCommandBuffer c, VkImage img, VkImageAspectFlags asp, uint32_t layer0, uint32_t layers,
                    VkImageLayout from, VkImageLayout to, VkAccessFlags sa, VkAccessFlags da,
                    VkPipelineStageFlags ss, VkPipelineStageFlags ds) {
    VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    b.srcAccessMask = sa;
    b.dstAccessMask = da;
    b.oldLayout = from;
    b.newLayout = to;
    b.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    b.image = img;
    b.subresourceRange = {asp, 0, 1, layer0, layers};
    vkCmdPipelineBarrier(c, ss, ds, 0, 0, nullptr, 0, nullptr, 1, &b);
}

static bool uploadImage(VkImage img, uint32_t layer, uint32_t w, uint32_t h, const std::vector<uint8_t>& px) {
    VkBuffer sb = VK_NULL_HANDLE;
    VkDeviceMemory sm = VK_NULL_HANDLE;
    if (!makeBuffer(px.size(), VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
                    VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, sb, sm)) return false;
    void* p = nullptr;
    vkMapMemory(g.dev, sm, 0, px.size(), 0, &p);
    memcpy(p, px.data(), px.size());
    vkUnmapMemory(g.dev, sm);
    VkCommandBuffer c = beginOnce();
    barrier(c, img, VK_IMAGE_ASPECT_COLOR_BIT, layer, 1, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
            VK_ACCESS_SHADER_READ_BIT, VK_ACCESS_TRANSFER_WRITE_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
    VkBufferImageCopy rg{};
    rg.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, layer, 1};
    rg.imageExtent = {w, h, 1};
    vkCmdCopyBufferToImage(c, sb, img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &rg);
    barrier(c, img, VK_IMAGE_ASPECT_COLOR_BIT, layer, 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
            VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    endOnce(c);
    vkDestroyBuffer(g.dev, sb, nullptr);
    vkFreeMemory(g.dev, sm, nullptr);
    return true;
}

static bool hasStencil(VkFormat f) { return f == VK_FORMAT_D24_UNORM_S8_UINT || f == VK_FORMAT_D32_SFLOAT_S8_UINT; }

// ---------------------------------------------------------------- init pieces
static bool createInstance(bool withSurface) {
    VkApplicationInfo ai{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    ai.pApplicationName = "OfflineBlox";
    ai.apiVersion = VK_API_VERSION_1_0;
    const char* exts[] = {VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME};
    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &ai;
    if (withSurface) {
        ci.enabledExtensionCount = 2;
        ci.ppEnabledExtensionNames = exts;
    }
    CK(vkCreateInstance(&ci, nullptr, &g.inst));
    return true;
}

static bool pickDevice(bool needSurface) {
    uint32_t n = 0;
    vkEnumeratePhysicalDevices(g.inst, &n, nullptr);
    if (n == 0) { gErr = "no Vulkan devices"; return false; }
    std::vector<VkPhysicalDevice> devs(n);
    vkEnumeratePhysicalDevices(g.inst, &n, devs.data());
    for (auto d : devs) {
        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(d, &qn, nullptr);
        std::vector<VkQueueFamilyProperties> qs(qn);
        vkGetPhysicalDeviceQueueFamilyProperties(d, &qn, qs.data());
        for (uint32_t i = 0; i < qn; i++) {
            if (!(qs[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)) continue;
            if (needSurface) {
                VkBool32 ok = VK_FALSE;
                vkGetPhysicalDeviceSurfaceSupportKHR(d, i, g.surf, &ok);
                if (!ok) continue;
            }
            g.phys = d;
            g.qfam = i;
            return true;
        }
    }
    gErr = "no suitable GPU queue";
    return false;
}

static bool createDevice() {
    float prio = 1.0f;
    VkDeviceQueueCreateInfo qi{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qi.queueFamilyIndex = g.qfam;
    qi.queueCount = 1;
    qi.pQueuePriorities = &prio;
    const char* dext[] = {VK_KHR_SWAPCHAIN_EXTENSION_NAME};
    VkDeviceCreateInfo di{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    di.queueCreateInfoCount = 1;
    di.pQueueCreateInfos = &qi;
    di.enabledExtensionCount = 1;
    di.ppEnabledExtensionNames = dext;
    CK(vkCreateDevice(g.phys, &di, nullptr, &g.dev));
    vkGetDeviceQueue(g.dev, g.qfam, 0, &g.queue);
    return true;
}

static bool pickDepth() {
    VkFormat cands[] = {VK_FORMAT_D32_SFLOAT, VK_FORMAT_D16_UNORM, VK_FORMAT_D24_UNORM_S8_UINT, VK_FORMAT_D32_SFLOAT_S8_UINT};
    for (VkFormat f : cands) {
        VkFormatProperties p;
        vkGetPhysicalDeviceFormatProperties(g.phys, f, &p);
        VkFormatFeatureFlags need = VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT;
        if ((p.optimalTilingFeatures & need) == need) { g.depthFmt = f; return true; }
    }
    gErr = "no usable depth format";
    return false;
}

static bool createSwapchain() {
    VkSurfaceCapabilitiesKHR caps;
    CK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(g.phys, g.surf, &caps));
    uint32_t fn = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(g.phys, g.surf, &fn, nullptr);
    if (fn == 0) { gErr = "no surface formats"; return false; }
    std::vector<VkSurfaceFormatKHR> fm(fn);
    vkGetPhysicalDeviceSurfaceFormatsKHR(g.phys, g.surf, &fn, fm.data());
    VkSurfaceFormatKHR chosen = fm[0];
    for (auto& f : fm) {
        if (f.format == VK_FORMAT_R8G8B8A8_UNORM || f.format == VK_FORMAT_B8G8R8A8_UNORM) { chosen = f; break; }
    }
    int ww = ANativeWindow_getWidth(g.win);
    int wh = ANativeWindow_getHeight(g.win);
    VkExtent2D ext;
    ext.width = std::max(caps.minImageExtent.width, std::min(caps.maxImageExtent.width, (uint32_t)std::max(ww, 1)));
    ext.height = std::max(caps.minImageExtent.height, std::min(caps.maxImageExtent.height, (uint32_t)std::max(wh, 1)));
    uint32_t cnt = caps.minImageCount + 1;
    if (caps.maxImageCount > 0 && cnt > caps.maxImageCount) cnt = caps.maxImageCount;
    VkSwapchainCreateInfoKHR si{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
    si.surface = g.surf;
    si.minImageCount = cnt;
    si.imageFormat = chosen.format;
    si.imageColorSpace = chosen.colorSpace;
    si.imageExtent = ext;
    si.imageArrayLayers = 1;
    si.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    si.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    si.preTransform = (caps.supportedTransforms & VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR)
                          ? VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR : caps.currentTransform;
    si.compositeAlpha = (caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR)
                            ? VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR : VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;
    si.presentMode = VK_PRESENT_MODE_FIFO_KHR;
    si.clipped = VK_TRUE;
    CK(vkCreateSwapchainKHR(g.dev, &si, nullptr, &g.sc));
    g.scFormat = chosen.format;
    g.ext = ext;
    uint32_t n = 0;
    vkGetSwapchainImagesKHR(g.dev, g.sc, &n, nullptr);
    g.scImages.resize(n);
    vkGetSwapchainImagesKHR(g.dev, g.sc, &n, g.scImages.data());
    for (uint32_t i = 0; i < n; i++) {
        VkImageView v = makeView(g.scImages[i], g.scFormat, VK_IMAGE_ASPECT_COLOR_BIT, VK_IMAGE_VIEW_TYPE_2D, 1);
        if (v == VK_NULL_HANDLE) return false;
        g.scViews.push_back(v);
    }
    return true;
}

static bool createDepthAndFramebuffers() {
    if (!makeImage(g.ext.width, g.ext.height, 1, g.depthFmt, VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT, g.depthImg, g.depthMem)) return false;
    VkImageAspectFlags asp = VK_IMAGE_ASPECT_DEPTH_BIT | (hasStencil(g.depthFmt) ? VK_IMAGE_ASPECT_STENCIL_BIT : 0);
    g.depthView = makeView(g.depthImg, g.depthFmt, asp, VK_IMAGE_VIEW_TYPE_2D, 1);
    if (g.depthView == VK_NULL_HANDLE) return false;
    for (size_t i = 0; i < g.scViews.size(); i++) {
        VkImageView at[2] = {g.scViews[i], g.depthView};
        VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fi.renderPass = g.rpMain;
        fi.attachmentCount = 2;
        fi.pAttachments = at;
        fi.width = g.ext.width;
        fi.height = g.ext.height;
        fi.layers = 1;
        VkFramebuffer fb = VK_NULL_HANDLE;
        CK(vkCreateFramebuffer(g.dev, &fi, nullptr, &fb));
        g.fbs.push_back(fb);
        VkSemaphoreCreateInfo sci{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        VkSemaphore sem = VK_NULL_HANDLE;
        CK(vkCreateSemaphore(g.dev, &sci, nullptr, &sem));
        g.renderDone.push_back(sem);
    }
    return true;
}

static void destroySwap() {
    if (!g.dev) return;
    for (auto f : g.fbs) vkDestroyFramebuffer(g.dev, f, nullptr);
    g.fbs.clear();
    for (auto s : g.renderDone) vkDestroySemaphore(g.dev, s, nullptr);
    g.renderDone.clear();
    for (auto v : g.scViews) vkDestroyImageView(g.dev, v, nullptr);
    g.scViews.clear();
    g.scImages.clear();
    if (g.depthView) vkDestroyImageView(g.dev, g.depthView, nullptr);
    if (g.depthImg) vkDestroyImage(g.dev, g.depthImg, nullptr);
    if (g.depthMem) vkFreeMemory(g.dev, g.depthMem, nullptr);
    g.depthView = VK_NULL_HANDLE; g.depthImg = VK_NULL_HANDLE; g.depthMem = VK_NULL_HANDLE;
    if (g.sc) vkDestroySwapchainKHR(g.dev, g.sc, nullptr);
    g.sc = VK_NULL_HANDLE;
}

static bool recreateSwap() {
    vkDeviceWaitIdle(g.dev);
    destroySwap();
    return createSwapchain() && createDepthAndFramebuffers();
}

static bool createRenderPasses() {
    {
        VkAttachmentDescription att[2]{};
        att[0].format = g.scFormat;
        att[0].samples = VK_SAMPLE_COUNT_1_BIT;
        att[0].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        att[0].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        att[0].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        att[0].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        att[0].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        att[0].finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
        att[1].format = g.depthFmt;
        att[1].samples = VK_SAMPLE_COUNT_1_BIT;
        att[1].loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        att[1].storeOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        att[1].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        att[1].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        att[1].initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        att[1].finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
        VkAttachmentReference cref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
        VkAttachmentReference dref{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
        VkSubpassDescription sp{};
        sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
        sp.colorAttachmentCount = 1;
        sp.pColorAttachments = &cref;
        sp.pDepthStencilAttachment = &dref;
        VkSubpassDependency dep{};
        dep.srcSubpass = VK_SUBPASS_EXTERNAL;
        dep.dstSubpass = 0;
        dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT;
        dep.dstStageMask = dep.srcStageMask;
        dep.srcAccessMask = 0;
        dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
        ri.attachmentCount = 2;
        ri.pAttachments = att;
        ri.subpassCount = 1;
        ri.pSubpasses = &sp;
        ri.dependencyCount = 1;
        ri.pDependencies = &dep;
        CK(vkCreateRenderPass(g.dev, &ri, nullptr, &g.rpMain));
    }
    {
        VkAttachmentDescription a{};
        a.format = g.depthFmt;
        a.samples = VK_SAMPLE_COUNT_1_BIT;
        a.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR;
        a.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        a.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        a.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        a.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        a.finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
        VkAttachmentReference dref{0, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
        VkSubpassDescription sp{};
        sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS;
        sp.pDepthStencilAttachment = &dref;
        VkSubpassDependency deps[2]{};
        deps[0].srcSubpass = VK_SUBPASS_EXTERNAL;
        deps[0].dstSubpass = 0;
        deps[0].srcStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        deps[0].dstStageMask = VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
        deps[0].srcAccessMask = VK_ACCESS_SHADER_READ_BIT;
        deps[0].dstAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        deps[0].dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;
        deps[1].srcSubpass = 0;
        deps[1].dstSubpass = VK_SUBPASS_EXTERNAL;
        deps[1].srcStageMask = VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
        deps[1].dstStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        deps[1].srcAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
        deps[1].dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
        deps[1].dependencyFlags = VK_DEPENDENCY_BY_REGION_BIT;
        VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
        ri.attachmentCount = 1;
        ri.pAttachments = &a;
        ri.subpassCount = 1;
        ri.pSubpasses = &sp;
        ri.dependencyCount = 2;
        ri.pDependencies = deps;
        CK(vkCreateRenderPass(g.dev, &ri, nullptr, &g.rpShadow));
    }
    return true;
}

static VkShaderModule makeModule(const unsigned char* code, size_t size) {
    VkShaderModuleCreateInfo mi{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    mi.codeSize = size;
    mi.pCode = reinterpret_cast<const uint32_t*>(code);
    VkShaderModule m = VK_NULL_HANDLE;
    if (vkCreateShaderModule(g.dev, &mi, nullptr, &m) != VK_SUCCESS) { gErr = "vkCreateShaderModule failed"; return VK_NULL_HANDLE; }
    return m;
}

static bool createPipeline(bool shadow) {
    VkShaderModule vs = shadow ? makeModule(shadow_vert_spv, sizeof(shadow_vert_spv)) : makeModule(box_vert_spv, sizeof(box_vert_spv));
    VkShaderModule fs = shadow ? VK_NULL_HANDLE : makeModule(box_frag_spv, sizeof(box_frag_spv));
    if (vs == VK_NULL_HANDLE || (!shadow && fs == VK_NULL_HANDLE)) return false;
    VkPipelineShaderStageCreateInfo st[2]{};
    st[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT;
    st[0].module = vs;
    st[0].pName = "main";
    st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT;
    st[1].module = fs;
    st[1].pName = "main";

    VkVertexInputBindingDescription vb[2] = {
        {0, 36, VK_VERTEX_INPUT_RATE_VERTEX},
        {1, INST_STRIDE, VK_VERTEX_INPUT_RATE_INSTANCE}};
    VkVertexInputAttributeDescription va[10] = {
        {0, 0, VK_FORMAT_R32G32B32_SFLOAT, 0},
        {1, 0, VK_FORMAT_R32G32B32_SFLOAT, 12},
        {2, 0, VK_FORMAT_R32G32_SFLOAT, 24},
        {3, 0, VK_FORMAT_R32_SFLOAT, 32},
        {4, 1, VK_FORMAT_R32G32B32A32_SFLOAT, 0},
        {5, 1, VK_FORMAT_R32G32B32A32_SFLOAT, 16},
        {6, 1, VK_FORMAT_R32G32B32A32_SFLOAT, 32},
        {7, 1, VK_FORMAT_R32G32B32A32_SFLOAT, 48},
        {8, 1, VK_FORMAT_R32G32B32A32_SFLOAT, 64},
        {9, 1, VK_FORMAT_R32G32B32A32_SFLOAT, 80}};
    VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    vi.vertexBindingDescriptionCount = 2;
    vi.pVertexBindingDescriptions = vb;
    vi.vertexAttributeDescriptionCount = 10;
    vi.pVertexAttributeDescriptions = va;
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount = 1;
    vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL;
    rs.cullMode = VK_CULL_MODE_NONE;
    rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    rs.lineWidth = 1.0f;
    if (shadow) {
        rs.depthBiasEnable = VK_TRUE;
        rs.depthBiasConstantFactor = 1.5f;
        rs.depthBiasSlopeFactor = 2.0f;
    }
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineDepthStencilStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};
    ds.depthTestEnable = VK_TRUE;
    ds.depthWriteEnable = VK_TRUE;
    ds.depthCompareOp = VK_COMPARE_OP_LESS;
    VkPipelineColorBlendAttachmentState cba{};
    cba.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cb.attachmentCount = shadow ? 0 : 1;
    cb.pAttachments = &cba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo dy{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    dy.dynamicStateCount = 2;
    dy.pDynamicStates = dyn;

    VkGraphicsPipelineCreateInfo pi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    pi.stageCount = shadow ? 1 : 2;
    pi.pStages = st;
    pi.pVertexInputState = &vi;
    pi.pInputAssemblyState = &ia;
    pi.pViewportState = &vp;
    pi.pRasterizationState = &rs;
    pi.pMultisampleState = &ms;
    pi.pDepthStencilState = &ds;
    pi.pColorBlendState = &cb;
    pi.pDynamicState = &dy;
    pi.layout = g.plLayout;
    pi.renderPass = shadow ? g.rpShadow : g.rpMain;
    pi.subpass = 0;
    VkResult r = vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &pi, nullptr, shadow ? &g.plShadow : &g.plMain);
    vkDestroyShaderModule(g.dev, vs, nullptr);
    if (fs != VK_NULL_HANDLE) vkDestroyShaderModule(g.dev, fs, nullptr);
    if (r != VK_SUCCESS) return bad("vkCreateGraphicsPipelines", r);
    return true;
}

static bool createDescriptors() {
    VkDescriptorSetLayoutBinding b[5]{};
    b[0].binding = 0;
    b[0].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    b[0].descriptorCount = 1;
    b[0].stageFlags = VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT;
    for (int i = 1; i < 4; i++) {
        b[i].binding = i;
        b[i].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
        b[i].descriptorCount = 1;
        b[i].stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    }
    b[4].binding = 4;
    b[4].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    b[4].descriptorCount = 1;
    b[4].stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    VkDescriptorSetLayoutCreateInfo li{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    li.bindingCount = 5;
    li.pBindings = b;
    CK(vkCreateDescriptorSetLayout(g.dev, &li, nullptr, &g.dsl));
    VkPipelineLayoutCreateInfo pl{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    pl.setLayoutCount = 1;
    pl.pSetLayouts = &g.dsl;
    CK(vkCreatePipelineLayout(g.dev, &pl, nullptr, &g.plLayout));
    VkDescriptorPoolSize ps[2] = {{VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 2}, {VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 3}};
    VkDescriptorPoolCreateInfo dp{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dp.maxSets = 1;
    dp.poolSizeCount = 2;
    dp.pPoolSizes = ps;
    CK(vkCreateDescriptorPool(g.dev, &dp, nullptr, &g.dpool));
    VkDescriptorSetAllocateInfo ai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    ai.descriptorPool = g.dpool;
    ai.descriptorSetCount = 1;
    ai.pSetLayouts = &g.dsl;
    CK(vkAllocateDescriptorSets(g.dev, &ai, &g.dset));
    return true;
}

static void writeDescriptors() {
    VkDescriptorBufferInfo bi{g.uboBuf, 0, UBO_SIZE};
    VkDescriptorBufferInfo bi2{g.rtBuf, 0, RT_SIZE};
    VkDescriptorImageInfo ii[3] = {
        {g.atlasSamp, g.atlasView, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
        {g.worldSamp, g.worldView, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL},
        {g.shSamp, g.shSampView, VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL}};
    VkWriteDescriptorSet w[5]{};
    w[0].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    w[0].dstSet = g.dset;
    w[0].dstBinding = 0;
    w[0].descriptorCount = 1;
    w[0].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    w[0].pBufferInfo = &bi;
    for (int i = 0; i < 3; i++) {
        w[i + 1].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        w[i + 1].dstSet = g.dset;
        w[i + 1].dstBinding = i + 1;
        w[i + 1].descriptorCount = 1;
        w[i + 1].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
        w[i + 1].pImageInfo = &ii[i];
    }
    w[4].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    w[4].dstSet = g.dset;
    w[4].dstBinding = 4;
    w[4].descriptorCount = 1;
    w[4].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    w[4].pBufferInfo = &bi2;
    vkUpdateDescriptorSets(g.dev, 5, w, 0, nullptr);
}

static const float FACES[6][15] = {
    {1, 0, 0, .5f, -.5f, .5f, .5f, .5f, .5f, .5f, .5f, -.5f, .5f, -.5f, -.5f},
    {-1, 0, 0, -.5f, .5f, .5f, -.5f, -.5f, .5f, -.5f, -.5f, -.5f, -.5f, .5f, -.5f},
    {0, 1, 0, .5f, .5f, .5f, -.5f, .5f, .5f, -.5f, .5f, -.5f, .5f, .5f, -.5f},
    {0, -1, 0, -.5f, -.5f, .5f, .5f, -.5f, .5f, .5f, -.5f, -.5f, -.5f, -.5f, -.5f},
    {0, 0, 1, -.5f, -.5f, .5f, -.5f, .5f, .5f, .5f, .5f, .5f, .5f, -.5f, .5f},
    {0, 0, -1, .5f, -.5f, -.5f, .5f, .5f, -.5f, -.5f, .5f, -.5f, -.5f, -.5f, -.5f}};

static bool createBuffersAndTextures() {
    const VkMemoryPropertyFlags hv = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    float verts[24 * 9];
    uint16_t idx[36];
    const float uvs[8] = {0, 0, 1, 0, 1, 1, 0, 1};
    for (int f = 0; f < 6; f++) {
        for (int v = 0; v < 4; v++) {
            float* o = &verts[(f * 4 + v) * 9];
            o[0] = FACES[f][3 + v * 3]; o[1] = FACES[f][4 + v * 3]; o[2] = FACES[f][5 + v * 3];
            o[3] = FACES[f][0]; o[4] = FACES[f][1]; o[5] = FACES[f][2];
            o[6] = uvs[v * 2]; o[7] = uvs[v * 2 + 1];
            o[8] = (float)f;
        }
        uint16_t b = (uint16_t)(f * 4);
        uint16_t* k = &idx[f * 6];
        k[0] = b; k[1] = b + 1; k[2] = b + 2; k[3] = b; k[4] = b + 2; k[5] = b + 3;
    }
    void* p = nullptr;
    if (!makeBuffer(sizeof(verts), VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, hv, g.vbuf, g.vmem)) return false;
    vkMapMemory(g.dev, g.vmem, 0, sizeof(verts), 0, &p);
    memcpy(p, verts, sizeof(verts));
    vkUnmapMemory(g.dev, g.vmem);
    if (!makeBuffer(sizeof(idx), VK_BUFFER_USAGE_INDEX_BUFFER_BIT, hv, g.ibuf, g.imem)) return false;
    vkMapMemory(g.dev, g.imem, 0, sizeof(idx), 0, &p);
    memcpy(p, idx, sizeof(idx));
    vkUnmapMemory(g.dev, g.imem);
    if (!makeBuffer((VkDeviceSize)MAX_INST * INST_STRIDE, VK_BUFFER_USAGE_VERTEX_BUFFER_BIT, hv, g.instBuf, g.instMem)) return false;
    vkMapMemory(g.dev, g.instMem, 0, (VkDeviceSize)MAX_INST * INST_STRIDE, 0, &g.instMap);
    if (!makeBuffer(UBO_SIZE, VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, hv, g.uboBuf, g.uboMem)) return false;
    vkMapMemory(g.dev, g.uboMem, 0, UBO_SIZE, 0, &g.uboMap);
    memset(g.uboMap, 0, UBO_SIZE);
    if (!makeBuffer(RT_SIZE, VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, hv, g.rtBuf, g.rtMem)) return false;
    vkMapMemory(g.dev, g.rtMem, 0, RT_SIZE, 0, &g.rtMap);
    memset(g.rtMap, 0, RT_SIZE);

    // textures
    const VkImageUsageFlags tu = VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT;
    if (!makeImage(ATLAS_W, ATLAS_H, ATLAS_LAYERS, VK_FORMAT_R8G8B8A8_UNORM, tu, g.atlasImg, g.atlasMem)) return false;
    g.atlasView = makeView(g.atlasImg, VK_FORMAT_R8G8B8A8_UNORM, VK_IMAGE_ASPECT_COLOR_BIT, VK_IMAGE_VIEW_TYPE_2D_ARRAY, ATLAS_LAYERS);
    if (!makeImage(WORLD_SZ, WORLD_SZ, 1, VK_FORMAT_R8G8B8A8_UNORM, tu, g.worldImg, g.worldMem)) return false;
    g.worldView = makeView(g.worldImg, VK_FORMAT_R8G8B8A8_UNORM, VK_IMAGE_ASPECT_COLOR_BIT, VK_IMAGE_VIEW_TYPE_2D, 1);
    g.atlasSamp = makeSampler(VK_FILTER_LINEAR, VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE, false);
    g.worldSamp = makeSampler(VK_FILTER_LINEAR, VK_SAMPLER_ADDRESS_MODE_REPEAT, false);
    if (!g.atlasView || !g.worldView || !g.atlasSamp || !g.worldSamp) return false;
    VkCommandBuffer c = beginOnce();
    barrier(c, g.atlasImg, VK_IMAGE_ASPECT_COLOR_BIT, 0, ATLAS_LAYERS, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
            0, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    barrier(c, g.worldImg, VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
            0, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    endOnce(c);

    // shadow map
    if (!makeImage(SHADOW_SIZE, SHADOW_SIZE, 1, g.depthFmt, VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT, g.shImg, g.shMem)) return false;
    VkImageAspectFlags asp = VK_IMAGE_ASPECT_DEPTH_BIT | (hasStencil(g.depthFmt) ? VK_IMAGE_ASPECT_STENCIL_BIT : 0);
    g.shAttView = makeView(g.shImg, g.depthFmt, asp, VK_IMAGE_VIEW_TYPE_2D, 1);
    g.shSampView = makeView(g.shImg, g.depthFmt, VK_IMAGE_ASPECT_DEPTH_BIT, VK_IMAGE_VIEW_TYPE_2D, 1);
    g.shSamp = makeSampler(VK_FILTER_NEAREST, VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE, true);
    if (!g.shAttView || !g.shSampView || !g.shSamp) return false;
    VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
    fi.renderPass = g.rpShadow;
    fi.attachmentCount = 1;
    fi.pAttachments = &g.shAttView;
    fi.width = SHADOW_SIZE;
    fi.height = SHADOW_SIZE;
    fi.layers = 1;
    CK(vkCreateFramebuffer(g.dev, &fi, nullptr, &g.shFb));
    return true;
}

static void destroyAll() {
    if (g.dev) {
        vkDeviceWaitIdle(g.dev);
        destroySwap();
        if (g.fence) vkDestroyFence(g.dev, g.fence, nullptr);
        if (g.imgAvail) vkDestroySemaphore(g.dev, g.imgAvail, nullptr);
        if (g.plMain) vkDestroyPipeline(g.dev, g.plMain, nullptr);
        if (g.plShadow) vkDestroyPipeline(g.dev, g.plShadow, nullptr);
        if (g.plLayout) vkDestroyPipelineLayout(g.dev, g.plLayout, nullptr);
        if (g.dpool) vkDestroyDescriptorPool(g.dev, g.dpool, nullptr);
        if (g.dsl) vkDestroyDescriptorSetLayout(g.dev, g.dsl, nullptr);
        if (g.shFb) vkDestroyFramebuffer(g.dev, g.shFb, nullptr);
        if (g.shSamp) vkDestroySampler(g.dev, g.shSamp, nullptr);
        if (g.shSampView) vkDestroyImageView(g.dev, g.shSampView, nullptr);
        if (g.shAttView) vkDestroyImageView(g.dev, g.shAttView, nullptr);
        if (g.shImg) vkDestroyImage(g.dev, g.shImg, nullptr);
        if (g.shMem) vkFreeMemory(g.dev, g.shMem, nullptr);
        if (g.atlasSamp) vkDestroySampler(g.dev, g.atlasSamp, nullptr);
        if (g.atlasView) vkDestroyImageView(g.dev, g.atlasView, nullptr);
        if (g.atlasImg) vkDestroyImage(g.dev, g.atlasImg, nullptr);
        if (g.atlasMem) vkFreeMemory(g.dev, g.atlasMem, nullptr);
        if (g.worldSamp) vkDestroySampler(g.dev, g.worldSamp, nullptr);
        if (g.worldView) vkDestroyImageView(g.dev, g.worldView, nullptr);
        if (g.worldImg) vkDestroyImage(g.dev, g.worldImg, nullptr);
        if (g.worldMem) vkFreeMemory(g.dev, g.worldMem, nullptr);
        if (g.vbuf) vkDestroyBuffer(g.dev, g.vbuf, nullptr);
        if (g.vmem) vkFreeMemory(g.dev, g.vmem, nullptr);
        if (g.ibuf) vkDestroyBuffer(g.dev, g.ibuf, nullptr);
        if (g.imem) vkFreeMemory(g.dev, g.imem, nullptr);
        if (g.instBuf) vkDestroyBuffer(g.dev, g.instBuf, nullptr);
        if (g.instMem) vkFreeMemory(g.dev, g.instMem, nullptr);
        if (g.uboBuf) vkDestroyBuffer(g.dev, g.uboBuf, nullptr);
        if (g.uboMem) vkFreeMemory(g.dev, g.uboMem, nullptr);
        if (g.rtBuf) vkDestroyBuffer(g.dev, g.rtBuf, nullptr);
        if (g.rtMem) vkFreeMemory(g.dev, g.rtMem, nullptr);
        if (g.rpMain) vkDestroyRenderPass(g.dev, g.rpMain, nullptr);
        if (g.rpShadow) vkDestroyRenderPass(g.dev, g.rpShadow, nullptr);
        if (g.pool) vkDestroyCommandPool(g.dev, g.pool, nullptr);
        vkDestroyDevice(g.dev, nullptr);
    }
    if (g.inst) {
        if (g.surf) vkDestroySurfaceKHR(g.inst, g.surf, nullptr);
        vkDestroyInstance(g.inst, nullptr);
    }
    if (g.win) ANativeWindow_release(g.win);
    g = Ctx();
}

static std::string startVk(JNIEnv* env, jobject surface) {
    destroyAll();
    gErr.clear();
    if (!createInstance(true)) return gErr;
    g.win = ANativeWindow_fromSurface(env, surface);
    if (!g.win) return "ANativeWindow_fromSurface failed";
    VkAndroidSurfaceCreateInfoKHR sci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    sci.window = g.win;
    VkResult r = vkCreateAndroidSurfaceKHR(g.inst, &sci, nullptr, &g.surf);
    if (r != VK_SUCCESS) { bad("vkCreateAndroidSurfaceKHR", r); return gErr; }
    if (!pickDevice(true) || !createDevice() || !pickDepth()) return gErr;

    VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pi.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    pi.queueFamilyIndex = g.qfam;
    if (vkCreateCommandPool(g.dev, &pi, nullptr, &g.pool) != VK_SUCCESS) return "vkCreateCommandPool failed";
    VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    ai.commandPool = g.pool;
    ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    ai.commandBufferCount = 1;
    if (vkAllocateCommandBuffers(g.dev, &ai, &g.cmd) != VK_SUCCESS) return "vkAllocateCommandBuffers failed";
    VkSemaphoreCreateInfo sem{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
    if (vkCreateSemaphore(g.dev, &sem, nullptr, &g.imgAvail) != VK_SUCCESS) return "vkCreateSemaphore failed";
    VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    fi.flags = VK_FENCE_CREATE_SIGNALED_BIT;
    if (vkCreateFence(g.dev, &fi, nullptr, &g.fence) != VK_SUCCESS) return "vkCreateFence failed";

    if (!createSwapchain()) return gErr;
    if (!createRenderPasses()) return gErr;
    if (!createDepthAndFramebuffers()) return gErr;
    if (!createDescriptors()) return gErr;
    if (!createBuffersAndTextures()) return gErr;
    if (!createPipeline(false) || !createPipeline(true)) return gErr;
    writeDescriptors();
    g.ready = true;
    return "";
}

static std::string renderFrame(const void* inst, int nShadow, int nMain, const float* gl) {
    if (!g.ready) return "renderer not ready";
    vkWaitForFences(g.dev, 1, &g.fence, VK_TRUE, UINT64_MAX);
    uint32_t idx = 0;
    VkResult r = vkAcquireNextImageKHR(g.dev, g.sc, UINT64_MAX, g.imgAvail, VK_NULL_HANDLE, &idx);
    if (r == VK_ERROR_OUT_OF_DATE_KHR) {
        if (!recreateSwap()) return gErr;
        return "";
    }
    if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) return "vkAcquireNextImageKHR failed: " + std::to_string((int)r);
    vkResetFences(g.dev, 1, &g.fence);

    int total = nShadow + nMain;
    if (total > (int)MAX_INST) {
        nMain = std::max(0, (int)MAX_INST - nShadow);
        if (nShadow > (int)MAX_INST) nShadow = (int)MAX_INST;
        total = nShadow + nMain;
    }
    memcpy(g.instMap, inst, (size_t)total * INST_STRIDE);
    memcpy(g.uboMap, gl, UBO_SIZE);
    memcpy(g.rtMap, gl + 60, RT_SIZE);

    vkResetCommandBuffer(g.cmd, 0);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    vkBeginCommandBuffer(g.cmd, &bi);
    VkBuffer vbs[2] = {g.vbuf, g.instBuf};
    VkDeviceSize offs[2] = {0, 0};

    // shadow pass (always runs so the shadow image is in the right layout)
    {
        VkClearValue cv;
        cv.depthStencil = {1.0f, 0};
        VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
        rb.renderPass = g.rpShadow;
        rb.framebuffer = g.shFb;
        rb.renderArea = {{0, 0}, {SHADOW_SIZE, SHADOW_SIZE}};
        rb.clearValueCount = 1;
        rb.pClearValues = &cv;
        vkCmdBeginRenderPass(g.cmd, &rb, VK_SUBPASS_CONTENTS_INLINE);
        if (nShadow > 0) {
            vkCmdBindPipeline(g.cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, g.plShadow);
            VkViewport vp{0, 0, (float)SHADOW_SIZE, (float)SHADOW_SIZE, 0.0f, 1.0f};
            VkRect2D sc{{0, 0}, {SHADOW_SIZE, SHADOW_SIZE}};
            vkCmdSetViewport(g.cmd, 0, 1, &vp);
            vkCmdSetScissor(g.cmd, 0, 1, &sc);
            vkCmdBindDescriptorSets(g.cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, g.plLayout, 0, 1, &g.dset, 0, nullptr);
            vkCmdBindVertexBuffers(g.cmd, 0, 2, vbs, offs);
            vkCmdBindIndexBuffer(g.cmd, g.ibuf, 0, VK_INDEX_TYPE_UINT16);
            vkCmdDrawIndexed(g.cmd, 36, (uint32_t)nShadow, 0, 0, 0);
        }
        vkCmdEndRenderPass(g.cmd);
    }
    // main pass
    {
        VkClearValue cv[2];
        cv[0].color = {{gl[36], gl[37], gl[38], 1.0f}};
        cv[1].depthStencil = {1.0f, 0};
        VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
        rb.renderPass = g.rpMain;
        rb.framebuffer = g.fbs[idx];
        rb.renderArea = {{0, 0}, g.ext};
        rb.clearValueCount = 2;
        rb.pClearValues = cv;
        vkCmdBeginRenderPass(g.cmd, &rb, VK_SUBPASS_CONTENTS_INLINE);
        if (nMain > 0) {
            vkCmdBindPipeline(g.cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, g.plMain);
            VkViewport vp{0, 0, (float)g.ext.width, (float)g.ext.height, 0.0f, 1.0f};
            VkRect2D sc{{0, 0}, g.ext};
            vkCmdSetViewport(g.cmd, 0, 1, &vp);
            vkCmdSetScissor(g.cmd, 0, 1, &sc);
            vkCmdBindDescriptorSets(g.cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, g.plLayout, 0, 1, &g.dset, 0, nullptr);
            vkCmdBindVertexBuffers(g.cmd, 0, 2, vbs, offs);
            vkCmdBindIndexBuffer(g.cmd, g.ibuf, 0, VK_INDEX_TYPE_UINT16);
            vkCmdDrawIndexed(g.cmd, 36, (uint32_t)nMain, 0, 0, (uint32_t)nShadow);
        }
        vkCmdEndRenderPass(g.cmd);
    }
    vkEndCommandBuffer(g.cmd);

    VkPipelineStageFlags ws = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.waitSemaphoreCount = 1;
    si.pWaitSemaphores = &g.imgAvail;
    si.pWaitDstStageMask = &ws;
    si.commandBufferCount = 1;
    si.pCommandBuffers = &g.cmd;
    si.signalSemaphoreCount = 1;
    si.pSignalSemaphores = &g.renderDone[idx];
    r = vkQueueSubmit(g.queue, 1, &si, g.fence);
    if (r != VK_SUCCESS) return "vkQueueSubmit failed: " + std::to_string((int)r);
    VkPresentInfoKHR pr{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
    pr.waitSemaphoreCount = 1;
    pr.pWaitSemaphores = &g.renderDone[idx];
    pr.swapchainCount = 1;
    pr.pSwapchains = &g.sc;
    pr.pImageIndices = &idx;
    r = vkQueuePresentKHR(g.queue, &pr);
    if (r == VK_ERROR_OUT_OF_DATE_KHR) {
        if (!recreateSwap()) return gErr;
    }
    return "";
}

static bool readBitmap(JNIEnv* env, jobject bmp, std::vector<uint8_t>& out, uint32_t& w, uint32_t& h) {
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bmp, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return false;
    if (info.format != ANDROID_BITMAP_FORMAT_RGBA_8888) return false;
    void* px = nullptr;
    if (AndroidBitmap_lockPixels(env, bmp, &px) != ANDROID_BITMAP_RESULT_SUCCESS) return false;
    w = info.width;
    h = info.height;
    out.resize((size_t)w * h * 4);
    for (uint32_t y = 0; y < h; y++) {
        memcpy(out.data() + (size_t)y * w * 4, (const uint8_t*)px + (size_t)y * info.stride, (size_t)w * 4);
    }
    AndroidBitmap_unlockPixels(env, bmp);
    return true;
}

// ---------------------------------------------------------------- JNI
extern "C" {

JNIEXPORT jstring JNICALL Java_com_offlineblox_VkBridge_probe(JNIEnv* env, jclass) {
    destroyAll();
    gErr.clear();
    std::string res;
    if (!createInstance(false) || !pickDevice(false)) res = gErr.empty() ? "Vulkan unavailable" : gErr;
    destroyAll();
    return env->NewStringUTF(res.c_str());
}

JNIEXPORT jstring JNICALL Java_com_offlineblox_VkBridge_start(JNIEnv* env, jclass, jobject surface, jint, jint) {
    std::string e = startVk(env, surface);
    if (!e.empty()) destroyAll();
    return env->NewStringUTF(e.c_str());
}

JNIEXPORT void JNICALL Java_com_offlineblox_VkBridge_uploadAtlas(JNIEnv* env, jclass, jint layer, jobject bmp) {
    if (!g.ready || layer < 0 || layer >= (jint)ATLAS_LAYERS) return;
    std::vector<uint8_t> px;
    uint32_t w = 0, h = 0;
    if (!readBitmap(env, bmp, px, w, h) || w != ATLAS_W || h != ATLAS_H) return;
    uploadImage(g.atlasImg, (uint32_t)layer, w, h, px);
}

JNIEXPORT void JNICALL Java_com_offlineblox_VkBridge_uploadWorld(JNIEnv* env, jclass, jobject bmp) {
    if (!g.ready) return;
    std::vector<uint8_t> px;
    uint32_t w = 0, h = 0;
    if (!readBitmap(env, bmp, px, w, h) || w != WORLD_SZ || h != WORLD_SZ) return;
    uploadImage(g.worldImg, 0, w, h, px);
}

JNIEXPORT jstring JNICALL Java_com_offlineblox_VkBridge_render(JNIEnv* env, jclass, jobject buf, jint nShadow, jint nMain, jfloatArray globals) {
    static float gl[60 + 1536];
    env->GetFloatArrayRegion(globals, 0, 60 + 1536, gl);
    const void* inst = env->GetDirectBufferAddress(buf);
    if (!inst) return env->NewStringUTF("instance buffer is not direct");
    std::string e = renderFrame(inst, nShadow, nMain, gl);
    return env->NewStringUTF(e.c_str());
}

JNIEXPORT void JNICALL Java_com_offlineblox_VkBridge_destroy(JNIEnv*, jclass) {
    destroyAll();
}

}  // extern "C"
