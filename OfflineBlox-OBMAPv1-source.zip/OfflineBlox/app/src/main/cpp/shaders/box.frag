#version 450
layout(location = 0) in vec3 vN;
layout(location = 1) in vec2 vUV;
layout(location = 2) in vec4 vShadow;
layout(location = 3) in vec3 vWorld;
layout(location = 4) in float vDist;
layout(location = 5) in vec4 vColor;
layout(location = 6) flat in vec2 vMP;
layout(set = 0, binding = 0, std140) uniform U {
  mat4 vp;
  mat4 lvp;
  vec4 light;
  vec4 fog;
  vec4 fogRange;
  vec4 params;
  vec4 cam;
  vec4 floorCol;
} u;
layout(set = 0, binding = 1) uniform sampler2DArray uAtlas;
layout(set = 0, binding = 2) uniform sampler2D uWorld;
layout(set = 0, binding = 3) uniform sampler2DShadow uShadow;
layout(location = 0) out vec4 outColor;
layout(set = 0, binding = 4, std140) uniform B {
  vec4 boxes[384];
} bx;
float rtHit(vec3 ro, vec3 rd, int i, out vec3 nrm) {
  vec3 bmin = bx.boxes[i * 3].xyz;
  vec3 bmax = bx.boxes[i * 3 + 1].xyz;
  vec3 d = mix(rd, vec3(1e-5), lessThan(abs(rd), vec3(1e-5)));
  vec3 inv = 1.0 / d;
  vec3 t0 = (bmin - ro) * inv;
  vec3 t1 = (bmax - ro) * inv;
  vec3 tmn = min(t0, t1);
  vec3 tmx = max(t0, t1);
  float tn = max(max(tmn.x, tmn.y), tmn.z);
  float tf = min(min(tmx.x, tmx.y), tmx.z);
  nrm = vec3(0.0, 0.0, 1.0);
  if (tn > tf || tn < 0.01) { return -1.0; }
  if (tn == tmn.x) { nrm = vec3(-sign(d.x), 0.0, 0.0); }
  else if (tn == tmn.y) { nrm = vec3(0.0, -sign(d.y), 0.0); }
  else { nrm = vec3(0.0, 0.0, -sign(d.z)); }
  return tn;
}
bool rtOcc(vec3 ro, vec3 rd, float maxT) {
  vec3 nn;
  int cnt = int(u.params.w);
  for (int i = 0; i < 128; i++) {
    if (i >= cnt) { break; }
    float t = rtHit(ro, rd, i, nn);
    if (t > 0.0 && t < maxT) { return true; }
  }
  return false;
}
vec3 rtRefl(vec3 ro, vec3 rd) {
  float best = 1e9;
  vec3 bn = vec3(0.0, 0.0, 1.0);
  vec3 bc = vec3(0.0);
  vec3 nn;
  int cnt = int(u.params.w);
  for (int i = 0; i < 128; i++) {
    if (i >= cnt) { break; }
    float t = rtHit(ro, rd, i, nn);
    if (t > 0.0 && t < best) { best = t; bn = nn; bc = bx.boxes[i * 3 + 2].rgb; }
  }
  if (rd.z < -0.001 && ro.z > 0.0) {
    float tp = -ro.z / rd.z;
    if (tp < best) { best = tp; bn = vec3(0.0, 0.0, 1.0); bc = u.floorCol.rgb; }
  }
  if (best < 1e8) {
    float dl = max(dot(bn, u.light.xyz), 0.0);
    return bc * (0.4 + 0.6 * dl);
  }
  return mix(u.fog.rgb, vec3(0.35, 0.55, 0.95), clamp(rd.z * 1.5, 0.0, 1.0));
}
void main() {
  vec3 n = normalize(vN);
  vec4 tex;
  if (vMP.y > 0.5) {
    vec3 an = abs(n);
    vec2 w;
    if (an.z > 0.5) { w = vWorld.xy; } else if (an.x > 0.5) { w = vWorld.yz; } else { w = vWorld.xz; }
    tex = texture(uWorld, w / 4.0);
  } else {
    tex = texture(uAtlas, vec3(vUV, vColor.a));
  }
  vec3 base = tex.rgb * vColor.rgb;
  float ndl = max(dot(n, u.light.xyz), 0.0);
  float sh = 1.0;
  float ao = 1.0;
  if (u.params.x > 0.5) {
    vec3 nd = vShadow.xyz / vShadow.w;
    vec2 suv = vec2(nd.x * 0.5 + 0.5, -nd.y * 0.5 + 0.5);
    float ref = nd.z * 0.5 + 0.5 - 0.003;
    if (suv.x > 0.0 && suv.x < 1.0 && suv.y > 0.0 && suv.y < 1.0 && ref < 1.0) {
      float sum = 0.0;
      for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
          sum += texture(uShadow, vec3(suv + vec2(float(i), float(j)) * u.params.y, ref));
        }
      }
      sh = sum / 9.0;
    }
  }
  if (u.params.z > 0.5) {
    float h0 = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
    vec3 po = vWorld + n * 0.03;
    float vis = 0.0;
    if (ndl > 0.0) {
      for (int k = 0; k < 3; k++) {
        vec3 j = vec3(h0, fract(h0 * 7.13 + float(k) * 0.37), fract(h0 * 3.71 + float(k) * 0.73)) - 0.5;
        vec3 rd = normalize(u.light.xyz + j * 0.07);
        vis += rtOcc(po, rd, 400.0) ? 0.0 : 1.0;
      }
      vis = vis / 3.0;
    }
    sh = vis;
    float occ = 0.0;
    for (int k = 0; k < 2; k++) {
      vec3 j = vec3(fract(h0 * 5.31 + float(k) * 0.61), fract(h0 * 9.17 + float(k) * 0.29), fract(h0 * 2.73 + float(k) * 0.83)) - 0.5;
      vec3 rd = normalize(n + j * 1.4);
      if (dot(rd, n) < 0.05) { rd = normalize(rd + n * 0.8); }
      occ += rtOcc(po, rd, 3.5) ? 1.0 : 0.0;
    }
    ao = 1.0 - 0.45 * occ / 2.0;
  }
  float hemi = 0.5 + 0.5 * n.z;
  float light = (0.36 + 0.14 * hemi) * ao + 0.62 * ndl * sh;
  vec3 col = base * light;
  if (u.params.z > 0.5 && vMP.y > 0.5) {
    vec3 V = normalize(u.cam.xyz - vWorld);
    float fr = 0.04 + 0.96 * pow(1.0 - max(dot(n, V), 0.0), 5.0);
    float kk = mix(0.07, 0.6, fr);
    vec3 rdr = reflect(-V, n);
    vec3 rc = rtRefl(vWorld + n * 0.03, rdr);
    col = mix(col, rc, kk);
  }
  float fogK = clamp((vDist - u.fogRange.x) / (u.fogRange.y - u.fogRange.x), 0.0, 1.0);
  col = mix(col, u.fog.rgb, fogK);
  outColor = vec4(col, 1.0);
}
