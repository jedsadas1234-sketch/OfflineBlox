#version 450
layout(location = 0) in vec3 aPos;
layout(location = 4) in vec4 iM0;
layout(location = 5) in vec4 iM1;
layout(location = 6) in vec4 iM2;
layout(location = 7) in vec4 iM3;
layout(location = 8) in vec4 iScale;
layout(set = 0, binding = 0, std140) uniform U {
  mat4 vp;
  mat4 lvp;
  vec4 light;
  vec4 fog;
  vec4 fogRange;
  vec4 params;
  vec4 cam;
  vec4 floorCol;
} u;
void main() {
  mat4 model = mat4(iM0, iM1, iM2, iM3);
  vec4 wp = model * vec4(aPos * iScale.xyz, 1.0);
  vec4 c = u.lvp * wp;
  gl_Position = vec4(c.x, -c.y, (c.z + c.w) * 0.5, c.w);
}
