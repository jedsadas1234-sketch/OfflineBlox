package com.offlineblox

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri

/**
 * Lets another app (the map editor) talk to the game's map list:
 *   query  content://com.offlineblox.maps/maps            -> name, desc, builtin (no json, small)
 *   query  content://com.offlineblox.maps/maps/<name>     -> name, desc, builtin, json (full .map text)
 *   insert content://com.offlineblox.maps/maps  values: json=<.map text>   -> adds / replaces a map
 *   delete content://com.offlineblox.maps/maps/<name>     -> removes an imported map
 */
class MapProvider : ContentProvider() {
    override fun onCreate(): Boolean {
        val c = context
        if (c != null) Maps.init(c.applicationContext)
        return true
    }

    override fun query(uri: Uri, projection: Array<String>?, selection: String?, selectionArgs: Array<String>?, sortOrder: String?): Cursor? {
        val cur = MatrixCursor(arrayOf("name", "desc", "builtin", "json"))
        val maps = Maps.all
        val seg = uri.pathSegments
        if (seg.size >= 2) {
            val i = maps.indexOfFirst { it.name == seg[1] }
            if (i >= 0) {
                val m = maps[i]
                cur.addRow(arrayOf<Any?>(m.name, m.desc, if (i < Maps.builtinCount) 1 else 0, Maps.toJson(m)))
            }
        } else {
            for ((i, m) in maps.withIndex()) {
                cur.addRow(arrayOf<Any?>(m.name, m.desc, if (i < Maps.builtinCount) 1 else 0, ""))
            }
        }
        return cur
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        val json = values?.getAsString("json") ?: return null
        return try {
            val m = Maps.add(json, "Imported map")
            Uri.parse("content://com.offlineblox.maps/maps/" + Uri.encode(m.name))
        } catch (_: Exception) {
            null
        }
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        val seg = uri.pathSegments
        if (seg.size < 2) return 0
        val i = Maps.all.indexOfFirst { it.name == seg[1] }
        if (i < Maps.builtinCount) return 0
        Maps.remove(i)
        return 1
    }

    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<String>?): Int = 0

    override fun getType(uri: Uri): String? = "vnd.android.cursor.dir/vnd.offlineblox.map"
}
