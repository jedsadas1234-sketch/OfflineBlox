package com.offlineblox

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/** OBMAP v1: fixed binary header + readable JSON manifest + binary asset payloads. */
object MapPackageCodec {
    private val MAGIC = byteArrayOf(0x4f, 0x42, 0x4d, 0x41, 0x50) // OBMAP
    private const val VERSION = 1
    private const val MAX_PACKAGE = 128 * 1024 * 1024
    private const val MAX_MANIFEST = 16 * 1024 * 1024
    private const val MAX_ASSETS = 512

    private data class Chunk(val id: String, val type: String, val bytes: ByteArray, val hash: String)

    fun isPackage(bytes: ByteArray): Boolean = bytes.size >= 5 && MAGIC.indices.all { bytes[it] == MAGIC[it] }

    fun encode(worldJson: String): ByteArray {
        val root = JSONObject(worldJson)
        val chunks = ArrayList<Chunk>()
        val textures = root.optJSONObject("textures")
        if (textures != null) {
            val keys = textures.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val item = textures.optJSONObject(id) ?: continue
                val encoded = item.optString("png", "")
                if (encoded.isBlank() || encoded == "<embedded>") continue
                val clean = encoded.substringAfter(",", encoded).replace("\\s".toRegex(), "")
                val raw = try { Base64.decode(clean, Base64.DEFAULT) } catch (e: Exception) { throw IllegalArgumentException("Invalid texture asset: $id") }
                val assetId = "tex:$id"
                chunks.add(Chunk(assetId, "texture/png", raw, sha256(raw)))
                item.remove("png")
                item.put("asset", assetId)
            }
        }
        val models = root.optJSONObject("models")
        if (models != null) {
            val keys = models.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val item = models.optJSONObject(id) ?: continue
                val va = item.optJSONArray("v") ?: continue
                val ia = item.optJSONArray("i") ?: continue
                val ua = item.optJSONArray("uv")
                val ca = item.optJSONArray("c")
                val nv = va.length(); val ni = ia.length(); val nu = ua?.length() ?: 0; val nc = ca?.length() ?: 0
                if (nv > 9_000_000 || ni > 180_000 || nu > 6_000_000 || nc > 3_000_000) throw IllegalArgumentException("Model asset too large: $id")
                val size = 16L + nv * 4L + ni * 4L + nu * 4L + nc * 4L
                if (size > MAX_PACKAGE) throw IllegalArgumentException("Model asset too large: $id")
                val buf = ByteBuffer.allocate(size.toInt()).order(ByteOrder.LITTLE_ENDIAN)
                buf.putInt(nv).putInt(ni).putInt(nu).putInt(nc)
                for (i in 0 until nv) buf.putFloat(va.optDouble(i, 0.0).toFloat())
                for (i in 0 until ni) buf.putInt(ia.optInt(i, -1))
                if (ua != null) for (i in 0 until nu) buf.putFloat(ua.optDouble(i, 0.0).toFloat())
                if (ca != null) for (i in 0 until nc) buf.putInt(ca.optInt(i, 0xFFFFFF))
                val raw = buf.array()
                val assetId = "mesh:$id"
                chunks.add(Chunk(assetId, "mesh/f32i32", raw, sha256(raw)))
                item.remove("v"); item.remove("i"); item.remove("uv"); item.remove("c")
                item.put("asset", assetId)
                item.put("vertexFloatCount", nv); item.put("indexCount", ni)
                item.put("uvFloatCount", nu); item.put("colorCount", nc)
            }
        }
        if (chunks.size > MAX_ASSETS) throw IllegalArgumentException("Too many embedded assets")
        val directory = JSONArray()
        var offset = 0L
        for (c in chunks) {
            directory.put(JSONObject().put("id", c.id).put("type", c.type).put("offset", offset)
                .put("length", c.bytes.size).put("sha256", c.hash))
            offset += c.bytes.size
        }
        root.put("_obmap", JSONObject().put("format", "OBMAP").put("version", VERSION).put("assets", directory))
        val manifest = root.toString().toByteArray(Charsets.UTF_8)
        if (manifest.size > MAX_MANIFEST || offset + manifest.size + 27L > MAX_PACKAGE) throw IllegalArgumentException("Map package too large")
        val out = ByteArrayOutputStream(5 + 2 + 4 + 4 + 4 + 8 + manifest.size + offset.toInt())
        val data = DataOutputStream(out)
        data.write(MAGIC); data.writeShort(VERSION); data.writeInt(0)
        data.writeInt(manifest.size); data.writeInt(chunks.size); data.writeLong(offset)
        data.write(manifest)
        for (c in chunks) data.write(c.bytes)
        data.flush()
        return out.toByteArray()
    }

    fun decode(bytes: ByteArray): String {
        if (!isPackage(bytes)) return bytes.toString(Charsets.UTF_8)
        if (bytes.size > MAX_PACKAGE || bytes.size < 27) throw IllegalArgumentException("Invalid or oversized OBMAP file")
        val header = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        header.position(5)
        val version = header.short.toInt() and 0xffff
        header.int // flags reserved
        val manifestLength = header.int
        val assetCount = header.int
        val payloadLength = header.long
        if (version != VERSION) throw IllegalArgumentException("Unsupported OBMAP version: $version")
        if (manifestLength < 2 || manifestLength > MAX_MANIFEST || assetCount < 0 || assetCount > MAX_ASSETS || payloadLength < 0 || payloadLength > MAX_PACKAGE) throw IllegalArgumentException("Invalid OBMAP header")
        val payloadStart = 27L + manifestLength
        if (payloadStart + payloadLength != bytes.size.toLong()) throw IllegalArgumentException("OBMAP size mismatch")
        val manifestBytes = bytes.copyOfRange(27, 27 + manifestLength)
        val root = JSONObject(manifestBytes.toString(Charsets.UTF_8))
        val meta = root.optJSONObject("_obmap") ?: throw IllegalArgumentException("OBMAP manifest missing")
        val entries = meta.optJSONArray("assets") ?: JSONArray()
        if (entries.length() != assetCount) throw IllegalArgumentException("OBMAP asset count mismatch")
        val loaded = HashMap<String, ByteArray>()
        for (i in 0 until entries.length()) {
            val e = entries.getJSONObject(i)
            val id = e.getString("id")
            val off = e.getLong("offset"); val len = e.getLong("length")
            if (off < 0 || len < 0 || off + len > payloadLength || len > MAX_PACKAGE) throw IllegalArgumentException("Invalid asset range: $id")
            val start = (payloadStart + off).toInt()
            val raw = bytes.copyOfRange(start, start + len.toInt())
            if (!sha256(raw).equals(e.optString("sha256"), true)) throw IllegalArgumentException("Asset checksum failed: $id")
            if (loaded.put(id, raw) != null) throw IllegalArgumentException("Duplicate asset: $id")
        }
        val textures = root.optJSONObject("textures")
        if (textures != null) {
            val keys = textures.keys()
            while (keys.hasNext()) {
                val id = keys.next(); val item = textures.optJSONObject(id) ?: continue
                val asset = item.optString("asset", "")
                if (asset.isNotEmpty()) {
                    val raw = loaded[asset] ?: throw IllegalArgumentException("Missing texture asset: $id")
                    item.put("png", Base64.encodeToString(raw, Base64.NO_WRAP)); item.remove("asset")
                }
            }
        }
        val models = root.optJSONObject("models")
        if (models != null) {
            val keys = models.keys()
            while (keys.hasNext()) {
                val id = keys.next(); val item = models.optJSONObject(id) ?: continue
                val asset = item.optString("asset", "")
                if (asset.isEmpty()) continue
                val raw = loaded[asset] ?: throw IllegalArgumentException("Missing mesh asset: $id")
                if (raw.size < 16) throw IllegalArgumentException("Invalid mesh asset: $id")
                val b = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
                val nv = b.int; val ni = b.int; val nu = b.int; val nc = b.int
                if (nv < 9 || nv % 3 != 0 || ni < 3 || ni % 3 != 0 || nu < 0 || nc < 0 || 16L + (nv.toLong()+ni+nu+nc)*4L != raw.size.toLong()) throw IllegalArgumentException("Invalid mesh layout: $id")
                val va = JSONArray(); repeat(nv) { va.put(b.float.toDouble()) }
                val ia = JSONArray(); repeat(ni) { ia.put(b.int) }
                if (nu > 0) { val ua = JSONArray(); repeat(nu) { ua.put(b.float.toDouble()) }; item.put("uv", ua) }
                if (nc > 0) { val ca = JSONArray(); repeat(nc) { ca.put(b.int) }; item.put("c", ca) }
                item.put("v", va); item.put("i", ia)
                item.remove("asset"); item.remove("vertexFloatCount"); item.remove("indexCount"); item.remove("uvFloatCount"); item.remove("colorCount")
            }
        }
        root.remove("_obmap")
        return root.toString()
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
