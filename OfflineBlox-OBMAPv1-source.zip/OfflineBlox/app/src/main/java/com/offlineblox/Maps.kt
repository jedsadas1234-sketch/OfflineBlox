package com.offlineblox

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * kind: 0 solid, 1 lava (kills), 2 bounce pad, 3 moving platform (mx,my,mz amplitude, period s),
 * 4 blinking platform (period, phase s), 5 checkpoint, 6 moving lava bar, 7 decor (no collision, no shadow).
 * Periods must divide 600 so every device stays in sync with the wall clock.
 */
class Box(
    val x: Float, val y: Float, val z: Float, val w: Float, val d: Float, val h: Float, val color: Int,
    val kind: Int = 0, val mx: Float = 0f, val my: Float = 0f, val mz: Float = 0f,
    val period: Float = 0f, val phase: Float = 0f
) {
    private fun s(t: Float) = if (period > 0f && (kind == 3 || kind == 6)) sin(6.2831855f * (t / period) + phase) else 0f
    fun cx(t: Float) = x + mx * s(t)
    fun cy(t: Float) = y + my * s(t)
    fun cz(t: Float) = z + mz * s(t)
    fun on(t: Float) = kind != 4 || period <= 0f || ((t + phase) % period) < period * 0.65f
}

class GameMap(
    val name: String, val desc: String, val floor: FloatArray?, val floorColor: Int,
    val boxes: List<Box>, val sx: Float, val sy: Float, val skyTop: Int, val skyBot: Int,
    val json: String? = null
) {
    val solids: List<Box> = boxes.filter { it.kind != 7 }
    val decor: List<Box> = boxes.filter { it.kind == 7 }
}

object Maps {
    const val builtinCount = 3
    private val list = CopyOnWriteArrayList<GameMap>()
    private val fileOf = ConcurrentHashMap<String, File>()
    private var dir: File? = null

    val all: List<GameMap>
        get() {
            if (list.isEmpty()) {
                list.add(baseplate()); list.add(obby()); list.add(town())
            }
            return list
        }

    /** Loads every *.map file that was imported earlier. */
    fun init(ctx: Context) {
        val d = File(ctx.filesDir, "maps")
        d.mkdirs()
        dir = d
        all
        val files = d.listFiles() ?: return
        for (f in files.sortedBy { it.name }) {
            if (!f.name.endsWith(".map")) continue
            try {
                val m = parse(MapPackageCodec.decode(f.readBytes()), f.nameWithoutExtension)
                if (list.none { it.name == m.name }) {
                    list.add(m)
                    fileOf[m.name] = f
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun hexCol(s: String?, def: Int): Int {
        if (s.isNullOrEmpty()) return def
        return try { Color.parseColor(s) } catch (_: Exception) { def }
    }

    /** A .map file is JSON text. Throws if it is not valid. */
    fun parse(text: String, fallbackName: String): GameMap {
        if (text.length > 96 * 1024 * 1024) throw IllegalArgumentException("file too large (max 96 MB)")
        val o = JSONObject(text)
        val name = o.optString("name", fallbackName).trim().ifEmpty { fallbackName }.take(40)
        val desc = o.optString("desc", "Custom map").take(120)
        val sp = o.optJSONArray("spawn")
        val sx = (sp?.optDouble(0, 0.0) ?: 0.0).toFloat()
        val sy = (sp?.optDouble(1, 0.0) ?: 0.0).toFloat()
        val sk = o.optJSONArray("sky")
        val top = hexCol(sk?.optString(0, ""), 0xFF4A90D9.toInt())
        val bot = hexCol(sk?.optString(1, ""), 0xFFBFE0FF.toInt())
        var floor: FloatArray? = null
        var floorColor = 0xFF7A7F85.toInt()
        val fl = o.optJSONObject("floor")
        if (fl != null) {
            val r = fl.optJSONArray("rect")
            if (r != null && r.length() >= 4) {
                floor = floatArrayOf(r.getDouble(0).toFloat(), r.getDouble(1).toFloat(), r.getDouble(2).toFloat(), r.getDouble(3).toFloat())
            }
            floorColor = hexCol(fl.optString("color", ""), floorColor)
        }
        val arr = o.optJSONArray("boxes") ?: JSONArray()
        if (arr.length() > 8000) throw IllegalArgumentException("too many boxes (max 8000)")
        val b = ArrayList<Box>()
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            val mv = j.optJSONArray("move")
            b.add(Box(
                j.optDouble("x", 0.0).toFloat(), j.optDouble("y", 0.0).toFloat(), j.optDouble("z", 0.0).toFloat(),
                j.optDouble("w", 1.0).toFloat().coerceAtLeast(0.05f), j.optDouble("d", 1.0).toFloat().coerceAtLeast(0.05f),
                j.optDouble("h", 1.0).toFloat().coerceAtLeast(0.05f),
                hexCol(j.optString("color", ""), 0xFFB0B8C0.toInt()),
                j.optInt("kind", 0).coerceIn(0, 7),
                (mv?.optDouble(0, 0.0) ?: 0.0).toFloat(), (mv?.optDouble(1, 0.0) ?: 0.0).toFloat(), (mv?.optDouble(2, 0.0) ?: 0.0).toFloat(),
                j.optDouble("period", 0.0).toFloat(), j.optDouble("phase", 0.0).toFloat()
            ))
        }
        return GameMap(name, desc, floor, floorColor, b, sx, sy, top, bot, text)
    }

    private fun hexStr(c: Int) = String.format("#%06X", c and 0xFFFFFF)
    private fun rnd(v: Float): Double = Math.round(v * 1000f) / 1000.0

    /** Any map (built-in or imported) as .map JSON text. */
    fun toJson(m: GameMap): String {
        val src = m.json
        if (src != null) return src
        val o = JSONObject()
        o.put("version", 1)
        o.put("name", m.name)
        o.put("desc", m.desc)
        o.put("spawn", JSONArray().put(rnd(m.sx)).put(rnd(m.sy)))
        o.put("sky", JSONArray().put(hexStr(m.skyTop)).put(hexStr(m.skyBot)))
        val f = m.floor
        if (f != null) {
            val fo = JSONObject()
            fo.put("rect", JSONArray().put(rnd(f[0])).put(rnd(f[1])).put(rnd(f[2])).put(rnd(f[3])))
            fo.put("color", hexStr(m.floorColor))
            o.put("floor", fo)
        }
        val arr = JSONArray()
        for (b in m.boxes) {
            val j = JSONObject()
            j.put("x", rnd(b.x)); j.put("y", rnd(b.y)); j.put("z", rnd(b.z))
            j.put("w", rnd(b.w)); j.put("d", rnd(b.d)); j.put("h", rnd(b.h))
            j.put("color", hexStr(b.color))
            if (b.kind != 0) j.put("kind", b.kind)
            if (b.mx != 0f || b.my != 0f || b.mz != 0f) j.put("move", JSONArray().put(rnd(b.mx)).put(rnd(b.my)).put(rnd(b.mz)))
            if (b.period > 0f) {
                j.put("period", rnd(b.period))
                if (b.phase != 0f) j.put("phase", rnd(b.phase))
            }
            arr.put(j)
        }
        o.put("boxes", arr)
        return o.toString()
    }

    /** Imports (and saves) a legacy JSON map. Returns the new map. */
    fun add(text: String, fallbackName: String): GameMap {
        val m = parse(text, fallbackName)
        all
        val old = list.indexOfFirst { it.name == m.name }
        if (old in 0 until builtinCount) throw IllegalArgumentException("name \"" + m.name + "\" is used by a built-in map")
        val dd = dir
        if (dd != null) {
            val f = File(dd, "m" + abs(m.name.hashCode()) + ".map")
            f.writeText(text)
            fileOf[m.name] = f
        }
        if (old >= builtinCount) list.removeAt(old)
        list.add(m)
        return m
    }

    /** Imports an OBMAP binary package or a legacy JSON byte stream and preserves its original bytes. */
    fun add(bytes: ByteArray, fallbackName: String): GameMap {
        val decoded = MapPackageCodec.decode(bytes)
        val m = add(decoded, fallbackName)
        val target = fileOf[m.name]
        if (target != null) target.writeBytes(bytes)
        return m
    }

    /** Map sent by the host while joining: kept for this session only. */
    fun addTransient(text: String) {
        val m = parse(text, "Host map")
        all
        val old = list.indexOfFirst { it.name == m.name }
        if (old in 0 until builtinCount) return
        if (old >= builtinCount) {
            if (list[old].json == text) return
            list.removeAt(old)
        }
        list.add(m)
    }

    fun remove(i: Int) {
        if (i < builtinCount || i >= list.size) return
        val m = list.removeAt(i)
        fileOf.remove(m.name)?.delete()
    }


    private val PALETTE = intArrayOf(
        0xFFC4281C.toInt(), 0xFF0D69AC.toInt(), 0xFFF5CD30.toInt(), 0xFF287F47.toInt(),
        0xFF6B327C.toInt(), 0xFFDA8541.toInt(), 0xFF008F9C.toInt(), 0xFFE8BAC8.toInt()
    )
    private val TOWN = intArrayOf(
        0xFFB8C2CC.toInt(), 0xFFD9D2C3.toInt(), 0xFF9AA7B5.toInt(), 0xFFC9B79C.toInt(), 0xFFA8B8A0.toInt(), 0xFFC0A8B8.toInt()
    )
    private val HOUSE = intArrayOf(
        0xFFF2D8A7.toInt(), 0xFFBFE0FF.toInt(), 0xFFE8BAC8.toInt(), 0xFFC9E4B0.toInt(), 0xFFF5CD30.toInt(), 0xFFDDDDDD.toInt()
    )

    private fun col(a: IntArray, i: Int) = a[((i % a.size) + a.size) % a.size]

    // ------------------------------------------------------------------ Baseplate (500 x 500)
    private fun baseplate(): GameMap {
        val b = ArrayList<Box>()
        val r = java.util.Random(11)
        val steel = 0xFFB0B8C0.toInt()
        fun cube(x: Float, y: Float, z: Float, w: Float, d: Float, h: Float, c: Int, kind: Int = 0) {
            b.add(Box(x, y, z, w, d, h, c, kind))
        }
        // ziggurat (east)
        for (i in 0 until 9) {
            val s = 64f - i * 6.5f
            cube(60f + (64f - s) / 2f, -32f + (64f - s) / 2f, 0f, s, s, 1.8f * (i + 1), col(PALETTE, i))
        }
        // long gentle ramp (west) up to a sky mesa; each step is lower than the walk-up threshold
        for (i in 0 until 100) {
            cube(-200f + i * 0.9f, -6f, 0f, 0.95f, 12f, 0.28f * (i + 1), if (i % 2 == 0) steel else 0xFF9AA2AA.toInt())
        }
        cube(-110f, -25f, 0f, 60f, 50f, 28f, 0xFFF2F3F3.toInt())
        for (i in 0 until 6) cube(-100f + i * 8f, -15f + (i % 2) * 20f, 28f, 4f, 4f, 2f + i, col(PALETTE, i + 2))
        // pillar climb (north)
        for (i in 0 until 24) cube(-30f + i * 5f, 45f + sin(i * 0.7f) * 8f, 0f, 3.5f, 3.5f, 1.2f * (i + 1), col(PALETTE, i))
        cube(90f, 33f, 0f, 14f, 24f, 28.8f, 0xFFF5CD30.toInt())
        // towers on a ring, bounce pad at every foot, bridges between pairs
        for (i in 0 until 12) {
            val a = i * 0.5236f
            val tx = cos(a) * 170f
            val ty = sin(a) * 170f
            cube(tx - 3f, ty - 3f, 0f, 6f, 6f, 12f, col(PALETTE, i))
            cube(tx - cos(a) * 10f - 2f, ty - sin(a) * 10f - 2f, 0f, 4f, 4f, 0.4f, 0xFFFF5FA2.toInt(), 2)
        }
        for (i in 0 until 12 step 2) {
            val a1 = i * 0.5236f
            val a2 = (i + 1) * 0.5236f
            val x1 = cos(a1) * 170f
            val y1 = sin(a1) * 170f
            val x2 = cos(a2) * 170f
            val y2 = sin(a2) * 170f
            cube(minOf(x1, x2) - 1.5f, y1 - 1.5f, 11f, abs(x2 - x1) + 3f, 3f, 1f, steel)
            cube(x2 - 1.5f, minOf(y1, y2) - 1.5f, 11f, 3f, abs(y2 - y1) + 3f, 1f, steel)
        }
        // scattered cubes
        var placed = 0
        var tries = 0
        while (placed < 160 && tries < 3000) {
            tries++
            val x = r.nextFloat() * 460f - 230f
            val y = r.nextFloat() * 460f - 230f
            if (x > -45f && x < 45f && y > -45f && y < 60f) continue
            if (x > 50f && x < 135f && y > -45f && y < 60f) continue
            if (x > -215f && x < -45f && y > -35f && y < 35f) continue
            if (x > -40f && x < 110f && y > 30f && y < 65f) continue
            if (abs(abs(x) - 170f) < 30f && abs(abs(y) - 170f) < 30f) continue
            val w = 2f + r.nextFloat() * 8f
            val d = 2f + r.nextFloat() * 8f
            val h = 1f + r.nextFloat() * 7f
            cube(x, y, 0f, w, d, h, col(PALETTE, r.nextInt(8)))
            placed++
        }
        return GameMap(
            "Baseplate", "Huge open plate: ziggurat, sky ramp, ring towers with bounce pads, pillar climb and lots of cubes.",
            floatArrayOf(-250f, -250f, 250f, 250f), 0xFF7A7F85.toInt(), b, 0f, 0f, 0xFF4A90D9.toInt(), 0xFFBFE0FF.toInt()
        )
    }

    // ------------------------------------------------------------------ Obby (very long, 8 stages)
    private fun obby(): GameMap {
        val b = ArrayList<Box>()
        val green = 0xFF3FBF5F.toInt()
        val gold = 0xFFF5CD30.toInt()
        var x = 8f
        var z = 0f
        fun plat(px: Float, py: Float, pz: Float, w: Float, d: Float, c: Int, kind: Int = 0,
                 mx: Float = 0f, my: Float = 0f, mz: Float = 0f, per: Float = 0f, ph: Float = 0f) {
            b.add(Box(px, py, pz, w, d, 0.8f, c, kind, mx, my, mz, per, ph))
        }
        fun checkpoint() { plat(x, -4f, z, 8f, 8f, green, 5); x += 10.5f }

        // 1: warm-up
        for (i in 0 until 14) { plat(x, sin(i * 0.8f) * 5f - 2f, z, 4f, 4f, col(PALETTE, i)); x += 6.5f; z += 0.4f }
        checkpoint()
        // 2: platforms sliding sideways
        for (i in 0 until 7) { plat(x, -2f, z, 4f, 4f, 0xFFDA8541.toInt(), 3, 0f, 7f, 0f, 8f, i * 1.1f); x += 8f }
        checkpoint()
        // 3: blinking platforms
        for (i in 0 until 12) { plat(x, sin(i * 1.3f) * 4f - 1.5f, z, 3f, 3f, 0xFF7FC4F0.toInt(), 4, 0f, 0f, 0f, 6f, i * 0.9f); x += 5.5f }
        x += 1f
        checkpoint()
        // 4: lava field with stepping stones and bounce pads
        run {
            b.add(Box(x - 2f, -22f, z - 1.2f, 82f, 44f, 1f, 0xFFFF4D1A.toInt(), 1))
            for (i in 0 until 14) {
                val yy = sin(i * 1.1f) * 8f - 1.25f
                if (i % 5 == 4) b.add(Box(x, yy, z, 3f, 3f, 0.4f, 0xFFFF5FA2.toInt(), 2))
                else plat(x, yy, z, 2.6f, 2.6f, col(PALETTE, i))
                x += 5.6f
            }
        }
        checkpoint()
        // 5: elevators
        for (i in 0 until 3) {
            plat(x, -2.5f, z + 5f, 5f, 5f, 0xFF00B7C2.toInt(), 3, 0f, 0f, 5f, 6f, i * 1.5f)
            x += 8f
            z += 10f
            plat(x, -2.5f, z, 5f, 5f, col(PALETTE, i + 3))
            x += 8f
        }
        checkpoint()
        // 6: narrow beams with sweeping lava bars
        for (j in 0 until 2) {
            plat(x, -0.8f, z, 36f, 1.6f, 0xFFB0B8C0.toInt())
            for (k in 0 until 3) b.add(Box(x + 8f + k * 10f, -5f, z + 0.8f, 1.5f, 6f, 3f, 0xFFFF2E2E.toInt(), 6, 0f, 6f, 0f, 5f, k * 2.1f))
            x += 39f
            plat(x, -3f, z, 6f, 6f, col(PALETTE, j + 5))
            x += 9f
        }
        checkpoint()
        // 7: bounce pad islands
        for (i in 0 until 6) {
            plat(x, -4f, z, 8f, 8f, col(PALETTE, i + 1))
            b.add(Box(x + 2.5f, -1.5f, z + 0.8f, 3f, 3f, 0.4f, 0xFFFF5FA2.toInt(), 2))
            x += 16f
        }
        checkpoint()
        // 8: spiral climb to the golden finish
        val cx = x + 14f
        for (i in 0 until 26) {
            val a = 3.1416f + i * 0.5f
            plat(cx + cos(a) * 10f - 2f, sin(a) * 10f - 2f, z + i * 1.1f, 4f, 4f, col(PALETTE, i))
        }
        val top = z + 26 * 1.1f
        plat(cx - 5f, -5f, top, 10f, 10f, gold)
        b.add(Box(cx - 1f, -1f, top + 0.8f, 2f, 2f, 4f, gold))
        return GameMap(
            "Obby", "Very long obby: sliding & blinking platforms, lava, elevators, sweepers, bounce pads, checkpoints.",
            floatArrayOf(-6f, -6f, 6f, 6f), 0xFF3A7BD5.toInt(), b, 0f, 0f, 0xFF3B2A6B.toInt(), 0xFFB48CE0.toInt()
        )
    }

    // ------------------------------------------------------------------ Town (600 x 600 city)
    private fun town(): GameMap {
        val b = ArrayList<Box>()
        val r = java.util.Random(5)
        val steel = 0xFFB0B8C0.toInt()
        val roof = 0xFF50565C.toInt()
        val glass1 = 0xFF9FD3F5.toInt()
        val glass2 = 0xFFFFE9A8.toInt()
        fun add(x: Float, y: Float, z: Float, w: Float, d: Float, h: Float, c: Int, kind: Int = 0) {
            b.add(Box(x, y, z, w, d, h, c, kind))
        }
        fun windows(x: Float, y: Float, w: Float, d: Float, h: Float) {
            var z = 5f
            var j = 0
            while (z + 3f < h - 1f) {
                val c = if (j % 2 == 0) glass1 else glass2
                add(x + w - 0.05f, y + 2f, z, 0.2f, d - 4f, 3f, c, 7)
                add(x - 0.15f, y + 2f, z, 0.2f, d - 4f, 3f, c, 7)
                add(x + 2f, y + d - 0.05f, z, w - 4f, 0.2f, 3f, c, 7)
                add(x + 2f, y - 0.15f, z, w - 4f, 0.2f, 3f, c, 7)
                z += 9f
                j++
            }
        }
        fun tree(x: Float, y: Float, s: Float) {
            add(x - 1.5f * s, y - 1.5f * s, 0f, 3f * s, 3f * s, 14f * s, 0xFF7C5C46.toInt())
            add(x - 8f * s, y - 8f * s, 12f * s, 16f * s, 16f * s, 4f * s, 0xFF287F47.toInt())
            add(x - 6f * s, y - 6f * s, 16f * s, 12f * s, 12f * s, 4f * s, 0xFF2F9A55.toInt())
            add(x - 3.5f * s, y - 3.5f * s, 20f * s, 7f * s, 7f * s, 3f * s, 0xFF3FB765.toInt())
        }
        // external staircase (jump up) ending at the west face of a building
        fun stairs(faceX: Float, y: Float, w: Float, h: Float) {
            val n = (h / 1.6f).toInt()
            for (i in 0 until n) add(faceX - (n - i) * 1.6f, y, 0f, 1.6f, w, 1.6f * (i + 1), steel)
        }
        // roads (flush with the ground)
        for (k in -5..4) {
            val p = 60f * k + 30f
            add(p - 6f, -300f, 0f, 12f, 600f, 0.06f, 0xFF3C4248.toInt(), 7)
            add(-300f, p - 6f, 0f, 600f, 12f, 0.06f, 0xFF3C4248.toInt(), 7)
        }
        // central plaza: fountain + clock tower
        add(-24f, -24f, 0f, 48f, 48f, 0.1f, 0xFFD6D2C8.toInt(), 7)
        add(-8f, -8f, 0f, 16f, 16f, 1.5f, steel)
        add(-6f, -6f, 1.5f, 12f, 12f, 0.1f, 0xFF4AA3E0.toInt(), 7)
        add(-1.5f, -1.5f, 1.5f, 3f, 3f, 7f, 0xFFD9D2C3.toInt())
        add(-3f, -3f, 8.5f, 6f, 6f, 1f, steel)
        add(12f, 12f, 0f, 9f, 9f, 46f, 0xFFB5412F.toInt())
        windows(12f, 12f, 9f, 9f, 46f)
        add(11f, 11f, 46f, 11f, 11f, 1.5f, roof)
        add(13f, 13f, 47.5f, 7f, 7f, 5f, steel)
        add(14.5f, 14.5f, 52.5f, 4f, 4f, 5f, 0xFFB5412F.toInt())
        add(15.5f, 15.5f, 57.5f, 2f, 2f, 4f, 0xFFF5CD30.toInt())
        stairs(12f, 14.5f, 4f, 46f)
        for (i in 0 until 4) tree(-17f + (i % 2) * 34f, -17f + (i / 2) * 34f, 0.8f)

        for (k in -4..4) for (m in -4..4) {
            if (k == 0 && m == 0) continue
            val cx = 60f * k
            val cy = 60f * m
            val t = r.nextInt(100)
            if (t < 34) {
                // skyscraper
                val w = 22f + r.nextInt(8)
                val d = 22f + r.nextInt(8)
                val h = 30f + r.nextInt(70)
                add(cx - w / 2f, cy - d / 2f, 0f, w, d, h, col(TOWN, r.nextInt(6)))
                add(cx - w / 2f - 0.5f, cy - d / 2f - 0.5f, h, w + 1f, d + 1f, 1.2f, roof)
                add(cx - 3f, cy - 3f, h + 1.2f, 6f, 6f, 4f, 0xFF8E959C.toInt())
                windows(cx - w / 2f, cy - d / 2f, w, d, h)
                if (h <= 60f && r.nextBoolean()) stairs(cx - w / 2f, cy - 2f, 4f, h)
            } else if (t < 62) {
                // four houses and a yard tree
                for (i in 0 until 4) {
                    val hx = cx + (if (i % 2 == 0) -13f else 13f) - 8f
                    val hy = cy + (if (i / 2 == 0) -13f else 13f) - 8f
                    val hh = 9f + r.nextInt(4)
                    add(hx, hy, 0f, 16f, 16f, hh, col(HOUSE, r.nextInt(6)))
                    add(hx - 1.5f, hy - 1.5f, hh, 19f, 19f, 3.5f, 0xFFB5412F.toInt())
                    add(hx + 5f, hy + 5f, hh + 3.5f, 6f, 6f, 3f, 0xFFB5412F.toInt())
                    add(hx + 16f - 0.05f, hy + 6f, 0f, 0.2f, 4f, 6f, 0xFF5A4030.toInt(), 7)
                    add(hx + 16f - 0.05f, hy + 11f, 3f, 0.2f, 3f, 3f, glass1, 7)
                    add(hx + 16f - 0.05f, hy + 1f, 3f, 0.2f, 3f, 3f, glass1, 7)
                }
                tree(cx, cy, 0.8f)
            } else if (t < 80) {
                // park: lawn, pond, hill, big trees
                add(cx - 22f, cy - 22f, 0f, 44f, 44f, 0.08f, 0xFF4F9A3B.toInt(), 7)
                add(cx - 7f, cy - 7f, 0f, 14f, 14f, 0.12f, 0xFF4AA3E0.toInt(), 7)
                for (i in 0 until 4) add(cx + 6f + i * 1.5f, cy - 22f + i * 1.5f, 0f, 12f - i * 3f, 12f - i * 3f, 1.8f * (i + 1), 0xFF5CAE46.toInt())
                for (i in 0 until 7) tree(cx + r.nextFloat() * 40f - 20f, cy + r.nextFloat() * 40f - 20f, 0.9f + r.nextFloat() * 0.8f)
            } else {
                // office row
                for (i in 0 until 3) {
                    val w = 14f + r.nextInt(6)
                    val d = 14f + r.nextInt(6)
                    val h = 18f + r.nextInt(30)
                    val bx = cx + (i - 1) * 16f - w / 2f
                    val by = cy - d / 2f + (r.nextFloat() * 14f - 7f)
                    add(bx, by, 0f, w, d, h, col(TOWN, r.nextInt(6)))
                    add(bx - 0.4f, by - 0.4f, h, w + 0.8f, d + 0.8f, 1f, roof)
                    windows(bx, by, w, d, h)
                    if (i == 1) add(bx + w / 2f - 2f, by + d / 2f - 2f, h + 1f, 4f, 4f, 3f, steel)
                }
            }
        }
        return GameMap(
            "Town", "Huge city: skyscrapers, houses, parks, a plaza with a clock tower and climbable rooftops.",
            floatArrayOf(-300f, -300f, 300f, 300f), 0xFF6BA64A.toInt(), b, 0f, 30f, 0xFF5BA3E8.toInt(), 0xFFD6EEFF.toInt()
        )
    }
}
