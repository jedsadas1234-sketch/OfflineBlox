package com.offlineblox

object L {
    var th = false
    fun t(en: String, thai: String) = if (th) thai else en
    fun list(en: List<String>, thai: List<String>) = if (th) thai else en

    val hairTh = listOf("ไม่มี", "สั้น", "ตั้งชัน", "ยาว", "โมฮอว์ก", "มวย")
    val hatsTh = listOf("ไม่มี", "หมวกแก๊ป", "หมวกทรงสูง", "มงกุฎ", "หมวกปาร์ตี้", "หมวกคาวบอย", "หูฟัง", "หมวกไหมพรม", "หูกระต่าย", "ฮาโล")
    val facesTh = listOf("ยิ้ม", "เท่", "โกรธ", "แลบลิ้น", "ตกใจ", "สุขใจ", "เขินอาย", "ง่วง")
    val backsTh = listOf("ไม่มี", "ผ้าคลุม", "ปีก", "เป้", "เจ็ตแพ็ก", "ดาบ", "ปีกค้างคาว")
    val designsTh = listOf("ไม่มี", "ลายขวาง", "ลายตั้ง", "กระเป๋า", "หัวใจ", "กากบาท")

    private val mapNamesTh = mapOf("Baseplate" to "ลานเปล่า", "Obby" to "โอบบี้", "Town" to "เมืองเล็ก")
    private val mapDescTh = mapOf(
        "Baseplate" to "ลานกว้างมหึมา มีพีระมิด ทางลาดขึ้นฟ้า หอคอยพร้อมแท่นเด้ง และก้อนลูกบาศก์เพียบ",
        "Obby" to "โอบบี้ยาวมาก 8 ด่าน แท่นเลื่อน แท่นกระพริบ ลาวา ลิฟต์ แท่นเด้ง และเช็กพอยต์",
        "Town" to "เมืองใหญ่ มีตึกระฟ้า บ้าน สวนสาธารณะ จัตุรัสและหอนาฬิกา ปีนขึ้นดาดฟ้าได้"
    )
    fun mapName(n: String) = if (th) (mapNamesTh[n] ?: n) else n
    fun mapDesc(n: String): String {
        if (th) return mapDescTh[n] ?: (Maps.all.firstOrNull { it.name == n }?.desc ?: "")
        return Maps.all.firstOrNull { it.name == n }?.desc ?: ""
    }
}
