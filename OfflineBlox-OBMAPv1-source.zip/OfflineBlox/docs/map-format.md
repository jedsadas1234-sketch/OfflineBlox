# OfflineBlox map package format

## OBMAP v1

A `.map` file exported by the Editor is an OBMAP v1 package. It uses a fixed binary header, a readable UTF-8 JSON manifest, and binary asset chunks. The Editor's **Code** panel continues to show the editable world JSON rather than package bytes.

### Header (big-endian)

| Field | Size | Meaning |
|---|---:|---|
| Magic | 5 bytes | ASCII `OBMAP` |
| Version | 2 bytes | `1` |
| Flags | 4 bytes | Reserved, currently `0` |
| Manifest length | 4 bytes | UTF-8 manifest byte count |
| Asset count | 4 bytes | Number of directory entries |
| Payload length | 8 bytes | Total binary asset bytes |

The header is followed by the manifest and then the concatenated payload chunks. Asset offsets are relative to the beginning of the payload.

### Manifest and assets

The manifest is the regular map JSON with an `_obmap` object containing `format`, `version`, and an `assets` directory. Each directory entry contains `id`, `type`, `offset`, `length`, and SHA-256 checksum.

- Texture chunks use `texture/png` and contain raw PNG bytes. The manifest texture entry refers to the chunk through `asset`.
- Mesh chunks use `mesh/f32i32`. Their little-endian body begins with four 32-bit counts (vertex floats, indices, UV floats, vertex colours), followed by those arrays in that order. The manifest model entry keeps its name, size and material/texture reference and points to the chunk through `asset`.
- World metadata and object transforms remain readable JSON in the manifest.

The reader validates package version, total lengths, asset ranges, duplicate IDs and SHA-256 checksums before reconstructing the legacy JSON representation used by the Editor and current Engine map model.

## Compatibility

Legacy JSON `.map` files remain importable. Export from the Editor and game now writes OBMAP v1. Project autosaves and the Code panel remain JSON source so they stay editable. Multiplayer's current text-map handshake remains compatible with legacy JSON for now.

## Current engine limitation

OBMAP v1 packages preserve embedded textures and meshes as binary chunks and the Engine can read/import the package container. The current world renderer still renders primitive boxes only; model and texture rendering in-game is a separate renderer implementation step and is not claimed as complete in this build.
