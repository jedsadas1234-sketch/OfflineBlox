package com.rate.phone
import android.app.*
import android.os.*
import android.webkit.*
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
  inner class Bridge {
    @JavascriptInterface fun info(): String {
      val mi = ActivityManager.MemoryInfo()
      (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
      val st = StatFs(Environment.getDataDirectory().path)
      val dm = resources.displayMetrics
      var f = 0L
      for (i in 0 until Runtime.getRuntime().availableProcessors()) try {
        f = maxOf(f, File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toLong())
      } catch (e: Exception) {}
      val soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE
      @Suppress("DEPRECATION") val hz = windowManager.defaultDisplay.refreshRate
      return JSONObject().put("brand", Build.MANUFACTURER).put("model", Build.MODEL).put("soc", soc)
        .put("hw", Build.HARDWARE).put("cores", Runtime.getRuntime().availableProcessors())
        .put("freq", f / 1e6).put("ram", mi.totalMem / 1e9).put("storage", st.totalBytes / 1e9)
        .put("w", maxOf(dm.widthPixels, dm.heightPixels)).put("h", minOf(dm.widthPixels, dm.heightPixels))
        .put("hz", hz.toDouble()).put("android", Build.VERSION.RELEASE).toString()
    }
  }
  override fun onCreate(s: Bundle?) {
    super.onCreate(s)
    window.statusBarColor = 0xFF0B0B14.toInt(); window.navigationBarColor = 0xFF0B0B14.toInt()
    val w = WebView(this)
    w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true
    w.setBackgroundColor(0xFF0B0B14.toInt())
    w.addJavascriptInterface(Bridge(), "Android")
    w.loadUrl("file:///android_asset/index.html")
    setContentView(w)
  }
}
