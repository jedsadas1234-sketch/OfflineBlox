package com.offlineblox.app

/** กล่องในแมพ: x,y,z = มุมต่ำสุด, w,h,d = ขนาด */
class Block(
    val x: Float, val y: Float, val z: Float,
    val w: Float, val h: Float, val d: Float,
    val color: Int
)

class GameMap(
    val id: String,
    val name: String,
    val desc: String,
    val sky: Int,
    val spawnX: Float, val spawnY: Float, val spawnZ: Float,
    val voidY: Float,
    val blocks: List<Block>
)

object Maps {
    private fun c(rgb: Int): Int = 0xFF000000.toInt() or rgb

    val all: List<GameMap> by lazy { listOf(grass(), obby(), city()) }

    fun byId(id: String?): GameMap = all.firstOrNull { it.id == id } ?: all[0]

    private fun tree(b: MutableList<Block>, x: Float, z: Float) {
        b.add(Block(x - 0.4f, 0f, z - 0.4f, 0.8f, 3f, 0.8f, c(0x6D4C41)))
        b.add(Block(x - 1.6f, 3f, z - 1.6f, 3.2f, 2.6f, 3.2f, c(0x2E7D32)))
        b.add(Block(x - 0.9f, 5.6f, z - 0.9f, 1.8f, 1.2f, 1.8f, c(0x388E3C)))
    }

    private fun house(b: MutableList<Block>, x: Float, z: Float, wall: Int, roof: Int) {
        // ผนัง 8x8 สูง 4 มีประตูกว้าง 2 ด้านหน้า (z ต่ำสุด)
        b.add(Block(x, 0f, z + 7.5f, 8f, 4f, 0.5f, wall))        // หลัง
        b.add(Block(x, 0f, z, 0.5f, 4f, 8f, wall))               // ซ้าย
        b.add(Block(x + 7.5f, 0f, z, 0.5f, 4f, 8f, wall))        // ขวา
        b.add(Block(x, 0f, z, 3f, 4f, 0.5f, wall))               // หน้าซ้าย
        b.add(Block(x + 5f, 0f, z, 3f, 4f, 0.5f, wall))          // หน้าขวา
        b.add(Block(x + 3f, 2.8f, z, 2f, 1.2f, 0.5f, wall))      // เหนือประตู
        b.add(Block(x - 0.5f, 4f, z - 0.5f, 9f, 0.5f, 9f, roof)) // หลังคา
        b.add(Block(x + 1f, 0f, z + 5f, 2f, 1f, 1.2f, c(0x8D6E63))) // โต๊ะ
    }

    private fun grass(): GameMap {
        val b = ArrayList<Block>()
        b.add(Block(-40f, -1f, -40f, 80f, 1f, 80f, c(0x5DBB4A)))
        b.add(Block(-2f, 0f, -40f, 4f, 0.05f, 80f, c(0xD7C79E)))
        val trees = listOf(8f to 6f, -9f to 10f, 14f to -8f, -15f to -12f,
            20f to 15f, -22f to 5f, 5f to -22f, -6f to -28f, 28f to -20f, -30f to 25f)
        for ((tx, tz) in trees) tree(b, tx, tz)
        house(b, -16f, -6f, c(0xEFE6D2), c(0xB71C1C))
        house(b, 9f, 12f, c(0xBBDEFB), c(0x37474F))
        // บันไดขึ้นหอคอย
        for (i in 0 until 12) {
            b.add(Block(14f + i * 1.2f, 0f, -22f, 1.2f, (i + 1) * 0.5f, 5f, c(0xBDBDBD)))
        }
        b.add(Block(28.4f, 0f, -22f, 6f, 6.5f, 5f, c(0xFFD54F)))
        // กล่องกระโดดเล่น
        for (i in 0 until 6) {
            b.add(Block(-4f + i * 1.8f, 0f, 20f + (i % 2) * 2f, 1.5f, 0.8f + i * 0.6f, 1.5f,
                c(if (i % 2 == 0) 0xFF7043 else 0x42A5F5)))
        }
        // กำแพงรอบแมพ
        b.add(Block(-40f, 0f, -40f, 80f, 2f, 1f, c(0x9E9E9E)))
        b.add(Block(-40f, 0f, 39f, 80f, 2f, 1f, c(0x9E9E9E)))
        b.add(Block(-40f, 0f, -40f, 1f, 2f, 80f, c(0x9E9E9E)))
        b.add(Block(39f, 0f, -40f, 1f, 2f, 80f, c(0x9E9E9E)))
        return GameMap("grass", "ทุ่งหญ้า", "แมพเริ่มต้น มีบ้าน ต้นไม้ หอคอย",
            c(0x87CEEB), 0f, 2f, -5f, -30f, b)
    }

    private fun obby(): GameMap {
        val b = ArrayList<Block>()
        b.add(Block(-5f, -1f, -5f, 10f, 1f, 10f, c(0x4CAF50)))
        val cols = intArrayOf(0xF44336, 0xFF9800, 0xFFEB3B, 0x4CAF50, 0x2196F3, 0x9C27B0)
        var x = 0f
        var y = 0f
        var z = 7f
        for (i in 0 until 26) {
            val w = if (i % 3 == 2) 2f else 3f
            b.add(Block(x - w / 2f, y - 0.5f, z, w, 0.5f, w, c(cols[i % cols.size])))
            z += w + 1.6f
            x += if (i % 2 == 0) 2.2f else -2.2f
            y += 0.45f
        }
        b.add(Block(x - 3f, y - 0.5f, z, 6f, 0.5f, 6f, c(0xFFC107)))
        return GameMap("obby", "ด่านกระโดด", "กระโดดข้ามแพลตฟอร์ม ตกแล้วเกิดใหม่",
            c(0xFFB74D), 0f, 2f, 0f, -12f, b)
    }

    private fun city(): GameMap {
        val b = ArrayList<Block>()
        b.add(Block(-70f, -1f, -70f, 140f, 1f, 140f, c(0x607D8B)))
        val pal = intArrayOf(0x90A4AE, 0xB0BEC5, 0xFFCC80, 0xA5D6A7, 0x90CAF9, 0xF48FB1)
        for (gx in -3..3) {
            for (gz in -3..3) {
                if (gx == 0 && gz == 0) continue
                val h = 6f + ((gx * 7 + gz * 13 + 40) % 9) * 3f
                val bx = gx * 20f - 6f
                val bz = gz * 20f - 6f
                b.add(Block(bx, 0f, bz, 12f, h, 12f, c(pal[(gx + gz + 10) % pal.size])))
                b.add(Block(bx + 4.5f, h, bz + 4.5f, 3f, 1f, 3f, c(0x455A64)))
            }
        }
        // ลานกลางเมืองมีขั้นบันไดกับน้ำพุ
        b.add(Block(-3f, 0f, -3f, 6f, 0.4f, 6f, c(0xCFD8DC)))
        b.add(Block(-1.5f, 0.4f, -1.5f, 3f, 0.6f, 3f, c(0x4FC3F7)))
        for (i in 0 until 5) {
            b.add(Block(-8f, 0f, 8f + i * 1.4f, 2f, 0.5f + i * 0.5f, 1.4f, c(0xFFAB91)))
        }
        return GameMap("city", "เมืองบล็อก", "ตึกสูงเรียงเป็นตาราง วิ่งเล่นในถนน",
            c(0x81D4FA), 0f, 2f, 3f, -30f, b)
    }
}
