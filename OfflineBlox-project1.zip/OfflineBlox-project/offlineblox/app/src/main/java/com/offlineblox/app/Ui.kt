package com.offlineblox.app

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min
import kotlin.math.sqrt

/** ตัวช่วยสร้างหน้าตาแบบบล็อกเหลี่ยมๆ ด้วยโค้ด (ไม่ต้องมีไฟล์ layout) */
object Ui {
    const val BG = 0xFF161A24.toInt()
    const val PANEL = 0xDD0E1118.toInt()
    const val GREEN = 0xFF2E9E3E.toInt()
    const val BLUE = 0xFF2A6BD6.toInt()
    const val RED = 0xFFD64545.toInt()
    const val GRAY = 0xFF4A5060.toInt()
    const val TEXT = 0xFFF2F4F8.toInt()
    const val DIM = 0xFF9AA3B5.toInt()

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun box(fill: Int, border: Int = 0x33FFFFFF, strokeDp: Int = 2, ctx: Context? = null): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = 0f
        val px = if (ctx != null) dp(ctx, strokeDp) else strokeDp
        d.setStroke(px, border)
        return d
    }

    @Suppress("DEPRECATION")
    fun immersive(a: Activity) {
        a.window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    fun label(ctx: Context, text: String, sp: Float = 16f, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    fun button(ctx: Context, text: String, color: Int = GREEN, onClick: () -> Unit): Button {
        val b = Button(ctx)
        b.text = text
        b.setTextColor(Color.WHITE)
        b.textSize = 16f
        b.isAllCaps = false
        b.background = box(color, 0x66FFFFFF, 2, ctx)
        b.setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))
        b.setOnClickListener { onClick() }
        return b
    }

    fun col(ctx: Context): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    fun row(ctx: Context): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        return l
    }

    fun lp(w: Int, h: Int, weight: Float = 0f, margin: Int = 0, ctx: Context? = null): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        val m = if (ctx != null) dp(ctx, margin) else margin
        p.setMargins(m, m, m, m)
        return p
    }

    val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    val CENTER = Gravity.CENTER
}

/** จอยสติ๊กเสมือน */
class Joystick(ctx: Context, private val onMove: (Float, Float) -> Unit) : View(ctx) {
    private var kx = 0f
    private var ky = 0f
    private var active = false
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFFFFF }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 6f
        canvas.drawCircle(cx, cy, r, basePaint)
        canvas.drawCircle(cx, cy, r, ringPaint)
        canvas.drawCircle(cx + kx * r, cy + ky * r, r * 0.38f, knobPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 6f
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                active = true
                var dx = (e.x - cx) / r
                var dy = (e.y - cy) / r
                val len = sqrt(dx * dx + dy * dy)
                if (len > 1f) { dx /= len; dy /= len }
                kx = dx; ky = dy
                onMove(dx, -dy)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                active = false
                kx = 0f; ky = 0f
                onMove(0f, 0f)
            }
        }
        invalidate()
        return true
    }
}
