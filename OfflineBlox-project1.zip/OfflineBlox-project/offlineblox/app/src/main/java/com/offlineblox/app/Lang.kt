package com.offlineblox

object L {
    var th = false
    fun t(en: String, thai: String) = if (th) thai else en
    fun list(en: List<String>, thai: List<String>) = if (th) thai else en

    val hairTh = listOf("ไม่มี", "สั้น", "ตั้งชัน", "ยาว", "โมฮอว์ก", "มวย")
    val hatsTh = listOf("ไม่มี", "หมวกแก๊ป", "หมวกทรงสูง", "มงกุฎ", "หมวกปาร์ตี้", "หมวกคาวบอย", "หูฟัง", "หมวกไหมพรม", "หูกระต่าย", "ฮาโล")
    val facesTh = listOf("ยิ้ม", "เท่", "โกรธ", "แลบลิ้น", "ตกใจ", "สุขใจ", "เขินอาย", "ง่วง")
    val backsTh = listOf("ไม่มี", "ผ้าคลุม", "ปีก", "เป้", "เจ็ตแพ็ก", "ดาบ", "ปีกค้างคาว")
    val designsTh = listOf("ไม่มี", "ลายขวาง", "ลายตั้ง", "กระเป๋า", "หัวใจ", "กากบาท")

    private val mapNamesTh = mapOf("Baseplate" to "ลานเปล่า", "Obby" to "โอบบี้", "Town" to "เมืองเล็ก")
    private val mapDescTh = mapOf(
        "Baseplate" to "ลานโล่ง มีบันไดกับลูกบาศก์ วิ่งเล่นอิสระ",
        "Obby" to "กระโดดข้ามแท่น ตกแล้วเกิดใหม่",
        "Town" to "เมืองเล็กมีบ้านกับต้นไม้"
    )
    fun mapName(n: String) = if (th) (mapNamesTh[n] ?: n) else n
    fun mapDesc(n: String): String {
        if (th) return mapDescTh[n] ?: ""
        return Maps.all.firstOrNull { it.name == n }?.desc ?: ""
    }
}
