package com.offlineblox.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.View
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class Tag(val text: String, val x: Float, val y: Float)

class GameRenderer(private val game: Game) : GLSurfaceView.Renderer {
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val clip = FloatArray(4)
    private val world = floatArrayOf(0f, 0f, 0f, 1f)
    private var w = 1
    private var h = 1
    private var last = 0L

    @Volatile var onTick: ((Float) -> Unit)? = null
    @Volatile var onTags: ((List<Tag>) -> Unit)? = null

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        Gfx.init()
        val s = game.map.sky
        GLES20.glClearColor(
            ((s shr 16) and 255) / 255f, ((s shr 8) and 255) / 255f, (s and 255) / 255f, 1f
        )
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        last = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = width
        h = if (height == 0) 1 else height
        GLES20.glViewport(0, 0, w, h)
        Matrix.perspectiveM(proj, 0, 60f, w.toFloat() / h.toFloat(), 0.1f, 400f)
    }

    private fun tag(text: String, x: Float, y: Float, z: Float): Tag? {
        world[0] = x; world[1] = y; world[2] = z; world[3] = 1f
        Matrix.multiplyMV(clip, 0, vp, 0, world, 0)
        if (clip[3] <= 0.1f) return null
        val nx = clip[0] / clip[3]
        val ny = clip[1] / clip[3]
        return Tag(text, (nx * 0.5f + 0.5f) * w, (1f - (ny * 0.5f + 0.5f)) * h)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else (now - last) / 1_000_000_000f
        last = now
        game.update(dt)
        onTick?.invoke(dt)

        val dist = 7f
        val cy = game.camYaw
        val cp = game.camPitch
        val tx = game.x
        val ty = game.y + 1.4f
        val tz = game.z
        val ex = tx - sin(cy) * cos(cp) * dist
        val ey = ty + sin(cp) * dist
        val ez = tz - cos(cy) * cos(cp) * dist
        Matrix.setLookAtM(view, 0, ex, ey, ez, tx, ty, tz, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Gfx.begin()
        for (b in game.map.blocks) Gfx.block(vp, b)
        AvatarDraw.draw(vp, game.x, game.y, game.z, game.yaw, game.myAvatar, game.walk, game.moving)

        val tags = ArrayList<Tag>()
        tag(game.myName, game.x, game.y + 2.5f, game.z)?.let { tags.add(it) }
        for (r in game.remotes.values) {
            AvatarDraw.draw(vp, r.x, r.y, r.z, r.yaw, r.avatar, r.walk, r.moving)
            tag(r.name, r.x, r.y + 2.5f, r.z)?.let { tags.add(it) }
        }
        onTags?.invoke(tags)
    }
}

/** ชั้นโปร่งใสวาดชื่อผู้เล่นเหนือหัว */
class NameTagView(ctx: Context) : View(ctx) {
    @Volatile private var tags: List<Tag> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * ctx.resources.displayMetrics.density
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    fun setTags(t: List<Tag>) {
        tags = t
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        for (t in tags) canvas.drawText(t.text.replace('_', ' '), t.x, t.y, paint)
    }
}
