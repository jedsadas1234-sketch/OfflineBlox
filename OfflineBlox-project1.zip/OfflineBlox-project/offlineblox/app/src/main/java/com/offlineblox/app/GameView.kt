package com.offlineblox

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.min

class GameView(ctx: Context, val net: Net, val gm: GameMap, val av: Avatar) : View(ctx) {
    interface Listener { fun onMenu(); fun onChat() }

    var listener: Listener? = null
    private val d = resources.displayMetrics.density
    var px = gm.sx
    var py = gm.sy
    var pz = 0f
    private var vz = 0f
    private var onGround = true
    private var phase = 0f
    private var swing = 0f
    private var camX = px
    private var camY = py
    private var camZ = 0f
    private var last = System.nanoTime()
    private var lastSend = 0L
    private var fps = 60f
    private var joyId = -1
    private var jox = 0f
    private var joy = 0f
    private var jx = 0f
    private var jy = 0f
    private var jumpId = -1
    private val cam = Iso.Cam(0f, 0f, 11f * d)
    private val sky = Paint()
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val menuR = RectF()
    private val chatR = RectF()
    private val body = 0.7f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sky.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), gm.skyTop, gm.skyBot, Shader.TileMode.CLAMP)
        menuR.set(8 * d, 8 * d, 76 * d, 36 * d)
        chatR.set(82 * d, 8 * d, 150 * d, 36 * d)
    }

    fun respawn() { px = gm.sx; py = gm.sy; pz = 1f; vz = 0f }

    // ---------- physics ----------
    private fun blocked(nx: Float, ny: Float, z: Float): Boolean {
        for (b in gm.boxes) {
            val top = b.z + b.h
            if (z < top - 0.3f && z + 4.5f > b.z &&
                nx + body > b.x && nx - body < b.x + b.w && ny + body > b.y && ny - body < b.y + b.d) return true
        }
        return false
    }

    private fun groundAt(x: Float, y: Float, zFrom: Float): Float {
        var g = -1000f
        val f = gm.floor
        if (f != null && x > f[0] && x < f[2] && y > f[1] && y < f[3]) g = 0f
        for (b in gm.boxes) {
            val top = b.z + b.h
            if (x + 0.4f > b.x && x - 0.4f < b.x + b.w && y + 0.4f > b.y && y - 0.4f < b.y + b.d && top <= zFrom + 0.3f && top > g) g = top
        }
        return g
    }

    private fun update(dt: Float) {
        val mag = min(1f, hypot(jx, jy))
        var moving = false
        if (mag > 0.12f) {
            var wx = (jx + 2 * jy) / 2f
            var wy = (2 * jy - jx) / 2f
            val l = hypot(wx, wy)
            if (l > 0.0001f) {
                wx /= l; wy /= l
                val sp = 9f * min(1f, mag * 1.3f)
                val nx = px + wx * sp * dt
                if (!blocked(nx, py, pz)) px = nx
                val ny = py + wy * sp * dt
                if (!blocked(px, ny, pz)) py = ny
                moving = true
            }
        }
        swing += ((if (moving) 1f else 0f) - swing) * min(1f, dt * 10f)
        phase += dt * 10f * swing

        if (jumpId != -1 && onGround) { vz = 12.5f; onGround = false }
        vz -= 34f * dt
        val nz = pz + vz * dt
        val g = groundAt(px, py, pz)
        if (vz <= 0f && nz <= g) { pz = g; vz = 0f; onGround = true } else { pz = nz; onGround = false }
        if (pz < -30f) respawn()

        camX += (px - camX) * min(1f, dt * 8f)
        camY += (py - camY) * min(1f, dt * 8f)
        camZ += (pz - camZ) * min(1f, dt * 5f)

        net.me.x = px; net.me.y = py; net.me.z = pz
        val tm = SystemClock.elapsedRealtime()
        if (tm - lastSend >= 50) { lastSend = tm; net.sendState(px, py, pz) }

        for (r in net.peers.values) {
            if (!r.fresh) continue
            val dx = r.tx - r.x
            val dy = r.ty - r.y
            val k = min(1f, dt * 14f)
            r.x += dx * k; r.y += dy * k; r.z += (r.tz - r.z) * k
            val mv = hypot(dx, dy) > 0.05f
            r.swing += ((if (mv) 1f else 0f) - r.swing) * min(1f, dt * 10f)
            r.phase += dt * 10f * r.swing
        }
    }

    // ---------- drawing ----------
    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        var dt = (now - last) / 1e9f
        last = now
        if (dt > 0.0001f) fps += (1f / dt - fps) * 0.1f
        if (dt > 0.05f) dt = 0.05f
        update(dt)
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, sky)
        cam.ox = w / 2f - (camX - camY) * cam.s
        cam.oy = h * 0.62f - (camX + camY) * cam.s * 0.5f + camZ * cam.s * 0.8f
        drawWorld(c)
        drawLabels(c)
        drawHud(c, w, h)
        postInvalidateOnAnimation()
    }

    private fun drawWorld(c: Canvas) {
        val f = gm.floor
        if (f != null) {
            Iso.box(c, cam, f[0], f[1], -1.5f, f[2] - f[0], f[3] - f[1], 1.5f, gm.floorColor)
            pen.style = Paint.Style.STROKE
            pen.strokeWidth = 1.5f
            pen.color = 0x22FFFFFF
            var gx = ceil(f[0] / 4f) * 4f
            while (gx <= f[2]) {
                c.drawLine(cam.sx(gx, f[1]), cam.sy(gx, f[1], 0f), cam.sx(gx, f[3]), cam.sy(gx, f[3], 0f), pen)
                gx += 4f
            }
            var gy = ceil(f[1] / 4f) * 4f
            while (gy <= f[3]) {
                c.drawLine(cam.sx(f[0], gy), cam.sy(f[0], gy, 0f), cam.sx(f[2], gy), cam.sy(f[2], gy, 0f), pen)
                gy += 4f
            }
        }
        val items = ArrayList<Pair<Float, () -> Unit>>()
        for (b in gm.boxes) {
            val fn: () -> Unit = { Iso.box(c, cam, b.x, b.y, b.z, b.w, b.d, b.h, b.color) }
            items.add(Pair(b.x + b.w / 2f + b.y + b.d / 2f + b.z * 0.02f, fn))
        }
        for (r in net.peers.values) {
            if (!r.fresh) continue
            val fn: () -> Unit = { Iso.avatar(c, cam, r.av, r.x, r.y, r.z, r.phase, r.swing) }
            items.add(Pair(r.x + r.y, fn))
        }
        val me: () -> Unit = { Iso.avatar(c, cam, av, px, py, pz, phase, swing) }
        items.add(Pair(px + py, me))
        items.sortBy { it.first }
        for (it in items) it.second()
    }

    private fun label(c: Canvas, text: String, x: Float, y: Float, size: Float, bubble: Boolean) {
        txt.textSize = size * d
        txt.textAlign = Paint.Align.CENTER
        txt.typeface = Typeface.DEFAULT_BOLD
        if (bubble) {
            val tw = txt.measureText(text)
            pen.style = Paint.Style.FILL
            pen.color = 0xEEFFFFFF.toInt()
            c.drawRoundRect(x - tw / 2 - 6 * d, y - size * d - 4 * d, x + tw / 2 + 6 * d, y + 5 * d, 6 * d, 6 * d, pen)
            txt.color = 0xFF111111.toInt()
            c.drawText(text, x, y, txt)
        } else {
            txt.style = Paint.Style.STROKE; txt.strokeWidth = 3f; txt.color = 0xFF000000.toInt()
            c.drawText(text, x, y, txt)
            txt.style = Paint.Style.FILL; txt.color = 0xFFFFFFFF.toInt()
            c.drawText(text, x, y, txt)
        }
        txt.style = Paint.Style.FILL
    }

    private fun drawLabels(c: Canvas) {
        val now = SystemClock.elapsedRealtime()
        fun tag(name: String, chat: String, chatT: Long, x: Float, y: Float, z: Float) {
            val sx = cam.sx(x, y)
            val sy = cam.sy(x, y, z + 6.3f)
            label(c, name, sx, sy, 13f, false)
            if (chat.isNotEmpty() && now - chatT < 6000) label(c, chat, sx, sy - 22 * d, 13f, true)
        }
        tag(net.me.name, net.me.chat, net.me.chatT, px, py, pz)
        for (r in net.peers.values) if (r.fresh) tag(r.name, r.chat, r.chatT, r.x, r.y, r.z)
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        // old-school top buttons
        for ((rect, t) in listOf(menuR to L.t("Menu", "เมนู"), chatR to L.t("Chat", "แชท"))) {
            pen.style = Paint.Style.FILL; pen.color = 0xAA222222.toInt()
            c.drawRect(rect, pen)
            pen.style = Paint.Style.STROKE; pen.strokeWidth = 2f; pen.color = 0xFFCCCCCC.toInt()
            c.drawRect(rect, pen)
            txt.textSize = 14f * d; txt.textAlign = Paint.Align.CENTER; txt.color = 0xFFFFFFFF.toInt(); txt.typeface = Typeface.DEFAULT_BOLD
            c.drawText(t, rect.centerX(), rect.centerY() + 5 * d, txt)
        }
        // leaderboard
        val rows = ArrayList<String>()
        rows.add(net.me.name)
        for (r in net.peers.values) rows.add(r.name)
        val pw = 130f * d
        val x0 = w - pw - 8 * d
        pen.style = Paint.Style.FILL; pen.color = 0xAA333333.toInt()
        c.drawRect(x0, 8 * d, x0 + pw, 8 * d + 22 * d, pen)
        pen.color = 0x88000000.toInt()
        c.drawRect(x0, 30 * d, x0 + pw, 30 * d + min(rows.size, 10) * 20 * d, pen)
        txt.textAlign = Paint.Align.LEFT; txt.textSize = 13f * d; txt.color = 0xFFFFFFFF.toInt()
        c.drawText(L.t("Players", "ผู้เล่น"), x0 + 6 * d, 24 * d, txt)
        txt.typeface = Typeface.DEFAULT
        for ((i, n) in rows.take(10).withIndex()) c.drawText(n, x0 + 6 * d, 45 * d + i * 20 * d, txt)
        // status
        val st = when (net.role) {
            1 -> L.t("SERVER ON  -  IP: ", "เซิร์ฟเปิดอยู่ - IP: ") + net.ipText
            2 -> L.t("Connected to server", "เชื่อมต่อเซิร์ฟแล้ว")
            else -> ""
        }
        if (st.isNotEmpty()) {
            txt.textAlign = Paint.Align.CENTER; txt.textSize = 12f * d; txt.color = 0xFFFFFF66.toInt()
            c.drawText(st, w / 2f, 24 * d, txt)
        }
        txt.textAlign = Paint.Align.RIGHT; txt.textSize = 10f * d; txt.color = 0xAAFFFFFF.toInt(); txt.typeface = Typeface.DEFAULT
        c.drawText("${fps.toInt()} fps", w - 12 * d, h - 8 * d, txt)
        // chat log
        val now = SystemClock.elapsedRealtime()
        val lines = net.chatLog.filter { now - it.t < 12000 }.takeLast(6)
        txt.textAlign = Paint.Align.LEFT; txt.textSize = 12f * d
        for ((i, l) in lines.withIndex()) {
            val y = 56 * d + i * 16 * d
            txt.style = Paint.Style.STROKE; txt.strokeWidth = 3f; txt.color = 0xFF000000.toInt()
            c.drawText(l.text, 10 * d, y, txt)
            txt.style = Paint.Style.FILL; txt.color = 0xFFFFFFFF.toInt()
            c.drawText(l.text, 10 * d, y, txt)
        }
        // joystick
        pen.style = Paint.Style.STROKE; pen.strokeWidth = 3f * d / 2
        if (joyId != -1) {
            pen.color = 0x88FFFFFF.toInt()
            c.drawCircle(jox, joy, 50 * d, pen)
            pen.style = Paint.Style.FILL; pen.color = 0xAAFFFFFF.toInt()
            c.drawCircle(jox + jx * 50 * d, joy + jy * 50 * d, 20 * d, pen)
        } else {
            pen.color = 0x44FFFFFF
            c.drawCircle(100 * d, h - 100 * d, 50 * d, pen)
        }
        pen.style = Paint.Style.FILL; pen.color = if (jumpId != -1) 0xAAFFFFFF.toInt() else 0x66FFFFFF
        c.drawCircle(w - 90 * d, h - 90 * d, 38 * d, pen)
        txt.textAlign = Paint.Align.CENTER; txt.textSize = 13f * d; txt.color = 0xFF222222.toInt(); txt.typeface = Typeface.DEFAULT_BOLD
        c.drawText(L.t("JUMP", "กระโดด"), w - 90 * d, h - 85 * d, txt)
    }

    // ---------- touch ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val x = e.getX(i)
                val y = e.getY(i)
                val id = e.getPointerId(i)
                if (menuR.contains(x, y)) listener?.onMenu()
                else if (chatR.contains(x, y)) listener?.onChat()
                else if (x < width * 0.5f && joyId == -1) { joyId = id; jox = x; joy = y; jx = 0f; jy = 0f }
                else if (x >= width * 0.5f && jumpId == -1) jumpId = id
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    if (e.getPointerId(i) == joyId) {
                        val dx = e.getX(i) - jox
                        val dy = e.getY(i) - joy
                        val max = 50f * d
                        val l = hypot(dx, dy)
                        val k = if (l > max) max / l else 1f
                        jx = dx * k / max; jy = dy * k / max
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL) { joyId = -1; jumpId = -1; jx = 0f; jy = 0f }
                if (id == joyId) { joyId = -1; jx = 0f; jy = 0f }
                if (id == jumpId) jumpId = -1
            }
        }
        return true
    }
}
