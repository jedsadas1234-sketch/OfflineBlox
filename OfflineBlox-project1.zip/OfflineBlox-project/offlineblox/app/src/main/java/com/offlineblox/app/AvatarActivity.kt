package com.offlineblox.app

import android.app.Activity
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Bundle
import android.widget.Button
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** ตัวอย่างตัวละครหมุนได้ให้ดูตอนแต่งตัว */
class PreviewRenderer(private val av: AvatarState) : GLSurfaceView.Renderer {
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private var t = 0f
    private var last = 0L

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        Gfx.init()
        GLES20.glClearColor(0.09f, 0.10f, 0.14f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        last = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        Matrix.perspectiveM(proj, 0, 40f, width.toFloat() / (if (height == 0) 1 else height), 0.1f, 50f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else (now - last) / 1_000_000_000f
        last = now
        t += dt
        Matrix.setLookAtM(view, 0, 0f, 1.7f, 7f, 0f, 1.1f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Gfx.begin()
        AvatarDraw.draw(vp, 0f, 0f, 0f, t * 0.9f, av, t * 6f, false)
    }
}

class AvatarActivity : Activity() {
    private lateinit var av: AvatarState
    private lateinit var glView: GLSurfaceView
    private lateinit var grid: GridLayout
    private var slot = "hat"
    private val tabs = HashMap<String, Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(this)
        av = AvatarState.load(this)

        val root = Ui.row(this)
        root.setBackgroundColor(Ui.BG)

        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        glView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        glView.setRenderer(PreviewRenderer(av))
        root.addView(glView, Ui.lp(0, Ui.MATCH, 1f))

        val right = Ui.col(this)
        val pad = Ui.dp(this, 14)
        right.setPadding(pad, pad, pad, pad)
        right.addView(Ui.label(this, "แต่งตัว", 24f, Ui.GREEN, true))

        val tabRow = Ui.row(this)
        for ((id, title) in Catalog.slots) {
            val b = Ui.button(this, title, Ui.GRAY) { selectSlot(id) }
            b.textSize = 13f
            tabs[id] = b
            tabRow.addView(b, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 2, this))
        }
        val tabScroll = HorizontalScrollView(this)
        tabScroll.addView(tabRow)
        right.addView(tabScroll)

        grid = GridLayout(this)
        grid.columnCount = 3
        val gridScroll = ScrollView(this)
        gridScroll.addView(grid)
        right.addView(gridScroll, Ui.lp(Ui.MATCH, Ui.MATCH, 1f))

        right.addView(Ui.button(this, "✔ เสร็จ", Ui.GREEN) { finish() },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        root.addView(right, Ui.lp(0, Ui.MATCH, 1.3f))

        setContentView(root)
        selectSlot(slot)
    }

    override fun onResume() {
        super.onResume()
        Ui.immersive(this)
        glView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glView.onPause()
        AvatarState.save(this, av)
    }

    private fun selectSlot(id: String) {
        slot = id
        for ((k, b) in tabs) {
            b.background = Ui.box(if (k == id) Ui.BLUE else Ui.GRAY, 0x66FFFFFF, 2, this)
        }
        refreshItems()
    }

    private fun refreshItems() {
        grid.removeAllViews()
        val cur = av.get(slot).id
        for (item in Catalog.list(slot)) {
            val fill = if (item.color == 0) 0xFF3A404E.toInt() else item.color
            val lum = (Color.red(fill) * 299 + Color.green(fill) * 587 + Color.blue(fill) * 114) / 1000
            val b = Button(this)
            b.text = item.name
            b.isAllCaps = false
            b.textSize = 12f
            b.setTextColor(if (lum > 150) Color.BLACK else Color.WHITE)
            b.background = if (item.id == cur) Ui.box(fill, Color.WHITE, 4, this)
            else Ui.box(fill, 0x44000000, 2, this)
            b.setOnClickListener {
                av.set(slot, item.id)
                AvatarState.save(this, av)
                refreshItems()
            }
            val lp = GridLayout.LayoutParams()
            lp.width = Ui.dp(this, 96)
            lp.height = Ui.dp(this, 52)
            lp.setMargins(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4))
            grid.addView(b, lp)
        }
    }
}
