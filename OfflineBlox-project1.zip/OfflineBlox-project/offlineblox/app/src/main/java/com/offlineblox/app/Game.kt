package com.offlineblox.app

import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** ผู้เล่นคนอื่นที่เห็นผ่านเน็ต */
class Remote(val id: Int, avatarStr: String) {
    @Volatile var name: String = "Player"
    @Volatile var tx = 0f
    @Volatile var ty = 0f
    @Volatile var tz = 0f
    @Volatile var tyaw = 0f
    @Volatile var moving = false
    var x = 0f
    var y = 0f
    var z = 0f
    var yaw = 0f
    var walk = 0f
    var first = true
    val avatar: AvatarState = AvatarState.decode(avatarStr)
}

class Game(val map: GameMap, val myName: String, val myAvatar: AvatarState) {
    var x = map.spawnX
    var y = map.spawnY
    var z = map.spawnZ
    var yaw = 0f
    var walk = 0f
    var moving = false

    private var vy = 0f
    private var onGround = false

    @Volatile var joyX = 0f
    @Volatile var joyY = 0f
    @Volatile var jumpReq = false
    @Volatile var camYaw = 0f
    @Volatile var camPitch = 0.45f

    val remotes = ConcurrentHashMap<Int, Remote>()

    private val rad = 0.4f
    private val height = 1.8f

    private fun hitBlock(px: Float, py: Float, pz: Float): Block? {
        for (b in map.blocks) {
            if (px - rad < b.x + b.w && px + rad > b.x &&
                py < b.y + b.h && py + height > b.y &&
                pz - rad < b.z + b.d && pz + rad > b.z
            ) return b
        }
        return null
    }

    private fun angDiff(a: Float, b: Float): Float {
        val twoPi = (2 * PI).toFloat()
        var d = (b - a) % twoPi
        if (d > PI) d -= twoPi
        if (d < -PI) d += twoPi
        return d
    }

    fun respawn() {
        x = map.spawnX; y = map.spawnY; z = map.spawnZ
        vy = 0f
    }

    fun update(dtIn: Float) {
        val dt = min(dtIn, 0.05f)
        val fx = sin(camYaw)
        val fz = cos(camYaw)
        val rx = -fz
        val rz = fx
        var dx = fx * joyY + rx * joyX
        var dz = fz * joyY + rz * joyX
        val len = sqrt(dx * dx + dz * dz)
        if (len > 1f) { dx /= len; dz /= len }
        moving = len > 0.15f
        if (moving) {
            val target = atan2(dx, dz)
            yaw += angDiff(yaw, target) * min(1f, dt * 14f)
            walk += dt * 11f
        }

        val speed = 7f
        // แกน X
        var nx = x + dx * speed * dt
        var b = hitBlock(nx, y, z)
        if (b == null) {
            x = nx
        } else {
            val top = b.y + b.h
            if (onGround && top - y <= 0.6f && hitBlock(nx, top + 0.001f, z) == null) {
                x = nx; y = top + 0.001f
            }
        }
        // แกน Z
        val nz = z + dz * speed * dt
        b = hitBlock(x, y, nz)
        if (b == null) {
            z = nz
        } else {
            val top = b.y + b.h
            if (onGround && top - y <= 0.6f && hitBlock(x, top + 0.001f, nz) == null) {
                z = nz; y = top + 0.001f
            }
        }
        // แกน Y
        vy -= 28f * dt
        if (jumpReq && onGround) { vy = 10.5f; onGround = false }
        jumpReq = false
        val ny = y + vy * dt
        val hb = hitBlock(x, ny, z)
        if (hb != null) {
            if (vy <= 0f) { y = hb.y + hb.h + 0.001f; onGround = true } else { y = hb.y - height - 0.001f }
            vy = 0f
        } else {
            y = ny
            onGround = false
        }
        if (y < map.voidY) respawn()

        // ทำให้คนอื่นขยับนุ่มๆ
        for (r in remotes.values) {
            if (r.first) { r.x = r.tx; r.y = r.ty; r.z = r.tz; r.yaw = r.tyaw; r.first = false }
            val k = min(1f, dt * 12f)
            r.x += (r.tx - r.x) * k
            r.y += (r.ty - r.y) * k
            r.z += (r.tz - r.z) * k
            r.yaw += angDiff(r.yaw, r.tyaw) * k
            if (r.moving) r.walk += dt * 11f
        }
    }
}
