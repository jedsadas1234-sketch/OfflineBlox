package com.offlineblox.app

import android.content.Context
import android.opengl.Matrix
import kotlin.math.sin

class Item(val id: String, val slot: String, val name: String, val color: Int, val shape: Int = 0)

object Catalog {
    private fun c(rgb: Int): Int = 0xFF000000.toInt() or rgb

    val slots: List<Pair<String, String>> = listOf(
        "skin" to "สีผิว", "hat" to "หมวก", "face" to "หน้า", "shirt" to "เสื้อ",
        "pants" to "กางเกง", "shoes" to "รองเท้า", "back" to "ของสะพายหลัง"
    )

    private val data: Map<String, List<Item>> by lazy {
        mapOf(
            "skin" to listOf(
                Item("sk0", "skin", "เหลือง", c(0xF5CD30)),
                Item("sk1", "skin", "ผิวแทน", c(0xE0A97A)),
                Item("sk2", "skin", "น้ำตาล", c(0xA0683C)),
                Item("sk3", "skin", "ขาว", c(0xFFE0C8)),
                Item("sk4", "skin", "เขียว", c(0x6BCB5A)),
                Item("sk5", "skin", "ฟ้า", c(0x5AA9E6)),
                Item("sk6", "skin", "ชมพู", c(0xF4A6C0)),
                Item("sk7", "skin", "เทา", c(0xA0A0A0))
            ),
            "hat" to listOf(
                Item("h0", "hat", "ไม่ใส่", 0, 0),
                Item("h1", "hat", "แก๊ปแดง", c(0xE53935), 1),
                Item("h2", "hat", "แก๊ปน้ำเงิน", c(0x1E88E5), 1),
                Item("h3", "hat", "แก๊ปดำ", c(0x212121), 1),
                Item("h4", "hat", "ซิลค์แฮตดำ", c(0x212121), 2),
                Item("h5", "hat", "ซิลค์แฮตม่วง", c(0x7B1FA2), 2),
                Item("h6", "hat", "มงกุฎทอง", c(0xFFC107), 3),
                Item("h7", "hat", "เขาปีศาจ", c(0xD32F2F), 4),
                Item("h8", "hat", "หมวกกันน็อก", c(0x78909C), 5),
                Item("h9", "hat", "บีนนี่เขียว", c(0x43A047), 6),
                Item("h10", "hat", "บีนนี่ชมพู", c(0xEC407A), 6),
                Item("h11", "hat", "กรวยส้ม", c(0xFB8C00), 7),
                Item("h12", "hat", "ฮาโล", c(0xFFD54F), 8),
                Item("h13", "hat", "หมวกถัง", c(0xECEFF1), 9),
                Item("h14", "hat", "ใบพัด", c(0x00ACC1), 10)
            ),
            "face" to listOf(
                Item("f0", "face", "ยิ้ม", 0, 0),
                Item("f1", "face", "แว่นดำ", 0, 1),
                Item("f2", "face", "โกรธ", 0, 2),
                Item("f3", "face", "ตาเดียว", 0, 3),
                Item("f4", "face", "หนวด", 0, 4),
                Item("f5", "face", "แก้มแดง", 0, 5),
                Item("f6", "face", "ตาหัวใจ", 0, 6),
                Item("f7", "face", "หลับตา", 0, 7)
            ),
            "shirt" to listOf(
                Item("s0", "shirt", "แดงเรียบ", c(0xE53935), 0),
                Item("s1", "shirt", "น้ำเงินเรียบ", c(0x1E88E5), 0),
                Item("s2", "shirt", "เขียวเรียบ", c(0x43A047), 0),
                Item("s3", "shirt", "เหลืองลายขวาง", c(0xFDD835), 1),
                Item("s4", "shirt", "ดำลายขวาง", c(0x212121), 1),
                Item("s5", "shirt", "ชมพูโลโก้", c(0xF06292), 2),
                Item("s6", "shirt", "ม่วงโลโก้", c(0x7E57C2), 2),
                Item("s7", "shirt", "ส้มแขนสั้น", c(0xFB8C00), 3),
                Item("s8", "shirt", "ฟ้าแขนสั้น", c(0x29B6F6), 3),
                Item("s9", "shirt", "ขาวแขนสั้น", c(0xF5F5F5), 3),
                Item("s10", "shirt", "เกราะเทา", c(0x78909C), 4),
                Item("s11", "shirt", "เสื้อกั๊กน้ำตาล", c(0x8D6E63), 4),
                Item("s12", "shirt", "ดำเรียบ", c(0x212121), 0)
            ),
            "pants" to listOf(
                Item("p0", "pants", "ยีนส์", c(0x3949AB), 0),
                Item("p1", "pants", "ดำ", c(0x212121), 0),
                Item("p2", "pants", "กากี", c(0xC2B280), 0),
                Item("p3", "pants", "แดง", c(0xC62828), 0),
                Item("p4", "pants", "ขาสั้นฟ้า", c(0x1E88E5), 1),
                Item("p5", "pants", "ขาสั้นเขียว", c(0x43A047), 1),
                Item("p6", "pants", "ขาสั้นดำ", c(0x212121), 1),
                Item("p7", "pants", "ขาว", c(0xECEFF1), 0)
            ),
            "shoes" to listOf(
                Item("o0", "shoes", "ผ้าใบขาว", c(0xF5F5F5), 0),
                Item("o1", "shoes", "ผ้าใบแดง", c(0xE53935), 0),
                Item("o2", "shoes", "ผ้าใบดำ", c(0x212121), 0),
                Item("o3", "shoes", "บูทน้ำตาล", c(0x6D4C41), 1),
                Item("o4", "shoes", "บูทดำ", c(0x212121), 1),
                Item("o5", "shoes", "รองเท้าทอง", c(0xFFC107), 0),
                Item("o6", "shoes", "เขียวนีออน", c(0x76FF03), 0),
                Item("o7", "shoes", "ชมพู", c(0xF48FB1), 0)
            ),
            "back" to listOf(
                Item("b0", "back", "ไม่มี", 0, 0),
                Item("b1", "back", "กระเป๋าแดง", c(0xE53935), 1),
                Item("b2", "back", "กระเป๋าน้ำเงิน", c(0x1E88E5), 1),
                Item("b3", "back", "ผ้าคลุมแดง", c(0xC62828), 2),
                Item("b4", "back", "ผ้าคลุมม่วง", c(0x6A1B9A), 2),
                Item("b5", "back", "ปีกขาว", c(0xFAFAFA), 3),
                Item("b6", "back", "ปีกดำ", c(0x212121), 3),
                Item("b7", "back", "ดาบ", c(0xB0BEC5), 5),
                Item("b8", "back", "เจ็ตแพ็ค", c(0x90A4AE), 6)
            )
        )
    }

    fun list(slot: String): List<Item> = data[slot] ?: emptyList()

    fun find(slot: String, id: String): Item {
        val l = list(slot)
        return l.firstOrNull { it.id == id } ?: l[0]
    }
}

class AvatarState {
    val ids = HashMap<String, String>()

    fun get(slot: String): Item = Catalog.find(slot, ids[slot] ?: "")

    fun set(slot: String, id: String) {
        ids[slot] = id
    }

    fun encode(): String = Catalog.slots.joinToString(",") { get(it.first).id }

    companion object {
        fun decode(s: String?): AvatarState {
            val a = AvatarState()
            val parts = (s ?: "").split(",")
            Catalog.slots.forEachIndexed { i, sl -> a.ids[sl.first] = parts.getOrNull(i) ?: "" }
            return a
        }

        fun load(ctx: Context): AvatarState =
            decode(ctx.getSharedPreferences("ob", Context.MODE_PRIVATE).getString("avatar", ""))

        fun save(ctx: Context, a: AvatarState) {
            ctx.getSharedPreferences("ob", Context.MODE_PRIVATE).edit()
                .putString("avatar", a.encode()).apply()
        }
    }
}

object AvatarDraw {
    private val base = FloatArray(16)
    private val rot = FloatArray(16)
    private const val WHITE = 0xFFFFFFFF.toInt()
    private const val BLACK = 0xFF111111.toInt()

    /** วาดตัวละครที่ตำแหน่ง x,y,z (y = เท้า) หันหน้าไปทาง yaw (เรเดียน) */
    fun draw(
        vp: FloatArray, x: Float, y: Float, z: Float, yaw: Float,
        a: AvatarState, walk: Float, moving: Boolean
    ) {
        val deg = Math.toDegrees(yaw.toDouble()).toFloat()
        Matrix.setIdentityM(rot, 0)
        Matrix.rotateM(rot, 0, deg, 0f, 1f, 0f)
        Matrix.setIdentityM(base, 0)
        Matrix.translateM(base, 0, x, y, z)
        Matrix.rotateM(base, 0, deg, 0f, 1f, 0f)

        fun p(lx: Float, ly: Float, lz: Float, w: Float, h: Float, d: Float, col: Int) =
            Gfx.draw(vp, base, rot, lx, ly, lz, w, h, d, col)

        val skin = a.get("skin").color
        val hat = a.get("hat")
        val face = a.get("face")
        val shirt = a.get("shirt")
        val pants = a.get("pants")
        val shoes = a.get("shoes")
        val back = a.get("back")
        val sw = if (moving) sin(walk) * 0.14f else 0f

        // ขา + กางเกง + รองเท้า
        val legCol = if (pants.shape == 1) skin else pants.color
        p(-0.4f, 0f, -0.2f + sw, 0.38f, 0.7f, 0.4f, legCol)
        p(0.02f, 0f, -0.2f - sw, 0.38f, 0.7f, 0.4f, legCol)
        if (pants.shape == 1) {
            p(-0.405f, 0.35f, -0.205f + sw, 0.39f, 0.35f, 0.41f, pants.color)
            p(0.015f, 0.35f, -0.205f - sw, 0.39f, 0.35f, 0.41f, pants.color)
        }
        val sh = if (shoes.shape == 1) 0.3f else 0.15f
        p(-0.41f, 0f, -0.21f + sw, 0.4f, sh, 0.56f, shoes.color)
        p(0.01f, 0f, -0.21f - sw, 0.4f, sh, 0.56f, shoes.color)

        // ลำตัว + เสื้อ
        p(-0.4f, 0.7f, -0.2f, 0.8f, 0.55f, 0.4f, shirt.color)
        if (shirt.shape == 1) p(-0.41f, 0.95f, -0.21f, 0.82f, 0.1f, 0.42f, WHITE)
        if (shirt.shape == 2) p(-0.15f, 0.85f, 0.2f, 0.3f, 0.3f, 0.02f, 0xFFFFD54F.toInt())

        // แขน
        val skinH = when (shirt.shape) { 3 -> 0.3f; 4 -> 0.55f; else -> 0.14f }
        fun arm(lx: Float, az: Float) {
            p(lx, 0.7f, az, 0.3f, skinH, 0.3f, skin)
            if (skinH < 0.55f) p(lx, 0.7f + skinH, az, 0.3f, 0.55f - skinH, 0.3f, shirt.color)
        }
        arm(-0.7f, -0.15f - sw)
        arm(0.4f, -0.15f + sw)

        // หัว + หน้า
        p(-0.275f, 1.25f, -0.275f, 0.55f, 0.55f, 0.55f, skin)
        drawFace(face.shape, ::p)

        drawHat(hat, ::p)
        drawBack(back, ::p)
    }

    private fun drawFace(shape: Int, p: (Float, Float, Float, Float, Float, Float, Int) -> Unit) {
        val z = 0.275f
        val eyes = { col: Int ->
            p(-0.17f, 1.52f, z, 0.1f, 0.1f, 0.02f, col)
            p(0.07f, 1.52f, z, 0.1f, 0.1f, 0.02f, col)
        }
        val smile = {
            p(-0.12f, 1.36f, z, 0.24f, 0.05f, 0.02f, BLACK)
        }
        when (shape) {
            0 -> { eyes(BLACK); smile() }
            1 -> { p(-0.27f, 1.5f, z, 0.54f, 0.13f, 0.03f, BLACK); smile() }
            2 -> {
                eyes(0xFFD50000.toInt())
                p(-0.2f, 1.64f, z, 0.16f, 0.04f, 0.02f, BLACK)
                p(0.04f, 1.64f, z, 0.16f, 0.04f, 0.02f, BLACK)
                p(-0.12f, 1.34f, z, 0.24f, 0.04f, 0.02f, BLACK)
            }
            3 -> {
                p(-0.12f, 1.46f, z, 0.24f, 0.24f, 0.02f, WHITE)
                p(-0.05f, 1.53f, z + 0.01f, 0.1f, 0.1f, 0.02f, BLACK)
                smile()
            }
            4 -> { eyes(BLACK); p(-0.2f, 1.4f, z, 0.4f, 0.07f, 0.03f, 0xFF4E342E.toInt()) }
            5 -> {
                eyes(BLACK); smile()
                p(-0.25f, 1.4f, z, 0.1f, 0.08f, 0.02f, 0xFFFF8A80.toInt())
                p(0.15f, 1.4f, z, 0.1f, 0.08f, 0.02f, 0xFFFF8A80.toInt())
            }
            6 -> { eyes(0xFFE91E63.toInt()); smile() }
            7 -> {
                p(-0.19f, 1.55f, z, 0.14f, 0.03f, 0.02f, BLACK)
                p(0.05f, 1.55f, z, 0.14f, 0.03f, 0.02f, BLACK)
                smile()
            }
        }
    }

    private fun drawHat(h: Item, p: (Float, Float, Float, Float, Float, Float, Int) -> Unit) {
        val col = h.color
        when (h.shape) {
            1 -> {
                p(-0.3f, 1.8f, -0.3f, 0.6f, 0.12f, 0.6f, col)
                p(-0.3f, 1.8f, 0.3f, 0.6f, 0.04f, 0.25f, col)
            }
            2 -> {
                p(-0.4f, 1.8f, -0.4f, 0.8f, 0.05f, 0.8f, col)
                p(-0.28f, 1.85f, -0.28f, 0.56f, 0.55f, 0.56f, col)
            }
            3 -> {
                p(-0.3f, 1.8f, -0.3f, 0.6f, 0.15f, 0.6f, col)
                p(-0.3f, 1.95f, -0.3f, 0.12f, 0.15f, 0.12f, col)
                p(0.18f, 1.95f, -0.3f, 0.12f, 0.15f, 0.12f, col)
                p(-0.3f, 1.95f, 0.18f, 0.12f, 0.15f, 0.12f, col)
                p(0.18f, 1.95f, 0.18f, 0.12f, 0.15f, 0.12f, col)
            }
            4 -> {
                p(-0.38f, 1.8f, -0.05f, 0.1f, 0.3f, 0.1f, col)
                p(0.28f, 1.8f, -0.05f, 0.1f, 0.3f, 0.1f, col)
                p(-0.42f, 2.05f, -0.05f, 0.08f, 0.15f, 0.1f, col)
                p(0.34f, 2.05f, -0.05f, 0.08f, 0.15f, 0.1f, col)
            }
            5 -> {
                p(-0.33f, 1.68f, -0.33f, 0.66f, 0.34f, 0.66f, col)
                p(-0.25f, 1.72f, 0.33f, 0.5f, 0.12f, 0.03f, 0xFF263238.toInt())
            }
            6 -> {
                p(-0.3f, 1.8f, -0.3f, 0.6f, 0.2f, 0.6f, col)
                p(-0.08f, 2.0f, -0.08f, 0.16f, 0.16f, 0.16f, WHITE)
            }
            7 -> {
                p(-0.3f, 1.8f, -0.3f, 0.6f, 0.2f, 0.6f, col)
                p(-0.2f, 2.0f, -0.2f, 0.4f, 0.2f, 0.4f, col)
                p(-0.1f, 2.2f, -0.1f, 0.2f, 0.2f, 0.2f, col)
            }
            8 -> {
                p(-0.3f, 2.1f, -0.3f, 0.6f, 0.05f, 0.08f, col)
                p(-0.3f, 2.1f, 0.22f, 0.6f, 0.05f, 0.08f, col)
                p(-0.3f, 2.1f, -0.3f, 0.08f, 0.05f, 0.6f, col)
                p(0.22f, 2.1f, -0.3f, 0.08f, 0.05f, 0.6f, col)
            }
            9 -> p(-0.34f, 1.8f, -0.34f, 0.68f, 0.35f, 0.68f, col)
            10 -> {
                p(-0.3f, 1.8f, -0.3f, 0.6f, 0.1f, 0.6f, col)
                p(-0.4f, 1.92f, -0.04f, 0.8f, 0.03f, 0.08f, 0xFFFF5252.toInt())
                p(-0.04f, 1.94f, -0.4f, 0.08f, 0.03f, 0.8f, 0xFFFFEB3B.toInt())
            }
        }
    }

    private fun drawBack(b: Item, p: (Float, Float, Float, Float, Float, Float, Int) -> Unit) {
        val col = b.color
        when (b.shape) {
            1 -> p(-0.3f, 0.75f, -0.45f, 0.6f, 0.5f, 0.25f, col)
            2 -> p(-0.4f, 0.3f, -0.27f, 0.8f, 0.95f, 0.06f, col)
            3 -> {
                p(-0.9f, 0.8f, -0.3f, 0.5f, 0.75f, 0.05f, col)
                p(0.4f, 0.8f, -0.3f, 0.5f, 0.75f, 0.05f, col)
            }
            5 -> {
                p(-0.05f, 0.7f, -0.3f, 0.1f, 0.9f, 0.06f, col)
                p(-0.15f, 1.15f, -0.3f, 0.3f, 0.06f, 0.06f, 0xFF6D4C41.toInt())
            }
            6 -> {
                p(-0.35f, 0.8f, -0.42f, 0.28f, 0.45f, 0.22f, col)
                p(0.07f, 0.8f, -0.42f, 0.28f, 0.45f, 0.22f, col)
                p(-0.3f, 0.65f, -0.37f, 0.18f, 0.15f, 0.12f, 0xFFFF9800.toInt())
                p(0.12f, 0.65f, -0.37f, 0.18f, 0.15f, 0.12f, 0xFFFF9800.toInt())
            }
        }
    }
}
