package com.offlineblox.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class RoomsActivity : Activity() {
    private var discovery: Discovery? = null
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(this)

        val root = Ui.row(this)
        root.setBackgroundColor(Ui.BG)
        val pad = Ui.dp(this, 24)
        root.setPadding(pad, pad, pad, pad)

        val left = Ui.col(this)
        left.addView(Ui.label(this, "ห้องใกล้ๆ", 28f, Ui.GREEN, true))
        status = Ui.label(this, "กำลังค้นหาห้องใน Wi-Fi/Hotspot เดียวกัน...", 13f, Ui.DIM)
        left.addView(status)
        left.addView(
            Ui.label(
                this,
                "ถ้าไม่เจอห้อง: ใส่ IP ของโฮสต์เอง (โฮสต์จะเห็น IP ตอนกดเปิดเซิร์ฟ) ถ้าต่อ Hotspot ของเพื่อน IP มักเป็น 192.168.43.1",
                12f, Ui.DIM
            ), Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 6, this)
        )

        val ipEdit = EditText(this)
        ipEdit.hint = "IP ของโฮสต์ เช่น 192.168.43.1"
        ipEdit.setTextColor(Ui.TEXT)
        ipEdit.setHintTextColor(Ui.DIM)
        ipEdit.setSingleLine(true)
        ipEdit.background = Ui.box(Ui.PANEL, 0x55FFFFFF, 2, this)
        ipEdit.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10))
        left.addView(ipEdit, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 6, this))

        left.addView(Ui.button(this, "เข้าด้วย IP นี้", Ui.BLUE) {
            val ip = ipEdit.text.toString().trim()
            if (ip.isNotEmpty()) pickMapThenJoin(ip)
        }, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        left.addView(Ui.button(this, "← กลับ", Ui.GRAY) { finish() },
            Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        root.addView(left, Ui.lp(0, Ui.MATCH, 1f, 0, this))

        list = Ui.col(this)
        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, Ui.lp(0, Ui.MATCH, 1f, 0, this))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        Ui.immersive(this)
        discovery = Discovery(this) { rooms -> runOnUiThread { show(rooms) } }.also { it.start() }
    }

    override fun onPause() {
        super.onPause()
        discovery?.stop()
        discovery = null
    }

    private fun show(rooms: List<Room>) {
        list.removeAllViews()
        if (rooms.isEmpty()) {
            status.text = "ยังไม่เจอห้อง... ให้เพื่อนกด \"เปิดเซิร์ฟ\" ในเกมก่อน"
            return
        }
        status.text = "เจอ ${rooms.size} ห้อง แตะเพื่อเข้า"
        for (r in rooms) {
            val card = Ui.col(this)
            card.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12))
            card.background = Ui.box(Ui.PANEL, 0x66FFFFFF, 2, this)
            card.addView(Ui.label(this, r.name.replace('_', ' '), 18f, Ui.TEXT, true))
            card.addView(
                Ui.label(
                    this,
                    "แมพ: ${Maps.byId(r.mapId).name} • โฮสต์: ${r.host.replace('_', ' ')} • ${r.players} คน",
                    13f, Ui.DIM
                )
            )
            card.addView(Ui.label(this, r.ip, 12f, Ui.DIM))
            card.setOnClickListener { join(r.ip, r.mapId) }
            list.addView(card, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 6, this))
        }
    }

    private fun pickMapThenJoin(ip: String) {
        val names = Maps.all.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("โฮสต์ใช้แมพไหน?")
            .setItems(names) { _, which -> join(ip, Maps.all[which].id) }
            .show()
    }

    private fun join(ip: String, mapId: String) {
        val name = getSharedPreferences("ob", MODE_PRIVATE).getString("name", "Player") ?: "Player"
        val i = Intent(this, GameActivity::class.java)
        i.putExtra("mode", "join")
        i.putExtra("map", mapId)
        i.putExtra("ip", ip)
        i.putExtra("name", name)
        startActivity(i)
    }
}
