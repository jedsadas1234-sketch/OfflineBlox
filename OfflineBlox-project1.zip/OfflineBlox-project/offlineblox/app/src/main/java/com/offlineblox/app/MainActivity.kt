package com.offlineblox

import android.app.Activity
import android.app.AlertDialog
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), GameView.Listener {
    private val net = Net()
    private lateinit var prefs: SharedPreferences
    private var avatar = Avatar()
    private var pname = "Player"
    private var game: GameView? = null
    private var curMap = 0
    private var screen = "home"
    private var cleanup: (() -> Unit)? = null
    private val ui = Handler(Looper.getMainLooper())
    private var mlock: WifiManager.MulticastLock? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("ob", MODE_PRIVATE)
        pname = prefs.getString("name", null) ?: ("Player" + (100..999).random()).also { prefs.edit().putString("name", it).apply() }
        avatar = Avatar.parse(prefs.getString("av", "") ?: "")
        L.th = prefs.getBoolean("th", java.util.Locale.getDefault().language == "th")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        net.onClosed = { ui.post { if (game != null) { toast(L.t("Disconnected from server", "หลุดจากเซิร์ฟเวอร์")); leave() } } }
        net.onWelcome = { mi -> ui.post { launch(mi, 2) } }
        net.onKicked = { ui.post { toast(L.t("Kicked: your name is already used in that room. Change your name and try again.", "โดนเตะ: ชื่อซ้ำกับคนในห้อง กรุณาเปลี่ยนชื่อแล้วเข้าใหม่")) } }
        showHome()
    }

    override fun onDestroy() { net.stop(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            game != null -> onMenu()
            screen != "home" -> showHome()
            else -> super.onBackPressed()
        }
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun save() { prefs.edit().putString("name", pname).putString("av", avatar.ser()).apply() }

    private fun bg(fill: Int, stroke: Int = 0, r: Int = 6, sw: Int = 1) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(sw), stroke)
    }

    private fun grad(top: Int, bot: Int, r: Int = 6, stroke: Int = 0) =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bot)).apply {
            cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun tv(t: String, sp: Float = 14f, col: Int = 0xFF222222.toInt(), bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(col); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun btn(t: String, green: Boolean = true, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER; setPadding(dp(16), dp(8), dp(16), dp(8))
        background = if (green) grad(0xFF5CB85C.toInt(), 0xFF2E8B2E.toInt(), 5, 0xFF1E6B1E.toInt())
        else grad(0xFF5B9BD5.toInt(), 0xFF1F5FA8.toInt(), 5, 0xFF144A85.toInt())
        setOnClickListener { onClick() }
    }

    private fun panel(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = bg(0xFFFFFFFF.toInt(), 0xFFAAAAAA.toInt(), 4)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        for (x in v) addView(x)
    }

    private fun lp(w: Int, h: Int, wt: Float = 0f, m: Int = 0) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(m), dp(m), dp(m), dp(m)) }

    private fun frame(tab: String, body: View) {
        cleanup?.invoke(); cleanup = null
        screen = tab
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFE6E6E6.toInt()) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(4), dp(12), dp(4))
            background = grad(0xFF3D8BD8.toInt(), 0xFF0E4E96.toInt(), 0, 0xFF08376B.toInt())
        }
        bar.addView(tv("OFFLINE", 22f, Color.WHITE, true).apply { setTypeface(typeface, Typeface.BOLD_ITALIC) })
        bar.addView(tv("BLOX", 22f, 0xFFFFA726.toInt(), true).apply { setTypeface(typeface, Typeface.BOLD_ITALIC) })
        bar.addView(View(this), lp(0, 1, 1f))
        for ((name, key, act) in listOf(
            Triple(L.t("Home", "หน้าแรก"), "home", { showHome() }),
            Triple(L.t("Games", "เกม"), "games", { showGames() }),
            Triple(L.t("Character", "ตัวละคร"), "char", { showChar() }),
            Triple(L.t("Servers", "เซิร์ฟเวอร์"), "servers", { showServers() })
        )) {
            bar.addView(tv(name, 14f, if (key == tab) 0xFF0E4E96.toInt() else Color.WHITE, true).apply {
                setPadding(dp(14), dp(6), dp(14), dp(6))
                if (key == tab) background = bg(Color.WHITE, 0, 4)
                setOnClickListener { act() }
            }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0f, 2))
        }
        bar.addView(tv(if (L.th) "EN" else "ไทย", 13f, 0xFFFFA726.toInt(), true).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6)); background = bg(0x33FFFFFF, 0, 4)
            setOnClickListener {
                L.th = !L.th
                prefs.edit().putBoolean("th", L.th).apply()
                when (tab) { "games" -> showGames(); "char" -> showChar(); "servers" -> showServers(); else -> showHome() }
            }
        }, lp(-2, -2, 0f, 2))
        root.addView(bar, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(body, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f, 8))
        game = null
        setContentView(root)
    }

    // ---------- screens ----------
    private fun showHome() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val et = EditText(this).apply {
            setText(pname); setSingleLine(); textSize = 16f
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val t = s.toString().replace("|", "").replace(",", "").trim().take(16)
                    pname = if (t.isEmpty()) "Player" else t
                    save()
                }
            })
        }
        val left = panel(
            tv(L.t("Welcome to OfflineBlox!", "ยินดีต้อนรับสู่ OfflineBlox!"), 20f, 0xFF0E4E96.toInt(), true),
            tv(L.t("Play with friends on the same Wi-Fi or hotspot. No account, no internet.", "เล่นกับเพื่อนผ่าน Wi-Fi หรือฮอตสปอตเดียวกัน ไม่ต้องสมัคร ไม่ต้องใช้เน็ต"), 13f),
            tv(L.t("Your name:", "ชื่อของคุณ:"), 13f, 0xFF555555.toInt(), true), et,
            btn(L.t("PLAY", "เล่นเลย")) { showGames() }.also { it.layoutParams = lp(-1, -2, 0f, 4) },
            btn(L.t("Find servers", "หาเซิร์ฟเวอร์"), false) { showServers() }.also { it.layoutParams = lp(-1, -2, 0f, 4) }
        )
        val prev = AvatarPreview(this) { avatar }
        val right = panel(
            tv(L.t("Your Character", "ตัวละครของคุณ"), 16f, 0xFF0E4E96.toInt(), true),
            btn(L.t("Customize", "แต่งตัว"), false) { showChar() }
        )
        right.addView(prev, 1, lp(-1, 0, 1f, 4))
        row.addView(left, lp(0, -1, 1.4f, 4))
        row.addView(right, lp(0, -1, 1f, 4))
        frame("home", row)
    }

    private fun showGames() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, m) in Maps.all.withIndex()) {
            val thumb = View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(m.skyTop, m.skyBot, m.floorColor)).apply { cornerRadius = dp(4).toFloat() }
            }
            val card = panel(
                thumb.also { it.layoutParams = lp(-1, dp(90), 0f, 0) },
                tv(L.mapName(m.name), 17f, 0xFF0E4E96.toInt(), true),
                tv(L.mapDesc(m.name), 12f),
                LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    addView(btn(L.t("Play", "เล่น")) { launch(i, 0) }, lp(0, -2, 1f, 2))
                    addView(btn(L.t("Host", "เปิดห้อง"), false) { launch(i, 1) }, lp(0, -2, 1f, 2))
                }
            )
            row.addView(card, lp(0, -2, 1f, 6))
        }
        frame("games", HorizontalScrollView(this).apply { addView(row) })
    }

    private class Cat(val name: String, val n: Int, val labels: List<String>?, val colors: IntArray?, val get: () -> Int, val set: (Int) -> Unit)

    private fun showChar() {
        val cats = listOf(
            Cat(L.t("Skin", "สีผิว"), Pal.skin.size, null, Pal.skin, { avatar.skin }, { avatar.skin = it }),
            Cat(L.t("Hair", "ทรงผม"), Pal.hairStyles.size, L.list(Pal.hairStyles, L.hairTh), null, { avatar.hair }, { avatar.hair = it }),
            Cat(L.t("Hair color", "สีผม"), Pal.col.size, null, Pal.col, { avatar.hairC }, { avatar.hairC = it }),
            Cat(L.t("Shirt", "เสื้อ"), Pal.col.size, null, Pal.col, { avatar.shirt }, { avatar.shirt = it }),
            Cat(L.t("Shirt design", "ลายเสื้อ"), Pal.designs.size, L.list(Pal.designs, L.designsTh), null, { avatar.design }, { avatar.design = it }),
            Cat(L.t("Pants", "กางเกง"), Pal.col.size, null, Pal.col, { avatar.pants }, { avatar.pants = it }),
            Cat(L.t("Shoes", "รองเท้า"), Pal.col.size, null, Pal.col, { avatar.shoes }, { avatar.shoes = it }),
            Cat(L.t("Hats", "หมวก"), Pal.hats.size, L.list(Pal.hats, L.hatsTh), null, { avatar.hat }, { avatar.hat = it }),
            Cat(L.t("Faces", "หน้า"), Pal.faces.size, L.list(Pal.faces, L.facesTh), null, { avatar.face }, { avatar.face = it }),
            Cat(L.t("Back", "ของสะพายหลัง"), Pal.backs.size, L.list(Pal.backs, L.backsTh), null, { avatar.back }, { avatar.back = it })
        )
        var sel = 0
        val prev = AvatarPreview(this) { avatar }
        val grid = GridLayout(this).apply { columnCount = 5 }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        lateinit var render: () -> Unit
        render = {
            tabs.removeAllViews()
            for ((i, c) in cats.withIndex()) {
                tabs.addView(tv(c.name, 13f, if (i == sel) Color.WHITE else 0xFF0E4E96.toInt(), true).apply {
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    background = if (i == sel) bg(0xFF1F5FA8.toInt(), 0, 4) else bg(0xFFDDEBFA.toInt(), 0, 4)
                    setOnClickListener { sel = i; render() }
                }, lp(-2, -2, 0f, 2))
            }
            grid.removeAllViews()
            val c = cats[sel]
            for (i in 0 until c.n) {
                val on = c.get() == i
                val v: View = if (c.colors != null) {
                    View(this).apply { background = bg(c.colors[i], if (on) 0xFFFF8F00.toInt() else 0x55000000, 6, if (on) 3 else 1) }
                } else {
                    tv(c.labels!![i], 13f, 0xFF222222.toInt(), true).apply {
                        gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(8), dp(4))
                        background = bg(0xFFF2F2F2.toInt(), if (on) 0xFFFF8F00.toInt() else 0x55000000, 6, if (on) 3 else 1)
                    }
                }
                v.setOnClickListener { c.set(i); save(); prev.invalidate(); render() }
                val p = GridLayout.LayoutParams().apply {
                    width = if (c.colors != null) dp(44) else dp(100)
                    height = if (c.colors != null) dp(44) else dp(40)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                grid.addView(v, p)
            }
        }
        render()
        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(HorizontalScrollView(this@MainActivity).apply { addView(tabs) }, lp(-1, -2))
            addView(ScrollView(this@MainActivity).apply { addView(grid) }, lp(-1, 0, 1f, 2))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(panel().also { it.addView(prev, lp(-1, -1, 1f)) }, lp(dp(230), -1, 0f, 4))
        row.addView(panel().also { it.addView(right, lp(-1, -1, 1f)) }, lp(0, -1, 1f, 4))
        frame("char", row)
    }

    private fun showServers() {
        cleanup?.invoke(); cleanup = null
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tick = object : Runnable {
            override fun run() {
                list.removeAllViews()
                val now = SystemClock.elapsedRealtime()
                val live = net.servers.values.filter { now - it.seen < 8000 }
                if (live.isEmpty()) list.addView(tv(L.t("Searching for servers on this Wi-Fi / hotspot...", "กำลังค้นหาห้องในเครือข่ายนี้..."), 14f, 0xFF777777.toInt()))
                for (s in live) {
                    val r = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                        background = bg(0xFFF2F8FF.toInt(), 0xFF9BBFE6.toInt(), 4); setPadding(dp(10), dp(6), dp(10), dp(6))
                    }
                    r.addView(tv("${s.name}  •  ${L.mapName(s.map)}  •  ${s.players} ${L.t("player(s)", "คน")}", 14f, 0xFF222222.toInt(), true), lp(0, -2, 1f))
                    r.addView(btn(L.t("Join", "เข้าร่วม")) { joinServer(s.ip) })
                    list.addView(r, lp(-1, -2, 0f, 3))
                }
                ui.postDelayed(this, 1000)
            }
        }
        net.startDiscovery()
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            mlock = wm.createMulticastLock("ob").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
        ui.post(tick)
        val ip = EditText(this).apply { hint = L.t("Server IP (e.g. 192.168.43.1)", "IP เซิร์ฟ (เช่น 192.168.43.1)"); setSingleLine() }
        val manual = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(ip, lp(0, -2, 1f))
            addView(btn(L.t("Join by IP", "เข้าด้วย IP"), false) { val t = ip.text.toString().trim(); if (t.isNotEmpty()) joinServer(t) })
        }
        val body = panel(
            tv(L.t("Servers on your network", "ห้องในเครือข่ายของคุณ"), 18f, 0xFF0E4E96.toInt(), true),
            tv(L.t("Open a map -> Menu -> Host server. Friends on the same hotspot/Wi-Fi will see it here.", "เข้าแมพ > เมนู > เปิดเซิร์ฟเวอร์ เพื่อนในฮอตสปอต/Wi-Fi เดียวกันจะเห็นห้องตรงนี้"), 12f),
            ScrollView(this).apply { addView(list) }.also { it.layoutParams = lp(-1, 0, 1f, 4) },
            manual
        )
        frame("servers", body)
        cleanup = { ui.removeCallbacks(tick); net.stopDiscovery(); try { mlock?.release() } catch (_: Exception) {} }
    }

    // ---------- game flow ----------
    private fun joinServer(ip: String) {
        net.stop()
        net.me = Remote(0, pname, avatar)
        toast(L.t("Connecting to $ip ...", "กำลังเชื่อมต่อ $ip ..."))
        Thread {
            val ok = net.join(ip)
            if (!ok) ui.post { toast(net.status) }
        }.start()
    }

    private fun launch(mi: Int, mode: Int) {
        cleanup?.invoke(); cleanup = null
        curMap = mi
        if (mode != 2) net.stop()
        net.me = Remote(0, pname, avatar)
        val gv = GameView(this, net, Maps.all[mi], avatar)
        gv.listener = this
        setContentView(gv)
        game = gv
        screen = "game"
        if (mode == 1) hostNow()
    }

    private fun hostNow() {
        if (net.startHost(curMap, Maps.all[curMap].name)) toast(L.t("Server on! IP: ", "เปิดเซิร์ฟแล้ว! IP: ") + net.localIps()) else toast(net.status)
    }

    private fun leave() { cleanup?.invoke(); cleanup = null; net.stop(); game = null; showHome() }

    override fun onMenu() {
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        items.add(L.t("Resume", "เล่นต่อ")); acts.add { }
        if (net.role == 0) {
            items.add(L.t("Host server (Wi-Fi / hotspot)", "เปิดเซิร์ฟเวอร์ (Wi-Fi / ฮอตสปอต)")); acts.add { hostNow() }
        } else if (net.role == 1) {
            items.add(L.t("Stop server", "ปิดเซิร์ฟเวอร์")); acts.add { net.stop(); toast(L.t("Server stopped", "ปิดเซิร์ฟเวอร์แล้ว")) }
        }
        items.add(L.t("Respawn", "เกิดใหม่")); acts.add { game?.respawn() }
        items.add(L.t("Leave game", "ออกจากเกม")); acts.add { leave() }
        AlertDialog.Builder(this).setTitle("OfflineBlox").setItems(items.toTypedArray()) { _, i -> acts[i]() }.show()
    }

    override fun onChat() {
        val et = EditText(this).apply { setSingleLine() }
        AlertDialog.Builder(this).setTitle(L.t("Chat", "แชท")).setView(et)
            .setPositiveButton(L.t("Send", "ส่ง")) { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) net.sendChat(t)
            }.setNegativeButton(L.t("Cancel", "ยกเลิก"), null).show()
    }
}
