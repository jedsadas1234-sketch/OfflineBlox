package com.offlineblox.app

import android.opengl.GLES20
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/** วาดกล่อง 3D สีล้วนด้วย OpenGL ES 2.0 */
object Gfx {
    private var prog = 0
    private var aPos = 0
    private var aNor = 0
    private var uMvp = 0
    private var uRot = 0
    private var uColor = 0
    private lateinit var buf: FloatBuffer

    val IDENT = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val tmp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    private const val VS = """
        attribute vec3 aPos;
        attribute vec3 aNor;
        uniform mat4 uMvp;
        uniform mat4 uRot;
        varying float vL;
        void main() {
            vec3 n = normalize((uRot * vec4(aNor, 0.0)).xyz);
            vL = 0.55 + 0.45 * max(dot(n, normalize(vec3(0.4, 0.9, 0.3))), 0.0);
            gl_Position = uMvp * vec4(aPos, 1.0);
        }
    """
    private const val FS = """
        precision mediump float;
        uniform vec4 uColor;
        varying float vL;
        void main() {
            gl_FragColor = vec4(uColor.rgb * vL, 1.0);
        }
    """

    // แต่ละหน้า: normal(3) + มุม 4 จุด (12)
    private val FACES = arrayOf(
        floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 0f, 1f, 1f, 1f, 1f, 0f, 1f, 1f),
        floatArrayOf(0f, 0f, -1f, 1f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 1f, 1f, 0f),
        floatArrayOf(1f, 0f, 0f, 1f, 0f, 1f, 1f, 0f, 0f, 1f, 1f, 0f, 1f, 1f, 1f),
        floatArrayOf(-1f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f, 0f),
        floatArrayOf(0f, 1f, 0f, 0f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 0f, 0f, 1f, 0f),
        floatArrayOf(0f, -1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 1f, 0f, 0f, 1f)
    )

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    /** เรียกทุกครั้งที่ GL surface ถูกสร้างใหม่ */
    fun init() {
        val vs = shader(GLES20.GL_VERTEX_SHADER, VS)
        val fs = shader(GLES20.GL_FRAGMENT_SHADER, FS)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aNor = GLES20.glGetAttribLocation(prog, "aNor")
        uMvp = GLES20.glGetUniformLocation(prog, "uMvp")
        uRot = GLES20.glGetUniformLocation(prog, "uRot")
        uColor = GLES20.glGetUniformLocation(prog, "uColor")

        val data = ArrayList<Float>()
        for (f in FACES) {
            val n = floatArrayOf(f[0], f[1], f[2])
            val idx = intArrayOf(0, 1, 2, 0, 2, 3)
            for (i in idx) {
                data.add(f[3 + i * 3]); data.add(f[4 + i * 3]); data.add(f[5 + i * 3])
                data.add(n[0]); data.add(n[1]); data.add(n[2])
            }
        }
        buf = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (v in data) buf.put(v)
        buf.position(0)
    }

    fun begin() {
        GLES20.glUseProgram(prog)
        buf.position(0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, buf)
        GLES20.glEnableVertexAttribArray(aPos)
        buf.position(3)
        GLES20.glVertexAttribPointer(aNor, 3, GLES20.GL_FLOAT, false, 24, buf)
        GLES20.glEnableVertexAttribArray(aNor)
    }

    /** วาดกล่องโลคอล lx,ly,lz (มุมต่ำสุด) ขนาด w,h,d ภายใต้เมทริกซ์ base */
    fun draw(
        vp: FloatArray, base: FloatArray, rot: FloatArray,
        lx: Float, ly: Float, lz: Float, w: Float, h: Float, d: Float, color: Int
    ) {
        Matrix.setIdentityM(tmp, 0)
        Matrix.translateM(tmp, 0, lx, ly, lz)
        Matrix.scaleM(tmp, 0, w, h, d)
        Matrix.multiplyMM(model, 0, base, 0, tmp, 0)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uRot, 1, false, rot, 0)
        GLES20.glUniform4f(
            uColor,
            ((color shr 16) and 255) / 255f,
            ((color shr 8) and 255) / 255f,
            (color and 255) / 255f,
            1f
        )
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    fun block(vp: FloatArray, b: Block) =
        draw(vp, IDENT, IDENT, b.x, b.y, b.z, b.w, b.h, b.d, b.color)
}
