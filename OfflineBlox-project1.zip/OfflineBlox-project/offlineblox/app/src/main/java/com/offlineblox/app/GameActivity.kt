package com.offlineblox.app

import android.app.Activity
import android.app.AlertDialog
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections
import kotlin.math.max
import kotlin.math.min

class GameActivity : Activity(), NetListener {
    private lateinit var game: Game
    private lateinit var glView: GLSurfaceView
    private lateinit var tagView: NameTagView
    private lateinit var chatLog: TextView
    private lateinit var statusView: TextView
    private var serverBtn: Button? = null
    private var host: NetHost? = null
    private var client: NetClient? = null
    private val chatLines = ArrayList<String>()
    private var sendAcc = 0f
    private var lastX = 0f
    private var lastY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.immersive(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val name = intent.getStringExtra("name") ?: "Player"
        val mapId = intent.getStringExtra("map") ?: "grass"
        val mode = intent.getStringExtra("mode") ?: "solo"
        val ip = intent.getStringExtra("ip")

        game = Game(Maps.byId(mapId), name, AvatarState.load(this))

        val root = FrameLayout(this)

        glView = GLSurfaceView(this)
        glView.setEGLContextClientVersion(2)
        glView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        val renderer = GameRenderer(game)
        tagView = NameTagView(this)
        renderer.onTick = { dt -> tick(dt) }
        renderer.onTags = { tags -> tagView.setTags(tags) }
        glView.setRenderer(renderer)
        glView.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastX = e.x; lastY = e.y }
                MotionEvent.ACTION_MOVE -> {
                    game.camYaw -= (e.x - lastX) * 0.006f
                    game.camPitch = max(0.05f, min(1.3f, game.camPitch + (e.y - lastY) * 0.004f))
                    lastX = e.x; lastY = e.y
                }
            }
            true
        }
        root.addView(glView, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        root.addView(tagView, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))

        // จอยสติ๊ก
        val joy = Joystick(this) { x, y -> game.joyX = x; game.joyY = y }
        val jlp = FrameLayout.LayoutParams(Ui.dp(this, 170), Ui.dp(this, 170),
            Gravity.BOTTOM or Gravity.START)
        jlp.setMargins(Ui.dp(this, 28), 0, 0, Ui.dp(this, 24))
        root.addView(joy, jlp)

        // ปุ่มกระโดด
        val jump = Button(this)
        jump.text = "⬆"
        jump.textSize = 26f
        jump.setTextColor(0xFFFFFFFF.toInt())
        jump.background = Ui.box(0x99000000.toInt(), 0xCCFFFFFF.toInt(), 3, this)
        jump.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) game.jumpReq = true
            true
        }
        val blp = FrameLayout.LayoutParams(Ui.dp(this, 96), Ui.dp(this, 96),
            Gravity.BOTTOM or Gravity.END)
        blp.setMargins(0, 0, Ui.dp(this, 40), Ui.dp(this, 36))
        root.addView(jump, blp)

        // มุมซ้ายบน: สถานะ + ปุ่มเซิร์ฟ + แชทล็อก
        val topLeft = Ui.col(this)
        statusView = Ui.label(this, "", 12f, Ui.TEXT)
        statusView.setShadowLayer(4f, 0f, 0f, 0xFF000000.toInt())
        topLeft.addView(statusView)
        if (mode == "solo") {
            val sb = Ui.button(this, "🌐 เปิดเซิร์ฟ", Ui.GREEN) { toggleServer() }
            sb.textSize = 13f
            serverBtn = sb
            topLeft.addView(sb, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 2, this))
        }
        chatLog = Ui.label(this, "", 13f, Ui.TEXT)
        chatLog.setShadowLayer(4f, 0f, 0f, 0xFF000000.toInt())
        topLeft.addView(chatLog)
        val tlp = FrameLayout.LayoutParams(Ui.dp(this, 320), Ui.WRAP, Gravity.TOP or Gravity.START)
        tlp.setMargins(Ui.dp(this, 12), Ui.dp(this, 8), 0, 0)
        root.addView(topLeft, tlp)

        // มุมขวาบน: แชท + ออก
        val topRight = Ui.row(this)
        val chatBtn = Ui.button(this, "💬 แชท", Ui.BLUE) { chatDialog() }
        chatBtn.textSize = 13f
        val exitBtn = Ui.button(this, "ออก", Ui.RED) { finish() }
        exitBtn.textSize = 13f
        topRight.addView(chatBtn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 2, this))
        topRight.addView(exitBtn, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, 2, this))
        val trlp = FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.TOP or Gravity.END)
        trlp.setMargins(0, Ui.dp(this, 8), Ui.dp(this, 12), 0)
        root.addView(topRight, trlp)

        setContentView(root)

        if (mode == "join" && ip != null) {
            setStatus("กำลังเชื่อมต่อ $ip ...")
            val c = NetClient(ip, name, game.myAvatar.encode(), mapId, this)
            client = c
            c.start()
        } else {
            setStatus("เล่นคนเดียว • กด \"เปิดเซิร์ฟ\" ให้เพื่อนใน Wi-Fi/Hotspot เดียวกันเข้ามา")
        }
    }

    // ---- เรียกจาก GL thread ทุกเฟรม ----
    private fun tick(dt: Float) {
        sendAcc += dt
        if (sendAcc >= 0.05f) {
            sendAcc = 0f
            host?.sendState(game.x, game.y, game.z, game.yaw, game.moving)
            client?.sendState(game.x, game.y, game.z, game.yaw, game.moving)
        }
    }

    private fun toggleServer() {
        val btn = serverBtn ?: return
        val h = host
        if (h == null) {
            val nh = NetHost("ห้องของ ${game.myName}", game.map.id, game.myName,
                game.myAvatar.encode(), this)
            host = nh
            nh.start()
            btn.text = "⏹ ปิดเซิร์ฟ"
            btn.background = Ui.box(Ui.RED, 0x66FFFFFF, 2, this)
            setStatus("เปิดเซิร์ฟแล้ว • IP ของเครื่องนี้: ${localIps()}")
        } else {
            h.stop()
            host = null
            game.remotes.clear()
            btn.text = "🌐 เปิดเซิร์ฟ"
            btn.background = Ui.box(Ui.GREEN, 0x66FFFFFF, 2, this)
            setStatus("ปิดเซิร์ฟแล้ว")
        }
    }

    private fun localIps(): String {
        val out = ArrayList<String>()
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && !a.isLoopbackAddress) out.add(a.hostAddress ?: "")
                }
            }
        } catch (e: Exception) { }
        return if (out.isEmpty()) "ไม่พบ (เปิด Wi-Fi หรือ Hotspot ก่อน)" else out.joinToString(", ")
    }

    private fun chatDialog() {
        val et = EditText(this)
        et.setSingleLine(true)
        AlertDialog.Builder(this)
            .setTitle("พิมพ์แชท")
            .setView(et)
            .setPositiveButton("ส่ง") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    Thread {
                        val h = host
                        val c = client
                        if (h != null) h.sendChat(t)
                        else if (c != null) c.sendChat(t)
                        else addChat("${game.myName}: $t")
                    }.start()
                }
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun setStatus(s: String) {
        runOnUiThread { statusView.text = s }
    }

    private fun addChat(line: String) {
        synchronized(chatLines) {
            chatLines.add(line)
            while (chatLines.size > 6) chatLines.removeAt(0)
        }
        val text = synchronized(chatLines) { chatLines.joinToString("\n") }
        runOnUiThread { chatLog.text = text }
    }

    private fun nameOf(id: Int): String {
        if (host != null && id == 0) return game.myName
        val c = client
        if (c != null && id == c.myId) return game.myName
        return game.remotes[id]?.name?.replace('_', ' ') ?: "?"
    }

    // ---- NetListener (เรียกจาก thread เครือข่าย) ----
    override fun onJoin(id: Int, name: String, avatar: String) {
        val r = Remote(id, avatar)
        r.name = name
        game.remotes[id] = r
        addChat("• ${name.replace('_', ' ')} เข้ามาแล้ว")
        host?.let { setStatus("เซิร์ฟเปิดอยู่ • ผู้เล่น ${it.playerCount()} คน • IP: ${localIps()}") }
    }

    override fun onState(id: Int, x: Float, y: Float, z: Float, yaw: Float, moving: Boolean) {
        val r = game.remotes[id] ?: return
        r.tx = x; r.ty = y; r.tz = z; r.tyaw = yaw; r.moving = moving
    }

    override fun onLeave(id: Int) {
        val r = game.remotes.remove(id) ?: return
        addChat("• ${r.name.replace('_', ' ')} ออกไปแล้ว")
        host?.let { setStatus("เซิร์ฟเปิดอยู่ • ผู้เล่น ${it.playerCount()} คน • IP: ${localIps()}") }
    }

    override fun onChat(id: Int, text: String) {
        addChat("${nameOf(id)}: $text")
    }

    override fun onStatus(msg: String) {
        setStatus(msg)
    }

    // ---- lifecycle ----
    override fun onResume() {
        super.onResume()
        Ui.immersive(this)
        glView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        host?.stop()
        client?.stop()
    }
}
