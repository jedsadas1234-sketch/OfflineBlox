package com.offlineblox

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.opengl.GLES30
import android.opengl.GLUtils
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random

/** Small OpenGL ES 3.0 helper: one cube mesh, lit+textured+shadowed shader. */
class Gfx : Painter {
    companion object {
        const val SHADOW = 1024
        const val RT_MAX = 128
        private const val TAG = "OfflineBlox"

        private const val VS = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;
layout(location = 3) in float aFace;
uniform mat4 uVP;
uniform mat4 uLightVP;
uniform mat4 uModel;
uniform vec3 uScale;
uniform vec4 uFace[6];
out vec3 vN;
out vec2 vUV;
out vec4 vShadow;
out vec3 vWorld;
out float vDist;
void main() {
  vec4 wp = uModel * vec4(aPos * uScale, 1.0);
  vWorld = wp.xyz;
  vN = normalize(mat3(uModel) * aNormal);
  vec4 r = uFace[int(aFace + 0.5)];
  vUV = r.xy + aUV * r.zw;
  vShadow = uLightVP * wp;
  gl_Position = uVP * wp;
  vDist = gl_Position.w;
}
"""

        private const val FS = """#version 300 es
precision highp float;
precision highp sampler2DShadow;
in vec3 vN;
in vec2 vUV;
in vec4 vShadow;
in vec3 vWorld;
in float vDist;
uniform sampler2D uTex;
uniform sampler2DShadow uShadowMap;
uniform vec4 uColor;
uniform vec3 uLightDir;
uniform vec3 uFog;
uniform vec2 uFogRange;
uniform int uMode;
uniform float uShadowOn;
uniform float uTexel;
out vec4 fragColor;
//RT_DECL
void main() {
  vec3 n = normalize(vN);
  vec2 uv = vUV;
  if (uMode == 1) {
    vec3 an = abs(n);
    vec2 w;
    if (an.z > 0.5) { w = vWorld.xy; } else if (an.x > 0.5) { w = vWorld.yz; } else { w = vWorld.xz; }
    uv = w / 4.0;
  }
  vec4 tex = texture(uTex, uv);
  vec3 base = tex.rgb * uColor.rgb;
  float ndl = max(dot(n, uLightDir), 0.0);
  float sh = 1.0;
  float ao = 1.0;
  if (uShadowOn > 0.5) {
    vec3 sc = vShadow.xyz / vShadow.w * 0.5 + 0.5;
    if (sc.x > 0.0 && sc.x < 1.0 && sc.y > 0.0 && sc.y < 1.0 && sc.z < 1.0) {
      float sum = 0.0;
      for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
          sum += texture(uShadowMap, vec3(sc.xy + vec2(float(i), float(j)) * uTexel, sc.z - 0.003));
        }
      }
      sh = sum / 9.0;
    }
  }
  //RT_SHADE
  float hemi = 0.5 + 0.5 * n.z;
  float light = (0.36 + 0.14 * hemi) * ao + 0.62 * ndl * sh;
  vec3 col = base * light;
  //RT_POST
  float fog = clamp((vDist - uFogRange.x) / (uFogRange.y - uFogRange.x), 0.0, 1.0);
  col = mix(col, uFog, fog);
  fragColor = vec4(col, 1.0);
}
"""

        private const val SVS = """#version 300 es
layout(location = 0) in vec3 aPos;
uniform mat4 uLightVP;
uniform mat4 uModel;
uniform vec3 uScale;
void main() {
  gl_Position = uLightVP * (uModel * vec4(aPos * uScale, 1.0));
}
"""

        private const val SFS = """#version 300 es
precision mediump float;
void main() {
}
"""

        private const val RT_DECL = """uniform highp sampler2D uBoxes;
uniform int uBoxCount;
uniform float uRT;
uniform vec3 uCam;
uniform vec3 uFloorCol;
float rtHit(vec3 ro, vec3 rd, int i, out vec3 nrm) {
  vec3 bmin = texelFetch(uBoxes, ivec2(0, i), 0).xyz;
  vec3 bmax = texelFetch(uBoxes, ivec2(1, i), 0).xyz;
  vec3 d = mix(rd, vec3(1e-5), lessThan(abs(rd), vec3(1e-5)));
  vec3 inv = 1.0 / d;
  vec3 t0 = (bmin - ro) * inv;
  vec3 t1 = (bmax - ro) * inv;
  vec3 tmn = min(t0, t1);
  vec3 tmx = max(t0, t1);
  float tn = max(max(tmn.x, tmn.y), tmn.z);
  float tf = min(min(tmx.x, tmx.y), tmx.z);
  nrm = vec3(0.0, 0.0, 1.0);
  if (tn > tf || tn < 0.01) { return -1.0; }
  if (tn == tmn.x) { nrm = vec3(-sign(d.x), 0.0, 0.0); }
  else if (tn == tmn.y) { nrm = vec3(0.0, -sign(d.y), 0.0); }
  else { nrm = vec3(0.0, 0.0, -sign(d.z)); }
  return tn;
}
bool rtOcc(vec3 ro, vec3 rd, float maxT) {
  vec3 nn;
  for (int i = 0; i < 128; i++) {
    if (i >= uBoxCount) { break; }
    float t = rtHit(ro, rd, i, nn);
    if (t > 0.0 && t < maxT) { return true; }
  }
  return false;
}
vec3 rtRefl(vec3 ro, vec3 rd) {
  float best = 1e9;
  vec3 bn = vec3(0.0, 0.0, 1.0);
  vec3 bc = vec3(0.0);
  vec3 nn;
  for (int i = 0; i < 128; i++) {
    if (i >= uBoxCount) { break; }
    float t = rtHit(ro, rd, i, nn);
    if (t > 0.0 && t < best) { best = t; bn = nn; bc = texelFetch(uBoxes, ivec2(2, i), 0).rgb; }
  }
  if (rd.z < -0.001 && ro.z > 0.0) {
    float tp = -ro.z / rd.z;
    if (tp < best) { best = tp; bn = vec3(0.0, 0.0, 1.0); bc = uFloorCol; }
  }
  if (best < 1e8) {
    float dl = max(dot(bn, uLightDir), 0.0);
    return bc * (0.4 + 0.6 * dl);
  }
  return mix(uFog, vec3(0.35, 0.55, 0.95), clamp(rd.z * 1.5, 0.0, 1.0));
}
"""
        private const val RT_SHADE = """if (uRT > 0.5) {
    float h0 = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
    vec3 po = vWorld + n * 0.03;
    float vis = 0.0;
    if (ndl > 0.0) {
      for (int k = 0; k < 3; k++) {
        vec3 j = vec3(h0, fract(h0 * 7.13 + float(k) * 0.37), fract(h0 * 3.71 + float(k) * 0.73)) - 0.5;
        vec3 rd = normalize(uLightDir + j * 0.07);
        vis += rtOcc(po, rd, 400.0) ? 0.0 : 1.0;
      }
      vis = vis / 3.0;
    }
    sh = vis;
    float occ = 0.0;
    for (int k = 0; k < 2; k++) {
      vec3 j = vec3(fract(h0 * 5.31 + float(k) * 0.61), fract(h0 * 9.17 + float(k) * 0.29), fract(h0 * 2.73 + float(k) * 0.83)) - 0.5;
      vec3 rd = normalize(n + j * 1.4);
      if (dot(rd, n) < 0.05) { rd = normalize(rd + n * 0.8); }
      occ += rtOcc(po, rd, 3.5) ? 1.0 : 0.0;
    }
    ao = 1.0 - 0.45 * occ / 2.0;
  }
"""
        private const val RT_POST = """if (uRT > 0.5 && uMode == 1) {
    vec3 V = normalize(uCam - vWorld);
    float fr = 0.04 + 0.96 * pow(1.0 - max(dot(n, V), 0.0), 5.0);
    float kk = mix(0.07, 0.6, fr);
    vec3 rdr = reflect(-V, n);
    vec3 rc = rtRefl(vWorld + n * 0.03, rdr);
    col = mix(col, rc, kk);
  }
"""
        private val FS_RT = FS.replace("//RT_DECL", RT_DECL).replace("//RT_SHADE", RT_SHADE).replace("//RT_POST", RT_POST)
    }

    var ok = false
    var rtOk = false
    var rtError = ""
    var error = ""
    override var mode = 0
    var shadowPass = false
    var shadowOk = false
    var shadowFbo = 0
    var worldTex = 0
    private var shadowTex = 0
    private var prog = 0
    private var sprog = 0
    private var vao = 0

    private var uVP = 0; private var uLightVP = 0; private var uModel = 0; private var uScale = 0
    private var uFace = 0; private var uTex = 0; private var uShadowMap = 0; private var uColor = 0
    private var uLightDir = 0; private var uFog = 0; private var uFogRange = 0; private var uMode = 0
    private var uShadowOn = 0; private var uTexel = 0
    private var sLVP = 0; private var sModel = 0; private var sScale = 0
    private var rtProg = 0; private var active = 0; private var rtTex = 0
    private var uBoxes = 0; private var uBoxCount = 0; private var uRT = 0; private var uCam = 0; private var uFloorCol = 0

    private fun u(p: Int, n: String) = GLES30.glGetUniformLocation(p, n)

    fun init() {
        prog = link(VS, FS)
        sprog = link(SVS, SFS)
        if (prog == 0 || sprog == 0) { ok = false; return }
        active = prog
        bindLocs(prog)
        sLVP = u(sprog, "uLightVP"); sModel = u(sprog, "uModel"); sScale = u(sprog, "uScale")
        buildMesh()
        worldTex = makeTexture(makeWorldBitmap(), true, true)
        initShadow()
        ok = true
        initRT()
    }

    private fun bindLocs(p: Int) {
        uVP = u(p, "uVP"); uLightVP = u(p, "uLightVP"); uModel = u(p, "uModel"); uScale = u(p, "uScale")
        uFace = u(p, "uFace"); uTex = u(p, "uTex"); uShadowMap = u(p, "uShadowMap"); uColor = u(p, "uColor")
        uLightDir = u(p, "uLightDir"); uFog = u(p, "uFog"); uFogRange = u(p, "uFogRange"); uMode = u(p, "uMode")
        uShadowOn = u(p, "uShadowOn"); uTexel = u(p, "uTexel")
        uBoxes = u(p, "uBoxes"); uBoxCount = u(p, "uBoxCount"); uRT = u(p, "uRT"); uCam = u(p, "uCam"); uFloorCol = u(p, "uFloorCol")
    }

    /** Ray-tracing shader is compiled on its own, so a failure here never breaks normal rendering. */
    private fun initRT() {
        val saved = error
        rtProg = link(VS, FS_RT)
        if (rtProg == 0) {
            rtError = if (error.length > saved.length) error.substring(saved.length) else "RT shader failed"
            error = saved
            return
        }
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        rtTex = t[0]
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rtTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA32F, 3, RT_MAX, 0, GLES30.GL_RGBA, GLES30.GL_FLOAT, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        rtOk = true
    }

    fun useRT(on: Boolean) {
        val p = if (on && rtOk) rtProg else prog
        if (p != active) {
            active = p
            bindLocs(p)
        }
    }

    /** Call right after beginMain when ray tracing is on. buf = 12 floats per box: min, max, color. */
    fun rtFrame(buf: java.nio.FloatBuffer, n: Int, cx: Float, cy: Float, cz: Float, floorCol: Int) {
        if (active != rtProg || !rtOk) return
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, rtTex)
        if (n > 0) GLES30.glTexSubImage2D(GLES30.GL_TEXTURE_2D, 0, 0, 0, 3, n, GLES30.GL_RGBA, GLES30.GL_FLOAT, buf)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glUniform1i(uBoxes, 2)
        GLES30.glUniform1i(uBoxCount, n)
        GLES30.glUniform1f(uRT, 1f)
        GLES30.glUniform3f(uCam, cx, cy, cz)
        GLES30.glUniform3f(uFloorCol, ((floorCol shr 16) and 255) / 255f, ((floorCol shr 8) and 255) / 255f, (floorCol and 255) / 255f)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val st = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            Log.e(TAG, log)
            error += "Shader: " + log.take(240) + " "
            GLES30.glDeleteShader(s)
            return 0
        }
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val a = compile(GLES30.GL_VERTEX_SHADER, vs)
        val b = compile(GLES30.GL_FRAGMENT_SHADER, fs)
        if (a == 0 || b == 0) return 0
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, a)
        GLES30.glAttachShader(p, b)
        GLES30.glLinkProgram(p)
        val st = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(p)
            Log.e(TAG, log)
            error += "Link: " + log.take(240) + " "
            return 0
        }
        return p
    }

    private fun buildMesh() {
        // per face: normal, then corners TL, TR, BR, BL
        val faces = arrayOf(
            floatArrayOf(1f, 0f, 0f, .5f, -.5f, .5f, .5f, .5f, .5f, .5f, .5f, -.5f, .5f, -.5f, -.5f),
            floatArrayOf(-1f, 0f, 0f, -.5f, .5f, .5f, -.5f, -.5f, .5f, -.5f, -.5f, -.5f, -.5f, .5f, -.5f),
            floatArrayOf(0f, 1f, 0f, .5f, .5f, .5f, -.5f, .5f, .5f, -.5f, .5f, -.5f, .5f, .5f, -.5f),
            floatArrayOf(0f, -1f, 0f, -.5f, -.5f, .5f, .5f, -.5f, .5f, .5f, -.5f, -.5f, -.5f, -.5f, -.5f),
            floatArrayOf(0f, 0f, 1f, -.5f, -.5f, .5f, -.5f, .5f, .5f, .5f, .5f, .5f, .5f, -.5f, .5f),
            floatArrayOf(0f, 0f, -1f, .5f, -.5f, -.5f, .5f, .5f, -.5f, -.5f, .5f, -.5f, -.5f, -.5f, -.5f)
        )
        val uvs = floatArrayOf(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f)
        val data = FloatArray(24 * 9)
        val idx = ShortArray(36)
        for (f in 0 until 6) {
            val fd = faces[f]
            for (v in 0 until 4) {
                val o = (f * 4 + v) * 9
                data[o] = fd[3 + v * 3]; data[o + 1] = fd[4 + v * 3]; data[o + 2] = fd[5 + v * 3]
                data[o + 3] = fd[0]; data[o + 4] = fd[1]; data[o + 5] = fd[2]
                data[o + 6] = uvs[v * 2]; data[o + 7] = uvs[v * 2 + 1]
                data[o + 8] = f.toFloat()
            }
            val b = f * 4
            val k = f * 6
            idx[k] = b.toShort(); idx[k + 1] = (b + 1).toShort(); idx[k + 2] = (b + 2).toShort()
            idx[k + 3] = b.toShort(); idx[k + 4] = (b + 2).toShort(); idx[k + 5] = (b + 3).toShort()
        }
        val fb = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(data); fb.position(0)
        val sb = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        sb.put(idx); sb.position(0)

        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        vao = ids[0]
        GLES30.glBindVertexArray(vao)
        val bufs = IntArray(2)
        GLES30.glGenBuffers(2, bufs, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, bufs[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.size * 4, fb, GLES30.GL_STATIC_DRAW)
        val stride = 9 * 4
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, stride, 12)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, stride, 24)
        GLES30.glEnableVertexAttribArray(3)
        GLES30.glVertexAttribPointer(3, 1, GLES30.GL_FLOAT, false, stride, 32)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, bufs[1])
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, sb, GLES30.GL_STATIC_DRAW)
    }

    private fun initShadow() {
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        shadowTex = t[0]
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, shadowTex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_DEPTH_COMPONENT24, SHADOW, SHADOW, 0,
            GLES30.GL_DEPTH_COMPONENT, GLES30.GL_UNSIGNED_INT, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_MODE, GLES30.GL_COMPARE_REF_TO_TEXTURE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_FUNC, GLES30.GL_LEQUAL)
        val f = IntArray(1)
        GLES30.glGenFramebuffers(1, f, 0)
        shadowFbo = f[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, shadowFbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_TEXTURE_2D, shadowTex, 0)
        GLES30.glDrawBuffers(1, intArrayOf(GLES30.GL_NONE), 0)
        GLES30.glReadBuffer(GLES30.GL_NONE)
        shadowOk = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) == GLES30.GL_FRAMEBUFFER_COMPLETE
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    fun makeTexture(bmp: Bitmap, repeat: Boolean, mip: Boolean): Int {
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0])
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        if (mip) GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER,
            if (mip) GLES30.GL_LINEAR_MIPMAP_LINEAR else GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        val w = if (repeat) GLES30.GL_REPEAT else GLES30.GL_CLAMP_TO_EDGE
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, w)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, w)
        return t[0]
    }

    fun makeWorldBitmap(): Bitmap {
        val s = 128
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint()
        c.drawColor(0xFFD8D8D8.toInt())
        val r = Random(7)
        p.style = Paint.Style.FILL
        for (i in 0 until 900) {
            p.color = if (r.nextBoolean()) 0x18FFFFFF else 0x18000000
            val x = r.nextInt(s).toFloat()
            val y = r.nextInt(s).toFloat()
            c.drawRect(x, y, x + 3f, y + 3f, p)
        }
        val sf = s.toFloat()
        p.color = 0x30FFFFFF
        c.drawRect(0f, 0f, sf, 4f, p); c.drawRect(0f, 0f, 4f, sf, p)
        p.color = 0x40000000
        c.drawRect(0f, sf - 4f, sf, sf, p); c.drawRect(sf - 4f, 0f, sf, sf, p)
        p.color = 0x14000000; c.drawCircle(64f, 64f, 22f, p)
        p.color = 0x20FFFFFF; c.drawCircle(61f, 61f, 18f, p)
        return bmp
    }

    fun useTex(tex: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
    }

    fun beginMain(vp: FloatArray, lvp: FloatArray, light: FloatArray, fog: Int, near: Float, far: Float, shadowOn: Boolean) {
        shadowPass = false
        GLES30.glUseProgram(active)
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0)
        GLES30.glUniformMatrix4fv(uLightVP, 1, false, lvp, 0)
        GLES30.glUniform3f(uLightDir, light[0], light[1], light[2])
        GLES30.glUniform3f(uFog, ((fog shr 16) and 255) / 255f, ((fog shr 8) and 255) / 255f, (fog and 255) / 255f)
        GLES30.glUniform2f(uFogRange, near, far)
        GLES30.glUniform1f(uShadowOn, if (shadowOn && shadowOk) 1f else 0f)
        GLES30.glUniform1f(uTexel, 1f / SHADOW)
        GLES30.glUniform1i(uTex, 0)
        GLES30.glUniform1i(uShadowMap, 1)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, shadowTex)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindVertexArray(vao)
    }

    fun beginShadow(lvp: FloatArray) {
        shadowPass = true
        GLES30.glUseProgram(sprog)
        GLES30.glUniformMatrix4fv(sLVP, 1, false, lvp, 0)
        GLES30.glBindVertexArray(vao)
    }

    /** model = rigid transform (translate + rotate). Size is applied separately. */
    override fun box(model: FloatArray, sx: Float, sy: Float, sz: Float, color: Int, faces: FloatArray) {
        if (shadowPass) {
            GLES30.glUniformMatrix4fv(sModel, 1, false, model, 0)
            GLES30.glUniform3f(sScale, sx, sy, sz)
        } else {
            GLES30.glUniformMatrix4fv(uModel, 1, false, model, 0)
            GLES30.glUniform3f(uScale, sx, sy, sz)
            GLES30.glUniform4f(uColor, ((color shr 16) and 255) / 255f, ((color shr 8) and 255) / 255f, (color and 255) / 255f, 1f)
            GLES30.glUniform1i(uMode, mode)
            GLES30.glUniform4fv(uFace, 6, faces, 0)
        }
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, 36, GLES30.GL_UNSIGNED_SHORT, 0)
    }
}
