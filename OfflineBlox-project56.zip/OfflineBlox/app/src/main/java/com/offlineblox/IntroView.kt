package com.offlineblox

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Black intro: "Offline" (white) slides in, "Blox" (yellow) drops in, "W.O.M.P." slides out from under Blox. */
class IntroView(ctx: Context, private val onDone: () -> Unit) : View(ctx) {
    private val t0 = SystemClock.uptimeMillis()
    private var fired = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    private fun ease(x: Float): Float {
        val k = x.coerceIn(0f, 1f)
        return 1f - (1f - k) * (1f - k) * (1f - k)
    }

    private fun finish() {
        if (!fired) {
            fired = true
            post { onDone() }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) finish()
        return true
    }

    override fun onDraw(c: Canvas) {
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        c.drawColor(Color.BLACK)
        val w = width.toFloat()
        val h = height.toFloat()
        val size = min(w * 0.12f, h * 0.30f)
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        p.letterSpacing = 0f
        p.textSize = size
        val offW = p.measureText("Offline")
        val bloxW = p.measureText("Blox")
        val x0 = (w - offW - bloxW) / 2f
        val by = h * 0.52f
        val fade = 1f - ease((t - 4.1f) / 0.5f)
        val alphaAll = 255f * fade

        // "Offline" slides in from the left
        val a1 = ease((t - 0.2f) / 0.7f)
        p.color = Color.WHITE
        p.alpha = (alphaAll * a1).toInt().coerceIn(0, 255)
        c.drawText("Offline", x0 - (1f - a1) * size * 1.6f, by, p)

        // "Blox" drops from above with a small bounce
        val b = ((t - 0.75f) / 0.5f).coerceIn(0f, 1f)
        val pos = 1f - (1f - b) * (1f - b) * cos(b * 9f)
        val yo = -(1f - pos) * h * 0.7f
        p.color = 0xFFF5CD30.toInt()
        p.alpha = if (t > 0.75f) alphaAll.toInt().coerceIn(0, 255) else 0
        c.drawText("Blox", x0 + offW, by + yo, p)

        // little yellow blocks burst out when Blox lands
        if (t > 1.2f && t < 2.0f) {
            val k = (t - 1.2f) / 0.8f
            val cx = x0 + offW + bloxW / 2f
            for (i in 0 until 12) {
                val ang = i * 0.5236f
                val dist = ease(k) * size * (0.9f + (i % 3) * 0.35f)
                p.color = 0xFFF5CD30.toInt()
                p.alpha = ((1f - k) * alphaAll).toInt().coerceIn(0, 255)
                val sz = size * 0.07f * (1f - k * 0.5f)
                c.drawRect(cx + cos(ang) * dist - sz, by - size * 0.3f + sin(ang) * dist - sz,
                    cx + cos(ang) * dist + sz, by - size * 0.3f + sin(ang) * dist + sz, p)
            }
        }

        // "W.O.M.P." slides down out of the bottom edge of "Blox"
        val s = ease((t - 1.75f) / 0.95f)
        if (s > 0f) {
            val ws = size * 0.30f
            p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            p.textSize = ws
            p.letterSpacing = 0.25f
            val womp = "W.O.M.P."
            val ww = p.measureText(womp)
            val clipTop = by + size * 0.10f
            val y = clipTop + ws * 1.05f * s
            p.color = 0xFFF5CD30.toInt()
            p.alpha = alphaAll.toInt().coerceIn(0, 255)
            c.drawRect(x0 + offW, clipTop, x0 + offW + bloxW * s, clipTop + 3f * d, p)
            p.color = Color.WHITE
            p.alpha = alphaAll.toInt().coerceIn(0, 255)
            c.save()
            c.clipRect(0f, clipTop + 3f * d, w, h)
            c.drawText(womp, x0 + offW + bloxW - ww, y, p)
            c.restore()
            p.letterSpacing = 0f
        }

        if (t > 1f && t < 4f) {
            p.typeface = Typeface.DEFAULT
            p.textSize = 11f * d
            p.color = 0xFF777777.toInt()
            p.alpha = 255
            p.textAlign = Paint.Align.CENTER
            c.drawText(L.t("tap to skip", "แตะเพื่อข้าม"), w / 2f, h - 24f * d, p)
            p.textAlign = Paint.Align.LEFT
        }
        if (t > 4.7f) finish() else postInvalidateOnAnimation()
    }
}

/** Intro jingle synthesised in code (no audio files): sweep, thump + chime, whoosh, two "womps", chord. */
object IntroSound {
    private var track: AudioTrack? = null

    fun stop() {
        val t = track
        track = null
        if (t != null) {
            try { t.stop() } catch (_: Exception) {}
            try { t.release() } catch (_: Exception) {}
        }
    }

    fun play(vol: Float) {
        stop()
        Thread {
            try {
                val sr = 22050
                val n = (sr * 4.4f).toInt()
                val s = FloatArray(n)
                val twoPi = (2.0 * PI).toFloat()
                fun add(t0: Float, dur: Float, f: (Float) -> Float) {
                    val i0 = (t0 * sr).toInt()
                    val cnt = (dur * sr).toInt()
                    for (i in 0 until cnt) {
                        val idx = i0 + i
                        if (idx >= n) break
                        s[idx] += f(i.toFloat() / sr)
                    }
                }
                // "Offline" sweep 200 -> 520 Hz
                add(0.2f, 0.7f) { t -> sin(twoPi * (200f * t + 320f * t * t / (2f * 0.7f))) * sin((PI * t / 0.7f).toFloat()) * 0.15f }
                // Blox lands: thump 110 -> 45 Hz
                add(1.15f, 0.5f) { t -> sin(twoPi * (110f * t - 65f * t * t / (2f * 0.5f))) * exp(-t * 7f) * 0.7f }
                // chime
                add(1.2f, 0.9f) { t -> (sin(twoPi * 660f * t) + 0.5f * sin(twoPi * 990f * t)) * exp(-t * 5f) * 0.22f }
                add(1.32f, 0.9f) { t -> sin(twoPi * 880f * t) * exp(-t * 5f) * 0.18f }
                // whoosh while W.O.M.P. slides out
                val rnd = java.util.Random(3)
                var z = 0f
                add(1.75f, 0.95f) { t ->
                    val nz = rnd.nextFloat() * 2f - 1f
                    z += (nz - z) * (0.05f + 0.2f * (t / 0.95f))
                    z * sin((PI * t / 0.95f).toFloat()) * 0.5f
                }
                // two descending "womps"
                add(2.45f, 0.5f) { t ->
                    val f = 260f - 120f * (t / 0.5f)
                    val ph = twoPi * (f * t + 3f * sin(twoPi * 6f * t) / 6f)
                    (sin(ph) + 0.4f * sin(2f * ph)) * exp(-t * 3f) * 0.3f
                }
                add(2.95f, 0.6f) { t ->
                    val f = 240f - 150f * (t / 0.6f)
                    val ph = twoPi * (f * t + 3f * sin(twoPi * 5f * t) / 5f)
                    (sin(ph) + 0.4f * sin(2f * ph)) * exp(-t * 2.6f) * 0.32f
                }
                // closing chord
                for (fq in floatArrayOf(262f, 330f, 392f)) {
                    add(3.3f, 1.1f) { t -> sin(twoPi * fq * t) * sin((PI * t / 1.1f).toFloat()) * 0.1f }
                }
                val data = ShortArray(n) { (s[it].coerceIn(-1f, 1f) * 30000f).toInt().toShort() }
                val at = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                at.write(data, 0, data.size)
                at.setVolume(vol.coerceIn(0f, 1f))
                track = at
                at.play()
            } catch (_: Exception) {}
        }.start()
    }
}
