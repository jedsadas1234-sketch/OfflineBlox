package com.offlineblox

import android.graphics.Bitmap
import android.opengl.Matrix
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt

/** Anything the avatar rig / scene can draw boxes into (OpenGL Gfx or the Vulkan instance list). */
interface Painter {
    var mode: Int
    fun box(model: FloatArray, sx: Float, sy: Float, sz: Float, color: Int, faces: FloatArray)
}

/** JNI bridge to the C++ Vulkan renderer (libobvk.so). */
object VkBridge {
    @Volatile var loaded = false

    init {
        try {
            System.loadLibrary("obvk")
            loaded = true
        } catch (_: Throwable) {
        }
    }

    @JvmStatic external fun probe(): String
    @JvmStatic external fun start(surface: Surface, w: Int, h: Int): String
    @JvmStatic external fun uploadAtlas(layer: Int, bmp: Bitmap)
    @JvmStatic external fun uploadWorld(bmp: Bitmap)
    @JvmStatic external fun render(buf: ByteBuffer, nShadow: Int, nMain: Int, globals: FloatArray): String
    @JvmStatic external fun destroy()

    /** True when the native library loaded and a Vulkan device with a graphics queue exists. */
    fun available(): Boolean {
        if (!loaded) return false
        return try { probe().isEmpty() } catch (_: Throwable) { false }
    }
}

/** Collects boxes as instance data: 24 floats each (model 16, scale+mode/part 4, color+layer 4). */
class VkPainter : Painter {
    companion object { const val MAX = 6000 }

    val buf: ByteBuffer = ByteBuffer.allocateDirect(MAX * 96).order(ByteOrder.nativeOrder())
    private val fb = buf.asFloatBuffer()
    var count = 0
    var layer = 0f
    override var mode = 0

    fun reset() {
        fb.clear()
        count = 0
    }

    override fun box(model: FloatArray, sx: Float, sy: Float, sz: Float, color: Int, faces: FloatArray) {
        if (count >= MAX) return
        var part = 6
        for (i in 0 until 6) if (faces === AvatarTex.rects[i]) part = i
        fb.put(model, 0, 16)
        fb.put(sx).put(sy).put(sz).put((mode + 2 * part).toFloat())
        fb.put(((color shr 16) and 255) / 255f).put(((color shr 8) and 255) / 255f).put((color and 255) / 255f).put(layer)
        count++
    }
}

/** Runs the Vulkan renderer on its own thread for a SurfaceView. */
class VkHost(view: SurfaceView, private val hud: GameHud) : SurfaceHolder.Callback {
    private var th: Thread? = null
    @Volatile private var running = false

    init {
        view.holder.addCallback(this)
    }

    override fun surfaceCreated(h: SurfaceHolder) {}

    override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) {
        stop()
        running = true
        val sf = h.surface
        val t = Thread { loop(sf, w, hh) }
        th = t
        t.start()
    }

    override fun surfaceDestroyed(h: SurfaceHolder) {
        stop()
    }

    private fun stop() {
        running = false
        try { th?.join(3000) } catch (_: Exception) {}
        th = null
    }

    private fun loop(sf: Surface, w: Int, h: Int) {
        val err = try { VkBridge.start(sf, w, h) } catch (e: Throwable) { e.toString() }
        if (err.isNotEmpty()) {
            hud.glError = "Vulkan: $err"
            return
        }
        try {
            val painter = VkPainter()
            val rig = Rig(painter)
            val atlas = HashMap<String, Int>()
            var next = 0
            fun layerFor(a: Avatar): Float {
                val key = a.ser() + "#" + Skins.ver
                var l = atlas[key]
                if (l == null) {
                    if (next >= 32) { atlas.clear(); next = 0 }
                    val bmp = AvatarTex.make(a)
                    VkBridge.uploadAtlas(next, bmp)
                    bmp.recycle()
                    l = next
                    atlas[key] = l
                    next++
                }
                return l.toFloat()
            }
            VkBridge.uploadWorld(Gfx().makeWorldBitmap())

            val lproj = FloatArray(16)
            val lview = FloatArray(16)
            val lvp = FloatArray(16)
            val model = FloatArray(16)
            val globals = FloatArray(48)
            val ln = sqrt(0.42f * 0.42f + 0.30f * 0.30f + 0.85f * 0.85f)
            val lx = 0.42f / ln
            val ly = 0.30f / ln
            val lz = 0.85f / ln

            fun world(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, color: Int) {
                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, cx, cy, cz)
                painter.box(model, sx, sy, sz, color, AvatarTex.white)
            }
            fun person(a: Avatar, x: Float, y: Float, z: Float, yaw: Float, phase: Float, swing: Float, airT: Float) {
                painter.mode = 0
                painter.layer = layerFor(a)
                rig.draw(a, x, y, z, yaw, phase, swing, airT)
            }

            while (running) {
                val gm = hud.gm
                val t = (System.currentTimeMillis() % 600000L) / 1000f
                val px = hud.px
                val py = hud.py
                val shadowsOn = hud.shadows
                painter.reset()

                // shadow casters: nearby solids + every character (also our own in first person)
                if (shadowsOn) {
                    painter.mode = 1
                    for (b in gm.solids) {
                        val bx = b.cx(t)
                        val by = b.cy(t)
                        if (abs(bx - px) > 45f + b.w || abs(by - py) > 45f + b.d || !b.on(t)) continue
                        world(bx + b.w / 2f, by + b.d / 2f, b.cz(t) + b.h / 2f, b.w, b.d, b.h, b.color)
                    }
                    person(hud.av, hud.px, hud.py, hud.pz, hud.yaw, hud.phase, hud.swing, hud.airT)
                    for (r in hud.net.peers.values) if (r.fresh) person(r.av, r.x, r.y, r.z, r.yaw, r.phase, r.swing, r.airT)
                }
                val nShadow = painter.count

                // visible scene
                painter.mode = 1
                val f = gm.floor
                if (f != null) world((f[0] + f[2]) / 2f, (f[1] + f[3]) / 2f, -0.75f, f[2] - f[0], f[3] - f[1], 1.5f, gm.floorColor)
                for (b in gm.solids) {
                    val bx = b.cx(t)
                    val by = b.cy(t)
                    if (abs(bx - px) > 170f + b.w || abs(by - py) > 170f + b.d || !b.on(t)) continue
                    world(bx + b.w / 2f, by + b.d / 2f, b.cz(t) + b.h / 2f, b.w, b.d, b.h, b.color)
                }
                for (b in gm.decor) {
                    if (abs(b.x - px) > 130f + b.w || abs(b.y - py) > 130f + b.d) continue
                    world(b.x + b.w / 2f, b.y + b.d / 2f, b.z + b.h / 2f, b.w, b.d, b.h, b.color)
                }
                if (!hud.firstPerson) person(hud.av, hud.px, hud.py, hud.pz, hud.yaw, hud.phase, hud.swing, hud.airT)
                for (r in hud.net.peers.values) if (r.fresh) person(r.av, r.x, r.y, r.z, r.yaw, r.phase, r.swing, r.airT)
                val nMain = painter.count - nShadow

                // light matrix (GL-style; the shaders convert to Vulkan clip space)
                val cx = floor(px)
                val cy = floor(py)
                val cz = hud.pz
                Matrix.setLookAtM(lview, 0, cx + lx * 50f, cy + ly * 50f, cz + lz * 50f, cx, cy, cz, 0f, 0f, 1f)
                Matrix.orthoM(lproj, 0, -30f, 30f, -30f, 30f, 1f, 120f)
                Matrix.multiplyMM(lvp, 0, lproj, 0, lview, 0)

                System.arraycopy(hud.vp, 0, globals, 0, 16)
                System.arraycopy(lvp, 0, globals, 16, 16)
                globals[32] = lx; globals[33] = ly; globals[34] = lz; globals[35] = 0f
                val sky = gm.skyBot
                globals[36] = ((sky shr 16) and 255) / 255f
                globals[37] = ((sky shr 8) and 255) / 255f
                globals[38] = (sky and 255) / 255f
                globals[39] = 0f
                globals[40] = 120f; globals[41] = 340f; globals[42] = 0f; globals[43] = 0f
                globals[44] = if (shadowsOn) 1f else 0f
                globals[45] = 1f / 1024f
                globals[46] = 0f; globals[47] = 0f

                val e = VkBridge.render(painter.buf, nShadow, nMain, globals)
                if (e.isNotEmpty()) {
                    hud.glError = "Vulkan: $e"
                    break
                }
            }
        } catch (e: Throwable) {
            hud.glError = "Vulkan: $e"
        } finally {
            try { VkBridge.destroy() } catch (_: Throwable) {}
        }
    }
}
