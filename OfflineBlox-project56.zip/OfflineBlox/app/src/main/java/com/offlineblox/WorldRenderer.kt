package com.offlineblox

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt

class WorldRenderer(private val hud: GameHud) : GLSurfaceView.Renderer {
    private var gfx = Gfx()
    private var rig = Rig(gfx)
    private val atlas = HashMap<String, Int>()
    private val lproj = FloatArray(16)
    private val lview = FloatArray(16)
    private val lvp = FloatArray(16)
    private val model = FloatArray(16)
    private val rtBuf = ByteBuffer.allocateDirect(Gfx.RT_MAX * 12 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private var rtN = 0
    private val light = FloatArray(3)
    private var w = 1
    private var h = 1

    init {
        val l = sqrt(0.42f * 0.42f + 0.30f * 0.30f + 0.85f * 0.85f)
        light[0] = 0.42f / l; light[1] = 0.30f / l; light[2] = 0.85f / l
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        gfx = Gfx()
        gfx.init()
        rig = Rig(gfx)
        atlas.clear()
        hud.glError = gfx.error
        hud.rtError = if (gfx.rtOk) "" else (if (gfx.rtError.isEmpty()) "RT not available" else gfx.rtError)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = width; h = height
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val gm = hud.gm
        val sky = gm.skyBot
        GLES30.glClearColor(((sky shr 16) and 255) / 255f, ((sky shr 8) and 255) / 255f, (sky and 255) / 255f, 1f)
        if (!gfx.ok) {
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
            return
        }
        try {
            val cx = floor(hud.px)
            val cy = floor(hud.py)
            val cz = hud.pz
            Matrix.setLookAtM(lview, 0, cx + light[0] * 50f, cy + light[1] * 50f, cz + light[2] * 50f, cx, cy, cz, 0f, 0f, 1f)
            Matrix.orthoM(lproj, 0, -30f, 30f, -30f, 30f, 1f, 120f)
            Matrix.multiplyMM(lvp, 0, lproj, 0, lview, 0)
            val rtOn = hud.rt && gfx.rtOk
            gfx.useRT(rtOn)
            val useShadow = hud.shadows && gfx.shadowOk && !rtOn
            if (useShadow) {
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, gfx.shadowFbo)
                GLES30.glViewport(0, 0, Gfx.SHADOW, Gfx.SHADOW)
                GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT)
                GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
                GLES30.glPolygonOffset(2f, 4f)
                gfx.beginShadow(lvp)
                drawScene(true)
                GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL)
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
                GLES30.glViewport(0, 0, w, h)
            }
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
            gfx.beginMain(hud.vp, lvp, light, sky, 120f, 340f, useShadow)
            if (rtOn) {
                buildRt()
                gfx.rtFrame(rtBuf, rtN, hud.camEx, hud.camEy, hud.camEz, gm.floorColor)
            }
            drawScene(false)
        } catch (e: Exception) {
            hud.glError = e.toString()
        }
    }

    /** Nearest boxes (plus the players as blocky occluders) go to the ray-tracing shader. */
    private fun buildRt() {
        val gm = hud.gm
        val t = (System.currentTimeMillis() % 600000L) / 1000f
        val px = hud.px
        val py = hud.py
        val list = gm.solids
        val keys = IntArray(list.size)
        var cnt = 0
        for (i in list.indices) {
            val b = list[i]
            if (!b.on(t)) continue
            val dx = b.cx(t) + b.w / 2f - px
            val dy = b.cy(t) + b.d / 2f - py
            val d2 = dx * dx + dy * dy
            if (d2 > 6400f) continue
            keys[cnt++] = (d2.toInt() shl 16) or i
        }
        java.util.Arrays.sort(keys, 0, cnt)
        val take = minOf(cnt, Gfx.RT_MAX - 36)
        rtBuf.clear()
        for (k in 0 until take) {
            val b = list[keys[k] and 0xFFFF]
            val bx = b.cx(t)
            val by = b.cy(t)
            val bz = b.cz(t)
            val c = b.color
            rtBuf.put(bx).put(by).put(bz).put(0f)
            rtBuf.put(bx + b.w).put(by + b.d).put(bz + b.h).put(0f)
            rtBuf.put(((c shr 16) and 255) / 255f).put(((c shr 8) and 255) / 255f).put((c and 255) / 255f).put(0f)
        }
        var n = take
        fun addBox(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, c: Int) {
            if (n >= Gfx.RT_MAX) return
            rtBuf.put(x0).put(y0).put(z0).put(0f)
            rtBuf.put(x1).put(y1).put(z1).put(0f)
            rtBuf.put(((c shr 16) and 255) / 255f).put(((c shr 8) and 255) / 255f).put((c and 255) / 255f).put(0f)
            n++
        }
        // a character = 6 blocky parts (head, torso, 2 arms, 2 legs), turned to the nearest axis
        fun person(x: Float, y: Float, z: Float, yaw: Float, a: Avatar) {
            val side = abs(sin(yaw * 0.017453292f)) > 0.7f
            val skin = Pal.skin[a.skin]
            val shirt = Pal.col[a.shirt]
            val pants = Pal.col[a.pants]
            fun part(cu: Float, hu: Float, hv: Float, z0: Float, z1: Float, c: Int) {
                if (!side) addBox(x - hv, y + cu - hu, z + z0, x + hv, y + cu + hu, z + z1, c)
                else addBox(x + cu - hu, y - hv, z + z0, x + cu + hu, y + hv, z + z1, c)
            }
            part(0.5f, 0.5f, 0.5f, 0f, 2f, pants)
            part(-0.5f, 0.5f, 0.5f, 0f, 2f, pants)
            part(0f, 1f, 0.5f, 2f, 4f, shirt)
            part(1.5f, 0.5f, 0.5f, 2f, 4f, shirt)
            part(-1.5f, 0.5f, 0.5f, 2f, 4f, shirt)
            part(0f, 0.6f, 0.6f, 4f, 5.2f, skin)
        }
        person(hud.px, hud.py, hud.pz, hud.yaw, hud.av)
        for (r in hud.net.peers.values) if (r.fresh) person(r.x, r.y, r.z, r.yaw, r.av)
        rtBuf.position(0)
        rtN = n
    }

    private fun worldBox(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, color: Int) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, cx, cy, cz)
        gfx.box(model, sx, sy, sz, color, AvatarTex.white)
    }

    private fun drawScene(shadow: Boolean) {
        val gm = hud.gm
        gfx.mode = 1
        if (!shadow) gfx.useTex(gfx.worldTex)
        val f = gm.floor
        if (f != null && !shadow) {
            worldBox((f[0] + f[2]) / 2f, (f[1] + f[3]) / 2f, -0.75f, f[2] - f[0], f[3] - f[1], 1.5f, gm.floorColor)
        }
        val t = (System.currentTimeMillis() % 600000L) / 1000f
        val ppx = hud.px
        val ppy = hud.py
        val lim = if (shadow) 45f else 170f
        for (b in gm.solids) {
            val bx = b.cx(t)
            val by = b.cy(t)
            if (abs(bx - ppx) > lim + b.w || abs(by - ppy) > lim + b.d) continue
            if (!b.on(t)) continue
            worldBox(bx + b.w / 2f, by + b.d / 2f, b.cz(t) + b.h / 2f, b.w, b.d, b.h, b.color)
        }
        if (!shadow) {
            for (b in gm.decor) {
                if (abs(b.x - ppx) > 130f + b.w || abs(b.y - ppy) > 130f + b.d) continue
                worldBox(b.x + b.w / 2f, b.y + b.d / 2f, b.z + b.h / 2f, b.w, b.d, b.h, b.color)
            }
        }
        gfx.mode = 0
        if (shadow || !hud.firstPerson) drawAv(shadow, hud.av, hud.px, hud.py, hud.pz, hud.yaw, hud.phase, hud.swing, hud.airT)
        for (r in hud.net.peers.values) {
            if (r.fresh) drawAv(shadow, r.av, r.x, r.y, r.z, r.yaw, r.phase, r.swing, r.airT)
        }
    }

    private fun drawAv(shadow: Boolean, a: Avatar, x: Float, y: Float, z: Float, yaw: Float, phase: Float, swing: Float, airT: Float) {
        if (!shadow) gfx.useTex(atlasTex(a))
        rig.draw(a, x, y, z, yaw, phase, swing, airT)
    }

    private fun atlasTex(a: Avatar): Int {
        val key = a.ser() + "#" + Skins.ver
        var t = atlas[key]
        if (t == null) {
            if (atlas.size > 40) {
                for (v in atlas.values) GLES30.glDeleteTextures(1, intArrayOf(v), 0)
                atlas.clear()
            }
            val bmp = AvatarTex.make(a)
            t = gfx.makeTexture(bmp, false, false)
            bmp.recycle()
            atlas[key] = t
        }
        return t
    }
}
