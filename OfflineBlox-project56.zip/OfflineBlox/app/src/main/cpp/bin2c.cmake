file(READ "${IN}" HEXDATA HEX)
string(REGEX REPLACE "([0-9a-f][0-9a-f])" "0x\\1," ARR "${HEXDATA}")
file(WRITE "${OUT}" "static const unsigned char ${NAME}[] __attribute__((aligned(4))) = {${ARR}};\n")
