#version 450
layout(location = 0) in vec3 vN;
layout(location = 1) in vec2 vUV;
layout(location = 2) in vec4 vShadow;
layout(location = 3) in vec3 vWorld;
layout(location = 4) in float vDist;
layout(location = 5) in vec4 vColor;
layout(location = 6) flat in vec2 vMP;
layout(set = 0, binding = 0, std140) uniform U {
  mat4 vp;
  mat4 lvp;
  vec4 light;
  vec4 fog;
  vec4 fogRange;
  vec4 params;
} u;
layout(set = 0, binding = 1) uniform sampler2DArray uAtlas;
layout(set = 0, binding = 2) uniform sampler2D uWorld;
layout(set = 0, binding = 3) uniform sampler2DShadow uShadow;
layout(location = 0) out vec4 outColor;
void main() {
  vec3 n = normalize(vN);
  vec4 tex;
  if (vMP.y > 0.5) {
    vec3 an = abs(n);
    vec2 w;
    if (an.z > 0.5) { w = vWorld.xy; } else if (an.x > 0.5) { w = vWorld.yz; } else { w = vWorld.xz; }
    tex = texture(uWorld, w / 4.0);
  } else {
    tex = texture(uAtlas, vec3(vUV, vColor.a));
  }
  vec3 base = tex.rgb * vColor.rgb;
  float ndl = max(dot(n, u.light.xyz), 0.0);
  float sh = 1.0;
  if (u.params.x > 0.5) {
    vec3 nd = vShadow.xyz / vShadow.w;
    vec2 suv = vec2(nd.x * 0.5 + 0.5, -nd.y * 0.5 + 0.5);
    float ref = nd.z * 0.5 + 0.5 - 0.003;
    if (suv.x > 0.0 && suv.x < 1.0 && suv.y > 0.0 && suv.y < 1.0 && ref < 1.0) {
      float sum = 0.0;
      for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
          sum += texture(uShadow, vec3(suv + vec2(float(i), float(j)) * u.params.y, ref));
        }
      }
      sh = sum / 9.0;
    }
  }
  float hemi = 0.5 + 0.5 * n.z;
  float light = 0.36 + 0.14 * hemi + 0.62 * ndl * sh;
  vec3 col = base * light;
  float fogK = clamp((vDist - u.fogRange.x) / (u.fogRange.y - u.fogRange.x), 0.0, 1.0);
  col = mix(col, u.fog.rgb, fogK);
  outColor = vec4(col, 1.0);
}
