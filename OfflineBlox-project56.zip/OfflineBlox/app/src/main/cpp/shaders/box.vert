#version 450
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;
layout(location = 3) in float aFace;
layout(location = 4) in vec4 iM0;
layout(location = 5) in vec4 iM1;
layout(location = 6) in vec4 iM2;
layout(location = 7) in vec4 iM3;
layout(location = 8) in vec4 iScale;
layout(location = 9) in vec4 iColor;
layout(set = 0, binding = 0, std140) uniform U {
  mat4 vp;
  mat4 lvp;
  vec4 light;
  vec4 fog;
  vec4 fogRange;
  vec4 params;
} u;
layout(location = 0) out vec3 vN;
layout(location = 1) out vec2 vUV;
layout(location = 2) out vec4 vShadow;
layout(location = 3) out vec3 vWorld;
layout(location = 4) out float vDist;
layout(location = 5) out vec4 vColor;
layout(location = 6) flat out vec2 vMP;
void main() {
  mat4 model = mat4(iM0, iM1, iM2, iM3);
  vec4 wp = model * vec4(aPos * iScale.xyz, 1.0);
  vWorld = wp.xyz;
  vN = normalize(mat3(model) * aNormal);
  float part = floor(iScale.w * 0.5 + 0.01);
  float mode = iScale.w - part * 2.0;
  vMP = vec2(part, mode);
  vec2 org = vec2((aFace * 64.0 + 1.0) / 384.0, (part * 64.0 + 1.0) / 448.0);
  vUV = org + aUV * vec2(62.0 / 384.0, 62.0 / 448.0);
  vShadow = u.lvp * wp;
  vec4 c = u.vp * wp;
  gl_Position = vec4(c.x, -c.y, (c.z + c.w) * 0.5, c.w);
  vDist = c.w;
  vColor = iColor;
}
