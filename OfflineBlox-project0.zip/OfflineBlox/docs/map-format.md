# OfflineBlox map file (`.map`)

A `.map` file is plain **JSON text** (UTF-8). Max 8000 boxes, 600 KB.

```json
{
  "version": 1,
  "name": "My Map",
  "desc": "short description",
  "spawn": [0, 0],
  "sky": ["#4A90D9", "#BFE0FF"],
  "floor": { "rect": [-100, -100, 100, 100], "color": "#7A7F85" },
  "boxes": [
    { "x": 0, "y": 0, "z": 0, "w": 10, "d": 10, "h": 3, "color": "#C4281C" },
    { "x": 20, "y": 0, "z": 0, "w": 4, "d": 4, "h": 0.8, "color": "#DA8541",
      "kind": 3, "move": [0, 7, 0], "period": 8, "phase": 0 }
  ]
}
```

* Coordinates are studs. `x`,`y` = ground plane, `z` = up. A box is placed by its **minimum corner** `(x, y, z)` with size `w` (x), `d` (y), `h` (z).
* `spawn`: `[x, y]`, the player appears there 1 stud above the floor.
* `sky`: `[top, bottom]`; the bottom colour is also the fog colour.
* `floor` is optional. Leave it out for a "void" map (players fall below z = -30 and respawn).
* `color`: `#RRGGBB`.
* `kind` (default 0):
  * 0 solid
  * 1 lava (kills)
  * 2 bounce pad
  * 3 moving platform: `move` = `[dx, dy, dz]` amplitude in studs, `period` in seconds
  * 4 blinking platform: `period` and `phase` in seconds (visible 65% of the period)
  * 5 checkpoint (stand on it to set the respawn point)
  * 6 moving lava bar (same fields as 3)
  * 7 decor (no collision, no shadow)
* Use periods that divide 600 (4, 5, 6, 8, 10, 12, 15, 20, 24, 25, 30 ...) so every phone stays in sync.
* Keep a stair step lower than 0.3 stud if players should walk up it without jumping.

## Talking to the game from the editor app

Import (push a map into the game):

* **Share / open a file**: `Intent.ACTION_SEND` (or `ACTION_VIEW`) with MIME type `application/x-offlineblox-map`, the `.map` file in `EXTRA_STREAM` (or the JSON text in `EXTRA_TEXT`), package `com.offlineblox`.
* **Custom action**: `com.offlineblox.IMPORT_MAP` with the JSON text in the extra `json`.
* **Content provider**: `contentResolver.insert(Uri.parse("content://com.offlineblox.maps/maps"), ContentValues().apply { put("json", text) })`.

Pull (read maps out of the game, including the built-in ones):

* `contentResolver.query(Uri.parse("content://com.offlineblox.maps/maps"), null, null, null, null)` -> columns `name, desc, builtin` for every map.
* `contentResolver.query(Uri.parse("content://com.offlineblox.maps/maps/" + Uri.encode(name)), ...)` -> adds the full `.map` JSON in column `json`.
* `contentResolver.delete(Uri.parse("content://com.offlineblox.maps/maps/" + Uri.encode(name)), null, null)` removes an imported (not built-in) map.

On Android 11+ the editor app needs `<queries><package android:name="com.offlineblox"/></queries>` in its manifest.
